<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-17 10:02:23 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:02:32 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:02:46 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:02:50 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:02:55 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:03:39 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:03:43 --> 404 Page Not Found: /index
ERROR - 2021-12-17 05:06:31 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-17 10:07:30 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:07:39 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:10:28 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:12:15 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:12:34 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:12:38 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:12:42 --> 404 Page Not Found: /index
ERROR - 2021-12-17 05:13:33 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-17 05:13:45 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-17 05:13:47 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-17 05:13:47 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-17 10:13:55 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:13:57 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:14:44 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:14:49 --> 404 Page Not Found: /index
ERROR - 2021-12-17 05:14:52 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-17 10:14:53 --> 404 Page Not Found: /index
ERROR - 2021-12-17 05:15:11 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-17 10:35:59 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:38:44 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:38:48 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:38:48 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:39:40 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:39:53 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:40:09 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:40:26 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:40:49 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:41:11 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:41:40 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:42:00 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:42:10 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:42:43 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:48:51 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:51:54 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:51:56 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:52:08 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:52:09 --> 404 Page Not Found: /index
ERROR - 2021-12-17 10:59:20 --> 404 Page Not Found: /index
ERROR - 2021-12-17 11:12:25 --> 404 Page Not Found: /index
ERROR - 2021-12-17 11:12:34 --> 404 Page Not Found: /index
ERROR - 2021-12-17 11:15:55 --> 404 Page Not Found: /index
ERROR - 2021-12-17 11:16:47 --> 404 Page Not Found: /index
ERROR - 2021-12-17 11:59:31 --> 404 Page Not Found: /index
ERROR - 2021-12-17 11:59:33 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:00:06 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:00:12 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:00:13 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-17 07:00:21 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-17 12:00:33 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:00:35 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:00:46 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:00:51 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:01:02 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:01:17 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:01:53 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:02:28 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:02:46 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:03:02 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:03:11 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:03:58 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:04:49 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:13:22 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:13:28 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:13:31 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:16:41 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:17:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 07:17:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 12:17:50 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:19:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 07:19:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 12:19:06 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:26:45 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:26:48 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:26:51 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:05 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:09 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:14 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:25 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:30 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:42 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:48 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:50 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:51 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:27:56 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:29:42 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:29:55 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 07:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 12:31:20 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:31:40 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:32:25 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:32:26 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:32:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 07:32:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 12:32:55 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:18 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:19 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:32 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:32 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:39 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:44 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:45 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:40:57 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:41:00 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:41:27 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-17 12:41:28 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:41:29 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:41:33 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:41:37 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:42:04 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:42:18 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:42:19 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:42:26 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:42:42 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-17 12:42:46 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:42:59 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:43:13 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:43:21 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:43:23 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:43:32 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:43:45 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:44:05 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:44:07 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:45:00 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:49:18 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:49:19 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:49:22 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:49:31 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:49:32 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:50:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 07:50:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 12:50:25 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:53:31 --> 404 Page Not Found: /index
ERROR - 2021-12-17 12:53:43 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 07:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 12:54:43 --> 404 Page Not Found: /index
ERROR - 2021-12-17 07:59:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 07:59:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 12:59:42 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:01:34 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:01:40 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:01:43 --> 404 Page Not Found: /index
ERROR - 2021-12-17 08:02:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 08:02:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 13:02:55 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:03:51 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:04:46 --> 404 Page Not Found: /index
ERROR - 2021-12-17 08:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 08:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 13:06:08 --> 404 Page Not Found: /index
ERROR - 2021-12-17 08:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 08:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 13:07:09 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:07:34 --> 404 Page Not Found: /index
ERROR - 2021-12-17 08:08:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 08:08:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 13:08:52 --> 404 Page Not Found: /index
ERROR - 2021-12-17 08:09:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 912
ERROR - 2021-12-17 08:09:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 1330
ERROR - 2021-12-17 13:09:49 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:16:25 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:36:30 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:36:37 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:36:46 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:39:53 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:39:57 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:40:02 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:40:53 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:43:17 --> 404 Page Not Found: /index
ERROR - 2021-12-17 13:48:07 --> 404 Page Not Found: /index
ERROR - 2021-12-17 16:44:41 --> 404 Page Not Found: /index
