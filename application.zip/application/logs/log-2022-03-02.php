<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-02 10:07:45 --> 404 Page Not Found: /index
ERROR - 2022-03-02 10:07:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-02 10:07:56 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-02 10:07:57 --> 404 Page Not Found: /index
ERROR - 2022-03-02 10:19:40 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:42:01 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-02 11:42:01 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:42:04 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:42:10 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:42:21 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:42:40 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:42:51 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:42:55 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:43:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-02 11:43:53 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:44:05 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:44:12 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:44:20 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:44:25 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:44:42 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:46:07 --> Query error: Unknown column 'order_schedules.re_upload_change' in 'field list' - Invalid query: SELECT `order_schedules`.`re_upload_change`
FROM `order_schedules`
WHERE `order_schedules`.`re_upload_change` = '1'
AND `order_schedules`.`order_id` = '652'
AND `order_schedules`.`created_by` = '15'
AND DATE(order_schedules.start_date) >= '2021-09-01'
AND DATE(order_schedules.end_date) <= '2021-09-15'
ERROR - 2022-03-02 11:46:37 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:49:42 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:49:42 --> 404 Page Not Found: /index
ERROR - 2022-03-02 11:50:21 --> Query error: Unknown column 'order_schedules.re_upload_change' in 'field list' - Invalid query: SELECT `order_schedules`.`re_upload_change`
FROM `order_schedules`
WHERE `order_schedules`.`re_upload_change` = '1'
AND `order_schedules`.`order_id` = '652'
AND `order_schedules`.`created_by` = '15'
AND DATE(order_schedules.start_date) >= '2021-09-01'
AND DATE(order_schedules.end_date) <= '2021-09-15'
ERROR - 2022-03-02 12:10:19 --> Severity: Warning --> require_once(Mail.php): failed to open stream: No such file or directory C:\xampp\htdocs\brienza\application\libraries\Mail_template.php 3
ERROR - 2022-03-02 12:10:19 --> Severity: Compile Error --> require_once(): Failed opening required 'Mail.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\brienza\application\libraries\Mail_template.php 3
ERROR - 2022-03-02 12:45:34 --> 404 Page Not Found: /index
ERROR - 2022-03-02 12:47:37 --> 404 Page Not Found: /index
ERROR - 2022-03-02 12:47:40 --> 404 Page Not Found: /index
ERROR - 2022-03-02 14:14:47 --> 404 Page Not Found: /index
