<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-23 06:17:56 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:20:17 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-23 06:20:27 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-23 06:20:28 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:21:14 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:21:22 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:21:41 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:21:47 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:25:06 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:30:14 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:37:41 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:44:34 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:45:24 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:45:28 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:45:28 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:51:18 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:51:21 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:51:37 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:51:41 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:51:41 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:52:32 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:52:32 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:52:37 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:52:48 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:52:50 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:52:55 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:53:02 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:54:37 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:55:07 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:56:19 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:57:45 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:58:09 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:59:40 --> 404 Page Not Found: /index
ERROR - 2022-11-23 06:59:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:00:13 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:00:34 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:01:53 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:01:57 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:02:06 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:02:13 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:02:21 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:02:35 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-23 07:06:19 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:06:52 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:09:11 --> 404 Page Not Found: /index
ERROR - 2022-11-23 07:09:50 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:00:11 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:00:41 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:14:17 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:16:50 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:17:02 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:17:03 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:18:31 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:18:31 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:18:57 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:18:57 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:19:50 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:19:52 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:19:55 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:20:01 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:20:01 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:25:51 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:25:52 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:40:28 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:40:28 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:42:16 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:50:55 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:50:57 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:50:58 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:51:17 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:51:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:51:44 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:51:58 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:52:19 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:52:29 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:52:39 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:52:46 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:52:55 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:53:03 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:53:09 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:53:09 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:55:28 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-23 08:55:41 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:59:15 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:59:17 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:59:25 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:59:28 --> 404 Page Not Found: /index
ERROR - 2022-11-23 08:59:29 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:01:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:01:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:01:54 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:01:54 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:03:48 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:03:48 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:03:58 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:03:58 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:04:10 --> 404 Page Not Found: /index
ERROR - 2022-11-23 09:04:10 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:04:36 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:04:57 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-23 11:04:59 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-23 11:04:59 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:05:18 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:05:21 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:06:33 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:06:50 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:06:50 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:08:33 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:10:22 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:11:32 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:12:45 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:12:55 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:12:56 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:14:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:14:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:15:32 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:15:32 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:15:52 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:15:53 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:16:21 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:16:33 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:16:34 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:17:36 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:20:02 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:20:03 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:20:49 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:22:10 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:22:10 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:22:59 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:23:22 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:25:05 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:25:31 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:25:40 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:27:07 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:28:10 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:28:46 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:29:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 124
ERROR - 2022-11-23 11:29:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 130
ERROR - 2022-11-23 11:29:05 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:31:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-23 11:31:30 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:33:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 124
ERROR - 2022-11-23 11:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 130
ERROR - 2022-11-23 11:33:23 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:34:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 130
ERROR - 2022-11-23 11:34:34 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:36:03 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:36:27 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:36:30 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:37:10 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:42:05 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:55:06 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:55:37 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:55:56 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:56:04 --> 404 Page Not Found: /index
ERROR - 2022-11-23 11:56:29 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:21:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:22:23 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:29:12 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:29:54 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:34:32 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:35:43 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:36:56 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:36:59 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:48:20 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:50:52 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:58:53 --> 404 Page Not Found: /index
ERROR - 2022-11-23 12:58:58 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:00 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:01 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:01 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:01 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:13 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:16 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:16 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:17 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:17 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:17 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:18 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:19 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:19 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:23 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 12:59:23 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:35:32 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:37:12 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:37:16 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:37:45 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:37:46 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:38:11 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:38:14 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:38:17 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:40:47 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:41:57 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:43:48 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:43:49 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:50 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:51 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:51 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:52 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:52 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:52 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:53 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:43:53 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:52:44 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:52:45 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:52:46 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:52:47 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:54:58 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:55:20 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:20 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:20 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:20 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:21 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:21 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:21 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:21 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:22 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:55:23 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:28 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:56:36 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:37 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:37 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:37 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:37 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:37 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:38 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:38 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:56:39 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:26 --> 404 Page Not Found: /index
ERROR - 2022-11-23 13:58:29 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:29 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:30 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:30 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:30 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:30 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:31 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 13:58:31 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 14:00:16 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:00:16 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:00:38 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:00:51 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 14:05:14 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:05:14 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:05:19 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 14:06:19 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 14:06:19 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:06:19 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:06:23 --> Severity: error --> Exception: Too few arguments to function Presenters::viewTemplateModal(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2804
ERROR - 2022-11-23 14:07:54 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:07:54 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:08:45 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:08:45 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:11:04 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:11:04 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:13:17 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:13:17 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:13:25 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2809
ERROR - 2022-11-23 14:13:30 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2809
ERROR - 2022-11-23 14:14:48 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:14:48 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:14:51 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2809
ERROR - 2022-11-23 14:14:56 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2809
ERROR - 2022-11-23 14:21:01 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2810
ERROR - 2022-11-23 14:22:08 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:22:08 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:23:21 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:23:21 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:24:52 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:24:53 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:34:05 --> 404 Page Not Found: /index
ERROR - 2022-11-23 14:34:06 --> 404 Page Not Found: /index
