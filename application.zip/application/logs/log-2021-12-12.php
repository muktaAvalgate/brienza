<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-12 18:29:24 --> 404 Page Not Found: /index
ERROR - 2021-12-12 13:29:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-12 18:29:34 --> 404 Page Not Found: /index
ERROR - 2021-12-12 18:30:39 --> 404 Page Not Found: /index
