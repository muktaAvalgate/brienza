<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-18 07:17:12 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:17:28 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:17:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 07:17:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 07:18:03 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-18 07:18:03 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:18:11 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:18:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 07:18:18 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-18 07:18:21 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:20:47 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:20:52 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:20:59 --> 404 Page Not Found: /index
ERROR - 2022-08-18 07:22:56 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:30:16 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:30:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 09:30:35 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:30:41 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:30:55 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:30:57 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:31:03 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:31:07 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:31:08 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:31:26 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 09:31:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-18 09:32:01 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:32:14 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:32:23 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-18 09:34:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-18 09:38:24 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:38:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 09:38:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-18 09:38:40 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:38:44 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:38:53 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:46:59 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 61
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 61
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 66
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 66
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 67
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 67
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 68
ERROR - 2022-08-18 09:49:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 68
ERROR - 2022-08-18 09:50:01 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:50:08 --> 404 Page Not Found: /index
ERROR - 2022-08-18 09:50:16 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:24:13 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 14:24:15 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-18 14:33:33 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:36:09 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:36:57 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:37:19 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:37:47 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:38:08 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:41:56 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:42:27 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 14:42:29 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:42:41 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:42:45 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:06 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:08 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:14 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:21 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:24 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:27 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:32 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:34 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:41 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:42 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:46 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:48 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:54 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:43:58 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:44:16 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:44:28 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-18 14:44:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-18 14:44:29 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:44:30 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:44:50 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:44:54 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:44:58 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:02 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:04 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:05 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:05 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:06 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:06 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:07 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:07 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:07 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:08 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:08 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:09 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:09 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:10 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:10 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:11 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:11 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:12 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:12 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:45:12 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-18 14:55:23 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:55:31 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:55:57 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:56:20 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:56:33 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:56:36 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:56:41 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:56:45 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:56:47 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:57:30 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:58:16 --> 404 Page Not Found: /index
ERROR - 2022-08-18 14:58:42 --> 404 Page Not Found: /index
ERROR - 2022-08-18 15:00:35 --> 404 Page Not Found: /index
ERROR - 2022-08-18 15:00:38 --> 404 Page Not Found: /index
ERROR - 2022-08-18 15:00:44 --> 404 Page Not Found: /index
ERROR - 2022-08-18 15:01:01 --> 404 Page Not Found: /index
ERROR - 2022-08-18 15:03:04 --> 404 Page Not Found: /index
ERROR - 2022-08-18 15:03:09 --> 404 Page Not Found: /index
