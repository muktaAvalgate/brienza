<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-22 06:28:12 --> 404 Page Not Found: /index
ERROR - 2022-11-22 06:30:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-22 06:30:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-22 07:10:47 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-22 07:25:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-22 07:25:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-22 07:25:12 --> 404 Page Not Found: /index
ERROR - 2022-11-22 07:27:17 --> 404 Page Not Found: /index
ERROR - 2022-11-22 07:29:03 --> 404 Page Not Found: /index
ERROR - 2022-11-22 07:29:06 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-22 07:29:06 --> 404 Page Not Found: /index
ERROR - 2022-11-22 07:30:34 --> 404 Page Not Found: /index
ERROR - 2022-11-22 07:44:07 --> 404 Page Not Found: /index
ERROR - 2022-11-22 07:54:06 --> 404 Page Not Found: /index
ERROR - 2022-11-22 07:55:00 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:00:17 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:10:02 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:10:22 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:10:25 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:10:50 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:22:34 --> Severity: Notice --> Undefined variable: tem_list C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 124
ERROR - 2022-11-22 08:22:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 124
ERROR - 2022-11-22 08:22:34 --> Severity: Notice --> Undefined variable: tem_list C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 130
ERROR - 2022-11-22 08:22:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\logs.php 130
ERROR - 2022-11-22 08:22:34 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:31:14 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:31:39 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:31:50 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:32:09 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:32:35 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:33:29 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:33:57 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:35:05 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:36:28 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:36:32 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:36:58 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:37:04 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:37:31 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:38:14 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:39:03 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:39:23 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:39:47 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:40:41 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:41:13 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:41:47 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:42:19 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:42:56 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:43:36 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:44:13 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:55:08 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:55:40 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:57:10 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:57:15 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:57:41 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:57:44 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:58:26 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:58:46 --> 404 Page Not Found: /index
ERROR - 2022-11-22 08:59:13 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:00:08 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:00:35 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:03:57 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:03:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:03:57 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:04:02 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:04:09 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:04:09 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:04:29 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:05:06 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:05:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:05:06 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:08:26 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:08:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:08:26 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:08:44 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:08:51 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:08:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 09:08:51 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:09:14 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:10:57 --> 404 Page Not Found: /index
ERROR - 2022-11-22 09:15:25 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:28:18 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-22 12:28:35 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:34:32 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:34:50 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:35:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-22 12:35:05 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-22 12:35:06 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:35:35 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:35:53 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:36:53 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:37:08 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:37:08 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:38:21 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:38:22 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:38:43 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:38:44 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:39:46 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:39:46 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:41:00 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:41:00 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:42:14 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:42:45 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:45:11 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:46:01 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:55:10 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:55:54 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:56:41 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:57:24 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:59:10 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:59:23 --> 404 Page Not Found: /index
ERROR - 2022-11-22 12:59:24 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:28:30 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:28:30 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:29:29 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:29:47 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:29:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:29:47 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:30:05 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:30:09 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:30:32 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:30:37 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:30:37 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:30:57 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:32:58 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:32:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:32:58 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:33:21 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:33:48 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:33:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:33:48 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:34:06 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:34:08 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:34:08 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:35:20 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:35:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:35:20 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:37:13 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:37:13 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:37:15 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:37:15 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:37:36 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:37:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 13:37:37 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:37:59 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:38:10 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:38:52 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:39:18 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:41:33 --> 404 Page Not Found: /index
ERROR - 2022-11-22 13:44:22 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:04:56 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:05:36 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:05:39 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 14:05:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 14:05:39 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:06:49 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 14:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 14:06:49 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:07:48 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 14:07:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-22 14:07:48 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:08:26 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:08:41 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:14:50 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:16:01 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:16:17 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:17:27 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:17:52 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:18:07 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:18:23 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:20:02 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:20:17 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:21:06 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:21:22 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:21:40 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:21:56 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:22:04 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:22:43 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:23:30 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:23:34 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:23:38 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:24:22 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:25:55 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:26:51 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:27:57 --> 404 Page Not Found: /index
ERROR - 2022-11-22 14:28:08 --> 404 Page Not Found: /index
