<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-09 07:15:30 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:16:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-09 07:16:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:16:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:16:43 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:18:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-09 07:18:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-09 07:18:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:18:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:18:15 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:18:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-09 07:18:47 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-09 07:18:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:18:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:18:48 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:19:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:19:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:19:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:19:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:29:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:30:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:30:55 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:32:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:32:04 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:33:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:33:57 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:34:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:15 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:34:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:21 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:34:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:48 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:34:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:34:53 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:35:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:35:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:35:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:35:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:40 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:36:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:52 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:36:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:36:57 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:40:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:40:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:40:06 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:40:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:40:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:40:08 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:48:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:12 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:48:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:21 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:48:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:21 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:48:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:24 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:48:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:28 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:48:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:36 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:48:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:48:43 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:49:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:49:08 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:49:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:49:37 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:50:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:50:53 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:52:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:52:58 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:53:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:11 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:53:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:14 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:53:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:23 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:53:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:28 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:53:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:33 --> 404 Page Not Found: /index
ERROR - 2022-09-09 07:53:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 07:53:41 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:03:32 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:03:49 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:04:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:04:12 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:11:39 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:11:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:11:41 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:11:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:11:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:11:45 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:12:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:12:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:12:07 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:03 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:21:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:44 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:21:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:21:49 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:22:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:22:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:22:11 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:23:42 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:23:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:23:43 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:23:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:23:54 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:01 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:11 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:13 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:24:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:24:23 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:03 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:13 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:25:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:25:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:25:56 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:26:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:26:05 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:27:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:27:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:27:37 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:33:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:33:43 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 83
ERROR - 2022-09-09 08:33:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-09 08:33:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:33:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:34:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:34:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:34:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:34:49 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 08:36:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:36:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:37:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:15 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 08:47:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:20 --> 404 Page Not Found: /index
ERROR - 2022-09-09 08:47:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:32 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 08:47:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:48:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:48:04 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 08:48:18 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 416
ERROR - 2022-09-09 08:48:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 417
ERROR - 2022-09-09 08:48:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:50:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:51:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:51:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 08:51:34 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:07:14 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 419
ERROR - 2022-09-09 09:07:14 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:07:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:07:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:07:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:07:14 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:07:33 --> Severity: Notice --> Undefined variable: description C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 419
ERROR - 2022-09-09 09:07:33 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:07:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:07:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:07:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:07:33 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:09:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:09:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:09:46 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:10:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:13 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:10:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:19 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:10:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:43 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:10:54 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-09 09:10:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-09 09:10:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:55 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-09 09:10:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-09 09:10:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:10:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:11:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:11:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:11:29 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:11:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:12:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:12:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:12:07 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:01 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:14 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:31 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:13:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:13:39 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:14:24 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:14:27 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:27 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:14:28 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:14:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:14:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:14:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:14:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:15:49 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:15:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:15:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:15:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:15:49 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:17:42 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:17:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:17:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:17:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:17:43 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:18:30 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:18:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:18:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:18:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:18:30 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:28:45 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:28:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:28:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:28:45 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:30:15 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:30:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:30:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:30:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:30:15 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:31:19 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 420
ERROR - 2022-09-09 09:31:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 421
ERROR - 2022-09-09 09:31:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:31:19 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:43:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:43:30 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:43:44 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:44:40 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:44:40 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:47:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:47:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:47:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:47:54 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 09:47:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:47:58 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:53:30 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:53:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:53:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:53:58 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:54:09 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:54:17 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:54:17 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:54:19 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:54:19 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:54:20 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:54:20 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:54:21 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:54:21 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:54:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:54:24 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:54:33 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:54:33 --> 404 Page Not Found: /index
ERROR - 2022-09-09 09:54:56 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:55:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:55:01 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:55:11 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:56:00 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:56:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:56:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:56:13 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:56:21 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 69
ERROR - 2022-09-09 09:57:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:57:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:57:25 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 09:57:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 09:57:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:17:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:17:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:17:55 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:29:22 --> Severity: Notice --> Undefined variable: notification C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 90
ERROR - 2022-09-09 11:29:23 --> Severity: Notice --> Undefined variable: notification C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 90
ERROR - 2022-09-09 11:29:38 --> Severity: Notice --> Undefined variable: notification C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 90
ERROR - 2022-09-09 11:29:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:29:41 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:29:52 --> Severity: Notice --> Undefined variable: notification C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 90
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-09 11:30:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:30:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:30:23 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:31:07 --> Severity: Notice --> Undefined variable: notifications C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 90
ERROR - 2022-09-09 11:48:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:03 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-09 11:48:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:27 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:48:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:48:37 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:49:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:49:35 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:49:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:49:46 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:49:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:49:54 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:50:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:50:11 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:50:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:50:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:50:23 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:50:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:50:42 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:51:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:51:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:51:39 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:51:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:51:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:51:48 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:51:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:51:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:51:56 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:54:19 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:54:20 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:54:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:54:42 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:54:42 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:55:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-09 11:55:01 --> 404 Page Not Found: /index
ERROR - 2022-09-09 11:55:01 --> 404 Page Not Found: /index
