<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-14 06:17:04 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:24:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-14 06:25:00 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-14 06:26:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-14 06:27:28 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:47:23 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:47:34 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:47:44 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:47:50 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:47:51 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:48:58 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:53:05 --> 404 Page Not Found: /index
ERROR - 2022-11-14 06:53:07 --> 404 Page Not Found: /index
ERROR - 2022-11-14 07:09:18 --> 404 Page Not Found: /index
ERROR - 2022-11-14 07:37:16 --> 404 Page Not Found: /index
ERROR - 2022-11-14 07:43:12 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:34:50 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:36:13 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:36:14 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:42:43 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:42:43 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:42:57 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:44:21 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:44:58 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:58:50 --> 404 Page Not Found: /index
ERROR - 2022-11-14 08:59:00 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:16:06 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:16:10 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:17:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-14 10:17:11 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:07 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:20 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:24 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:26 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:30 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:34 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:37 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:45 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:46 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:47 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:52 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:23:56 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:24:01 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:24:04 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:24:05 --> 404 Page Not Found: /index
ERROR - 2022-11-14 10:51:51 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-14 10:51:53 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-14 11:59:35 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 12:17:49 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:17:59 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:52:21 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:52:26 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:52:29 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:52:36 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:52:39 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:52:41 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:53:40 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 12:54:27 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:54:30 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:54:32 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:54:35 --> 404 Page Not Found: /index
ERROR - 2022-11-14 12:55:48 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:02:55 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:03:38 --> 404 Page Not Found: /index
ERROR - 2022-11-14 13:03:50 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:04:07 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:05:41 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:13:23 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:31:01 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:38:14 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:43:21 --> Severity: Notice --> Undefined variable: notification_id C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 301
ERROR - 2022-11-14 13:43:22 --> Query error: Column 'notification_id' cannot be null - Invalid query: INSERT INTO `notification_users` (`user_id`, `notification_id`) VALUES ('5', NULL)
ERROR - 2022-11-14 13:45:48 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:48:37 --> 404 Page Not Found: /index
ERROR - 2022-11-14 13:52:53 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 13:55:01 --> 404 Page Not Found: /index
ERROR - 2022-11-14 14:21:18 --> 404 Page Not Found: /index
ERROR - 2022-11-14 14:21:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-14 14:21:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-14 14:21:33 --> 404 Page Not Found: /index
ERROR - 2022-11-14 14:21:37 --> 404 Page Not Found: /index
ERROR - 2022-11-14 14:21:39 --> 404 Page Not Found: /index
ERROR - 2022-11-14 14:26:17 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-14 14:29:43 --> 404 Page Not Found: /index
