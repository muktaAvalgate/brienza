<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-31 07:19:48 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:20:02 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:20:23 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-31 07:20:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4165
ERROR - 2022-08-31 07:20:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-31 07:20:34 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4165
ERROR - 2022-08-31 07:20:34 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4165
ERROR - 2022-08-31 07:20:34 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-31 07:20:43 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-31 07:20:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4165
ERROR - 2022-08-31 07:20:46 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-31 07:29:33 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:29:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-31 07:29:42 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-31 07:29:42 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:31:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`' at line 3 - Invalid query: SELECT *
FROM `sessions`
WHERE `id` > `IS` `NULL`
ERROR - 2022-08-31 07:31:47 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:31:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`' at line 3 - Invalid query: SELECT *
FROM `sessions`
WHERE `id` > `IS` `NULL`
ERROR - 2022-08-31 07:36:38 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:01 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:04 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:08 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:20 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:30 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:47 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:50 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:37:52 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:39:56 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:40:08 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:40:19 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-08-31 07:41:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-08-31 07:42:06 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:42:08 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:42:23 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:44:43 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:44:48 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:44:51 --> 404 Page Not Found: /index
ERROR - 2022-08-31 07:45:00 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:11:31 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:11:45 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:11:56 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:12:18 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:12:29 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:13:11 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:13:38 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:13:39 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:13:50 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:23:13 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:23:24 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:26:17 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:26:29 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:26:43 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:27:16 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:27:25 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:27:34 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:27:39 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:28:33 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:28:35 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:28:45 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:30:14 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:30:23 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:30:33 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:36:31 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:36:35 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:36:54 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:36:57 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:37:05 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:40:01 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:40:14 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:40:31 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:40:58 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:41:04 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:41:28 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:41:30 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:41:32 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:41:41 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:44:45 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:44:56 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:45:08 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:45:35 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:45:40 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:45:57 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:46:00 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:46:04 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:48:23 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:48:34 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:48:44 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:49:02 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:49:08 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:49:26 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:49:28 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:49:30 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:49:35 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:58:17 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:58:28 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:58:41 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:59:10 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:59:15 --> 404 Page Not Found: /index
ERROR - 2022-08-31 08:59:59 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:00:02 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:00:12 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:02:21 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:02:22 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:02:32 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:02:44 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 63
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 63
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 67
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 67
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 69
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 69
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 70
ERROR - 2022-08-31 09:03:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 70
ERROR - 2022-08-31 09:03:31 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:03:36 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:05:01 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:05:03 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:05:08 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:12:16 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:12:28 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:19:52 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:20:09 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:20:25 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:21:58 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:22:19 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:22:38 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:24:32 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:24:38 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:30:21 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:30:26 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:30:31 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:31:13 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:31:17 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:31:43 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:31:55 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:31:57 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:34:15 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:34:19 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:34:32 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:34:43 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:36:00 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:36:04 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:36:09 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:37:02 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:37:06 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:37:09 --> 404 Page Not Found: /index
ERROR - 2022-08-31 09:37:20 --> 404 Page Not Found: /index
ERROR - 2022-08-31 11:53:44 --> 404 Page Not Found: /index
ERROR - 2022-08-31 11:54:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-31 11:54:19 --> 404 Page Not Found: /index
ERROR - 2022-08-31 11:54:29 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-31 11:54:31 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-31 11:54:47 --> 404 Page Not Found: /index
ERROR - 2022-08-31 11:55:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-31 11:55:03 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-31 11:55:03 --> 404 Page Not Found: /index
ERROR - 2022-08-31 11:56:39 --> 404 Page Not Found: /index
ERROR - 2022-08-31 11:59:41 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:06:21 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:06:21 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:23:55 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:23:56 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:45:40 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:45:40 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:49:48 --> Severity: error --> Exception: syntax error, unexpected ' ' (T_STRING) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4731
ERROR - 2022-08-31 12:49:52 --> Severity: error --> Exception: syntax error, unexpected ' ' (T_STRING) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4731
ERROR - 2022-08-31 12:50:03 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:50:03 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:51:03 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:51:03 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:53:46 --> 404 Page Not Found: /index
ERROR - 2022-08-31 12:53:46 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:00:25 --> Severity: Compile Error --> Cannot redeclare Schools::teacher_report() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 924
ERROR - 2022-08-31 13:01:01 --> Severity: Compile Error --> Cannot redeclare Schools::teacher_report() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 924
ERROR - 2022-08-31 13:01:33 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:01:34 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:03:23 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:03:23 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:03:27 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:03:27 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:05:18 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:05:18 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:05:32 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:05:33 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:05:36 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:05:36 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:27:25 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:27:25 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:33:03 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:43:50 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:43:50 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:48:55 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4712
ERROR - 2022-08-31 13:48:58 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4712
ERROR - 2022-08-31 13:49:38 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:49:39 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:53:24 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:53:27 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:53:28 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:53:28 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:53:28 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:53:29 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:53:29 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:54:19 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:54:20 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:54:21 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4713
ERROR - 2022-08-31 13:55:08 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:55:09 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:10 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:11 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-08-31 13:55:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:17 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-08-31 13:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-08-31 13:55:28 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:30 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-08-31 13:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-08-31 13:55:35 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:55:39 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:55:40 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:55:46 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:46 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:46 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:55:46 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:58 --> 404 Page Not Found: /index
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:56:59 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 13:57:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-08-31 13:57:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-08-31 13:57:02 --> 404 Page Not Found: /index
ERROR - 2022-08-31 14:20:31 --> 404 Page Not Found: /index
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:32 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Notice --> Undefined index: sessions.name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:20:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-08-31 14:20:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-08-31 14:21:17 --> 404 Page Not Found: /index
ERROR - 2022-08-31 14:27:04 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:27:05 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:33:53 --> 404 Page Not Found: /index
ERROR - 2022-08-31 14:35:55 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:35:56 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:35:56 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:35:56 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:35:56 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:35:56 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:35:57 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:38:40 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:38:41 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:38:41 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:38:41 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:38:41 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:38:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:39:46 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-08-31 14:39:48 --> 404 Page Not Found: /index
ERROR - 2022-08-31 14:39:51 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
