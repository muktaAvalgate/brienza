<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-09 06:11:07 --> 404 Page Not Found: /index
ERROR - 2022-12-09 06:11:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-09 06:11:54 --> 404 Page Not Found: /index
ERROR - 2022-12-09 06:11:59 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-09 06:12:02 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-09 06:15:09 --> 404 Page Not Found: /index
ERROR - 2022-12-09 06:15:11 --> 404 Page Not Found: /index
ERROR - 2022-12-09 06:23:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 40
ERROR - 2022-12-09 06:23:32 --> Query error: Unknown column 'title_topics' in 'where clause' - Invalid query: SELECT *
FROM `title_topics`
JOIN `order_schedules` ON `order_schedules`.`topic_id` = `title_topics`.`id`
WHERE `order_schedules`.`created_by` = '15'
AND `title_topics` <> `null`
GROUP BY `order_schedules`.`topic_id`
ERROR - 2022-12-09 06:23:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 40
ERROR - 2022-12-09 06:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 40
ERROR - 2022-12-09 06:32:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-09 06:32:15 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:32:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:32:15 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:32:15 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:34:53 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:34:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:34:53 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:34:53 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:35:14 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:35:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:35:14 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:35:14 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:35:33 --> Severity: error --> Exception: syntax error, unexpected '&&' (T_BOOLEAN_AND), expecting :: (T_PAAMAYIM_NEKUDOTAYIM) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 40
ERROR - 2022-12-09 06:35:53 --> Severity: error --> Exception: syntax error, unexpected '&&' (T_BOOLEAN_AND), expecting :: (T_PAAMAYIM_NEKUDOTAYIM) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 40
ERROR - 2022-12-09 06:36:06 --> Severity: error --> Exception: syntax error, unexpected '||' (T_BOOLEAN_OR), expecting :: (T_PAAMAYIM_NEKUDOTAYIM) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 40
ERROR - 2022-12-09 06:49:48 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:49:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:49:48 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:49:48 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:20 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:20 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:20 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:57 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:57 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:51:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 38
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 38
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 38
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 38
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Undefined variable: log_content C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 45
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 45
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Undefined variable: log_content C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 45
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 45
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Undefined variable: log_content C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 45
ERROR - 2022-12-09 06:52:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 45
ERROR - 2022-12-09 06:53:06 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:53:06 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:53:06 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:53:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:53:24 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:53:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:53:24 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 06:53:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 07:07:51 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 07:07:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 07:07:51 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 07:07:51 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 07:11:21 --> 404 Page Not Found: /index
ERROR - 2022-12-09 07:11:23 --> 404 Page Not Found: /index
ERROR - 2022-12-09 07:56:38 --> 404 Page Not Found: /index
ERROR - 2022-12-09 07:56:40 --> 404 Page Not Found: /index
ERROR - 2022-12-09 08:12:33 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:12:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:12:33 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:12:33 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:16 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:16 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:16 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:49 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:49 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:34:49 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:35:41 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:35:41 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:35:41 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:35:41 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-09 08:37:57 --> 404 Page Not Found: /index
ERROR - 2022-12-09 08:38:03 --> 404 Page Not Found: /index
ERROR - 2022-12-09 08:48:21 --> 404 Page Not Found: /index
ERROR - 2022-12-09 08:48:40 --> 404 Page Not Found: /index
ERROR - 2022-12-09 08:49:01 --> 404 Page Not Found: /index
ERROR - 2022-12-09 08:49:05 --> 404 Page Not Found: /index
ERROR - 2022-12-09 08:49:07 --> 404 Page Not Found: /index
ERROR - 2022-12-09 11:00:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-09 11:00:36 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-09 12:08:02 --> 404 Page Not Found: /index
ERROR - 2022-12-09 12:08:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-09 12:08:19 --> 404 Page Not Found: /index
ERROR - 2022-12-09 12:08:25 --> 404 Page Not Found: /index
ERROR - 2022-12-09 12:08:42 --> 404 Page Not Found: /index
ERROR - 2022-12-09 12:08:42 --> 404 Page Not Found: /index
ERROR - 2022-12-09 12:44:42 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
