<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-21 05:08:32 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:08:38 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:09:12 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:11:11 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:15:40 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:17:55 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:18:06 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:19:08 --> 404 Page Not Found: /index
ERROR - 2021-12-21 00:20:25 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 05:23:44 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:24:19 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:25:12 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:25:30 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:26:44 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:31:40 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:32:33 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:32:59 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:33:24 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:42:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:45:56 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:47:53 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:48:29 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:51:38 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:51:50 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:54:49 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:56:55 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:57:04 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:57:07 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:57:09 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:58:13 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:58:45 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:59:09 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:03:36 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:09:07 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:09:10 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:09:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:09:57 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:10:00 --> 404 Page Not Found: /index
ERROR - 2021-12-21 01:10:02 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 01:10:03 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 01:10:09 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 06:10:16 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:11:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:11:20 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:11:37 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:11:55 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:21:59 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:22:24 --> 404 Page Not Found: /index
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 01:22:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 06:24:36 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:24:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 01:24:59 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 06:25:03 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:25:36 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:25:51 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:25:56 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:26:46 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:26:50 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:27:46 --> 404 Page Not Found: /index
ERROR - 2021-12-21 07:49:09 --> 404 Page Not Found: /index
ERROR - 2021-12-21 07:49:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 07:49:42 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:11:21 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:11:24 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:11:50 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:11:55 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:12:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:12:47 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:17:12 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:17:18 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:18:00 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:18:21 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:18:23 --> 404 Page Not Found: /index
ERROR - 2021-12-21 03:18:42 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 03:18:59 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 08:19:06 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:19:09 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:19:13 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:44:54 --> 404 Page Not Found: /index
ERROR - 2021-12-21 08:45:08 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:03:33 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:11:59 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:12:04 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:12:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:12:23 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:12:30 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:12:33 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:22:26 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:22:57 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:23:10 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:23:14 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:26:26 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:27:16 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:27:22 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:27:56 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:28:01 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:28:16 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:28:21 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:28:28 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:28:33 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 04:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 387
ERROR - 2021-12-21 09:28:46 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:28:47 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:28:48 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:28:57 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 09:28:58 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:28:59 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:29:02 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:29:08 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:29:08 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 09:29:10 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:29:11 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:29:11 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:29:14 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:29:22 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:30:09 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:31:10 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:32:07 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:32:50 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:32:52 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 09:32:52 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:32:58 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 09:32:59 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:33:01 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:33:05 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:33:23 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:34:04 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:35:06 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:35:40 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:35:51 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:37:12 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:38:22 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:38:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:38:28 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:41:26 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:41:28 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:42:15 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:44:39 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:44:49 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:45:36 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:46:00 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:46:04 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:46:08 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 04:46:25 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 04:46:31 --> Severity: Notice --> Undefined offset: 15 /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 387
ERROR - 2021-12-21 04:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 387
ERROR - 2021-12-21 09:46:33 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:46:33 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:46:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:47:00 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:47:13 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:47:18 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:47:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 09:47:29 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:47:31 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:47:51 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:48:23 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:48:35 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:48:35 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:48:43 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-21 09:48:47 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 387
ERROR - 2021-12-21 09:48:50 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:48:54 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:49:01 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 09:49:02 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:03 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:05 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:08 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:20 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:28 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:35 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:49 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:49:52 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:50:09 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:50:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:50:40 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:50:57 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:51:27 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:51:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:51:47 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:51:48 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:52:07 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:52:15 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:52:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:52:48 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:53:12 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:53:31 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:53:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 09:53:41 --> 404 Page Not Found: /index
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 04:53:48 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 09:53:52 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:54:08 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:54:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:54:47 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:55:08 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:55:26 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:55:46 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:56:06 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:56:26 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:56:52 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:57:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:57:39 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:57:48 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:57:53 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:57:59 --> 404 Page Not Found: /index
ERROR - 2021-12-21 09:58:04 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:03:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:03:30 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:04:17 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 10:04:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 05:04:27 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 10:07:26 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:08:23 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:08:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 10:08:32 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:08:32 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:08:35 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:08:37 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:08:45 --> 404 Page Not Found: /index
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 05:09:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-21 10:09:40 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:10:18 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:12:36 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:13:21 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:16:13 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:16:30 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:21:32 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:21:44 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:23:29 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:23:32 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:30:11 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:30:42 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:30:51 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:30:53 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:30:54 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:31:10 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:31:45 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:33:11 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:33:30 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:34:57 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:35:00 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:39:27 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:39:36 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:39:39 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:39:41 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:39:46 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:42:13 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:42:22 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:42:26 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:42:29 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:44:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:44:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:44:24 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:44:53 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:44:55 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:45:25 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:48:12 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:48:15 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:48:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:20 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:24 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:29 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:32 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:37 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:39 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:44 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:46 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:49:49 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:50:51 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:50:53 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:52:48 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:53:05 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:53:16 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:53:24 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:53:48 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:56:41 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:56:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:56:46 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:58:00 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:58:38 --> 404 Page Not Found: /index
ERROR - 2021-12-21 10:58:52 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:01:27 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:01:31 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:17 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:21 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:33 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:35 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:37 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:39 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:42 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:45 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:48 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:03:59 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:05:32 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:05:37 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:05:40 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:05:43 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:06:40 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:07:27 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:07:31 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:07:34 --> 404 Page Not Found: /index
ERROR - 2021-12-21 11:10:42 --> 404 Page Not Found: /index
ERROR - 2021-12-21 06:21:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-21 13:15:16 --> 404 Page Not Found: /index
