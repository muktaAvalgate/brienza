<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-01 07:16:04 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:16:08 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:22:13 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:23:06 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-01 07:23:11 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:23:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-01 07:23:19 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-01 07:23:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-01 07:23:36 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-01 07:23:37 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:30:37 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:30:39 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:41 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:42 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:43 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:30:43 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:31:38 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:31:39 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:31:39 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:31:39 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:31:39 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:31:39 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:31:41 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:31:43 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:32:21 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:32:21 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:32:21 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:32:22 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:32:22 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 07:36:37 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:38:28 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:38:29 --> Query error: Column 'school_id' in where clause is ambiguous - Invalid query: SELECT `sessions`.`name`, `teachers`.`name` AS `teacher_name`
FROM `orders`
JOIN `teachers` ON `orders`.`school_id` = `teachers`.`school_id`
JOIN `sessions` ON `orders`.`session_id` = `sessions`.`id`
WHERE `school_id` = '14'
ERROR - 2022-09-01 07:38:32 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:38:33 --> Query error: Column 'school_id' in where clause is ambiguous - Invalid query: SELECT `sessions`.`name`, `teachers`.`name` AS `teacher_name`
FROM `orders`
JOIN `teachers` ON `orders`.`school_id` = `teachers`.`school_id`
JOIN `sessions` ON `orders`.`session_id` = `sessions`.`id`
WHERE `school_id` = '14'
ERROR - 2022-09-01 07:38:35 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:38:37 --> Query error: Column 'school_id' in where clause is ambiguous - Invalid query: SELECT `sessions`.`name`, `teachers`.`name` AS `teacher_name`
FROM `orders`
JOIN `teachers` ON `orders`.`school_id` = `teachers`.`school_id`
JOIN `sessions` ON `orders`.`session_id` = `sessions`.`id`
WHERE `school_id` = '24'
ERROR - 2022-09-01 07:47:52 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:47:54 --> Query error: Column 'school_id' in where clause is ambiguous - Invalid query: SELECT `sessions`.`name`, `teachers`.`name` AS `teacher_name`
FROM `orders`
JOIN `sessions` ON `orders`.`session_id` = `sessions`.`id`
JOIN `teachers` ON `orders`.`school_id` = `teachers`.`school_id`
WHERE `school_id` = '14'
ERROR - 2022-09-01 07:47:56 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:47:57 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:47:59 --> Query error: Column 'school_id' in where clause is ambiguous - Invalid query: SELECT `sessions`.`name`, `teachers`.`name` AS `teacher_name`
FROM `orders`
JOIN `sessions` ON `orders`.`session_id` = `sessions`.`id`
JOIN `teachers` ON `orders`.`school_id` = `teachers`.`school_id`
WHERE `school_id` = '24'
ERROR - 2022-09-01 07:48:03 --> 404 Page Not Found: /index
ERROR - 2022-09-01 07:48:40 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:01:48 --> Severity: Compile Error --> Cannot redeclare App_model::get_log_pdf_content() C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4753
ERROR - 2022-09-01 09:04:13 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:14 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-09-01 09:04:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-09-01 09:04:19 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:04:21 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:21 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:21 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:21 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:32 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:04:32 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:04:38 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:38 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:38 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:04:38 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 956
ERROR - 2022-09-01 09:06:23 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:06:23 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:08:32 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:08:33 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:13:10 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:13:11 --> 404 Page Not Found: /index
ERROR - 2022-09-01 09:13:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4737
ERROR - 2022-09-01 09:13:24 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4737
ERROR - 2022-09-01 09:30:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-01 09:30:24 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-01 09:33:17 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 09:33:43 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 09:33:48 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 09:34:06 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 09:34:25 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 09:35:47 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 10:09:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\presenter_billing.php 102
ERROR - 2022-09-01 10:10:27 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT), expecting ';' or ',' C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\presenter_billing.php 102
ERROR - 2022-09-01 11:42:59 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 12:16:48 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 12:16:55 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 12:17:14 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 12:17:25 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-09-01 12:43:07 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:43:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-01 12:43:22 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:43:22 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:43:34 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:43:34 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:49:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 952
ERROR - 2022-09-01 12:49:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-09-01 12:49:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:27 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4740
ERROR - 2022-09-01 12:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 952
ERROR - 2022-09-01 12:51:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 964
ERROR - 2022-09-01 12:51:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 965
ERROR - 2022-09-01 12:52:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:43 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:45 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:46 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:48 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:52:57 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4742
ERROR - 2022-09-01 12:53:22 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:53:23 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:53:28 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:53:28 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:53:30 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:53:30 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:53:48 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:54:19 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:54:20 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:54:20 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:54:21 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:54:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:54:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:54:31 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4748
ERROR - 2022-09-01 12:57:20 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4728
ERROR - 2022-09-01 12:57:21 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4728
ERROR - 2022-09-01 12:57:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4728
ERROR - 2022-09-01 12:57:28 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4728
ERROR - 2022-09-01 12:58:37 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:58:38 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:58:41 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:58:42 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:58:44 --> 404 Page Not Found: /index
ERROR - 2022-09-01 12:58:44 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:03:10 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:03:10 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 952
ERROR - 2022-09-01 13:09:10 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:09:10 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:09:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 952
ERROR - 2022-09-01 13:09:38 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:09:38 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:09:44 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:09:44 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:13:03 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:13:03 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-01 13:13:06 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `order_schedules`
WHERE `order_id` IN(Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
ERROR - 2022-09-01 13:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\system\core\Common.php 573
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:13 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:15:14 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:55 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:15:55 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:15:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4719
ERROR - 2022-09-01 13:16:57 --> Severity: error --> Exception: syntax error, unexpected '';' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4722
ERROR - 2022-09-01 13:17:02 --> Severity: error --> Exception: syntax error, unexpected '';' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4722
ERROR - 2022-09-01 13:17:07 --> Severity: error --> Exception: syntax error, unexpected '';' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4722
ERROR - 2022-09-01 13:17:09 --> Severity: error --> Exception: syntax error, unexpected '';' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4722
ERROR - 2022-09-01 13:17:26 --> 404 Page Not Found: /index
ERROR - 2022-09-01 13:17:26 --> 404 Page Not Found: /index
ERROR - 2022-09-01 14:55:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-01 14:55:23 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-01 14:55:38 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
