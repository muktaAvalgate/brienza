<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-11 15:38:44 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:40:39 --> 404 Page Not Found: /index
ERROR - 2021-12-11 10:40:40 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-11 15:40:43 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:40:49 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:41:20 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:41:45 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:41:47 --> 404 Page Not Found: /index
ERROR - 2021-12-11 10:41:50 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-11 15:41:51 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:42:02 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:42:15 --> 404 Page Not Found: /index
ERROR - 2021-12-11 15:42:22 --> 404 Page Not Found: /index
