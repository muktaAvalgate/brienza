<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-19 09:24:22 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:27:40 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:27:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-19 09:27:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:27:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:27:55 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:28:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-19 09:28:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-19 09:28:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:28:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:28:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-19 09:28:19 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-19 09:28:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:28:19 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:39:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:39:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:39:50 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:39:50 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:39:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:39:54 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:40:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:40:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 09:40:03 --> 404 Page Not Found: /index
ERROR - 2022-09-19 09:40:03 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:12:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:12:54 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:12:54 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:16:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:16:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:16:26 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:16:27 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:16:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:16:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:16:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:16:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:17 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:18 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:20 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:20 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:22 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:22 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:23 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:23 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:24 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:24 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:26 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:26 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:17:59 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-19 11:17:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-19 11:17:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:17:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:19:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:19:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:19:02 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:19:03 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:19:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:19:19 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:19:20 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:42 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:42 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:44 --> Severity: Notice --> Undefined variable: order_ids C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4929
ERROR - 2022-09-19 11:22:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:45 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:45 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:47 --> Severity: Notice --> Undefined variable: order_ids C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4929
ERROR - 2022-09-19 11:22:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:47 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:48 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:48 --> Severity: Notice --> Undefined variable: order_ids C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4929
ERROR - 2022-09-19 11:22:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:49 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:49 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:22:55 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-19 11:22:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-19 11:22:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:22:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:23:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:23:54 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:23:54 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:25:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:25:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:25:57 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:25:57 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:00 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:00 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:01 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:01 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:12 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:12 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:35 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:36 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:37 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:37 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:38 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:39 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:39 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:40 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:26:40 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:26:41 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:27:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:27:29 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:27:29 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:27:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:27:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:27:30 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:27:30 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:36 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:36 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:38 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:38 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:39 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:39 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:54 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:56 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:56 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:28:57 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:28:57 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:29:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:29:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:29:22 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:29:22 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:29:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:29:24 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:29:24 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:29:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:29:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:29:25 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:29:25 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:30:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:30:11 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:30:11 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:30:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:30:13 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:30:13 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:30:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:30:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:30:14 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:30:14 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:32:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:32:43 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:32:43 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:33:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:33:29 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:33:29 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:34:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:34:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:34:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:34:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:34:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:34:57 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:34:57 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:34:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:34:59 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:34:59 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:35:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:35:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:35:00 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:35:00 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:35:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:35:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:35:02 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:35:02 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:35:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:35:51 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:35:52 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:36:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:36:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:36:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:36:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:37:00 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:38:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:38:40 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:38:40 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:38:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:38:44 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:39:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:39:11 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:39:11 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:39:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:39:29 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:39:29 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:41:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:41:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:41:23 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:41:24 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:41:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:41:52 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:41:53 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:42:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:42:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:42:10 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:42:11 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:42:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:42:23 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:42:23 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:42:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:42:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:42:41 --> 404 Page Not Found: /index
ERROR - 2022-09-19 11:43:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:43:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 11:43:55 --> 404 Page Not Found: /index
ERROR - 2022-09-19 12:11:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 12:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 12:11:58 --> 404 Page Not Found: /index
ERROR - 2022-09-19 12:11:58 --> 404 Page Not Found: /index
ERROR - 2022-09-19 12:14:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 12:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 12:14:42 --> 404 Page Not Found: /index
ERROR - 2022-09-19 12:14:42 --> 404 Page Not Found: /index
ERROR - 2022-09-19 12:24:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 12:24:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 12:24:30 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:14:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:14:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:14:22 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:49:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-19 14:49:34 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-19 14:49:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:49:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:49:37 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-19 14:49:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-19 14:49:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:49:41 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:49:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-19 14:49:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-19 14:49:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:49:54 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:50:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:50:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:50:01 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:57:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:57:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:57:39 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:57:39 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:57:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:57:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-19 14:57:58 --> 404 Page Not Found: /index
ERROR - 2022-09-19 14:57:58 --> 404 Page Not Found: /index
