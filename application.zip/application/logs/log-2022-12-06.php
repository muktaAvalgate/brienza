<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-06 06:25:50 --> 404 Page Not Found: /index
ERROR - 2022-12-06 06:26:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-06 06:26:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-06 06:26:18 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-06 06:26:23 --> 404 Page Not Found: /index
ERROR - 2022-12-06 06:33:01 --> 404 Page Not Found: /index
ERROR - 2022-12-06 06:35:15 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-06 06:35:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-06 06:35:15 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 58
ERROR - 2022-12-06 06:35:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 58
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:44 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 06:58:59 --> Severity: Notice --> Undefined variable: template_topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 61
ERROR - 2022-12-06 06:58:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-06 07:12:04 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:15:29 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:16:58 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-12-06 07:16:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-12-06 07:17:46 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-06 07:28:59 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:29:59 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:30:27 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:35:57 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:36:01 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:37:19 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:37:51 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:38:40 --> 404 Page Not Found: /index
ERROR - 2022-12-06 07:41:58 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:06:01 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:41:36 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:41:52 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-06 08:41:55 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-06 08:41:56 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:42:08 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-12-06 08:42:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-12-06 08:42:09 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:59:31 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:59:34 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:59:49 --> 404 Page Not Found: /index
ERROR - 2022-12-06 08:59:58 --> 404 Page Not Found: /index
ERROR - 2022-12-06 09:03:22 --> 404 Page Not Found: /index
ERROR - 2022-12-06 09:03:33 --> 404 Page Not Found: /index
ERROR - 2022-12-06 09:03:37 --> 404 Page Not Found: /index
ERROR - 2022-12-06 09:03:45 --> 404 Page Not Found: /index
ERROR - 2022-12-06 09:58:32 --> 404 Page Not Found: /index
ERROR - 2022-12-06 10:05:21 --> 404 Page Not Found: /index
ERROR - 2022-12-06 10:05:24 --> 404 Page Not Found: /index
ERROR - 2022-12-06 10:26:45 --> 404 Page Not Found: /index
ERROR - 2022-12-06 11:36:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-06 11:36:23 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-06 11:36:25 --> 404 Page Not Found: /index
ERROR - 2022-12-06 11:36:38 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:12:16 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:12:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-06 12:12:37 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:12:55 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:13:03 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:13:04 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:30:22 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:33:14 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:34:33 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:35:46 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:42:16 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:42:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-06 12:42:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-06 12:42:33 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:42:38 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:42:48 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:42:54 --> 404 Page Not Found: /index
ERROR - 2022-12-06 12:43:18 --> 404 Page Not Found: /index
ERROR - 2022-12-06 13:34:55 --> 404 Page Not Found: /index
ERROR - 2022-12-06 13:35:38 --> 404 Page Not Found: /index
ERROR - 2022-12-06 13:38:26 --> 404 Page Not Found: /index
ERROR - 2022-12-06 14:05:00 --> 404 Page Not Found: /index
ERROR - 2022-12-06 14:05:05 --> 404 Page Not Found: /index
ERROR - 2022-12-06 14:05:05 --> 404 Page Not Found: /index
