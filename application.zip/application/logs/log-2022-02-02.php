<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-02 11:24:32 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:24:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-02 11:24:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-02 11:24:45 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:34:41 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:34:51 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-02 11:34:53 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:36:10 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:36:19 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:50:21 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:50:25 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:50:26 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:56:45 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:57:12 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:57:12 --> 404 Page Not Found: /index
ERROR - 2022-02-02 11:57:18 --> Severity: Notice --> Undefined variable: topicId C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 853
ERROR - 2022-02-02 12:08:15 --> 404 Page Not Found: /index
ERROR - 2022-02-02 12:08:16 --> 404 Page Not Found: /index
ERROR - 2022-02-02 12:22:53 --> 404 Page Not Found: /index
ERROR - 2022-02-02 12:22:53 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:13:17 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:13:18 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:13:54 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:13:55 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:28:19 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:28:19 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:28:57 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:28:57 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:28:58 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:28:59 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:42:02 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:42:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-02 13:42:12 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:42:21 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:42:23 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:42:56 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:43:03 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:43:03 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:43:05 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:43:05 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:43:50 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:52:22 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:53:09 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:53:15 --> 404 Page Not Found: /index
ERROR - 2022-02-02 13:53:17 --> 404 Page Not Found: /index
