<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-29 05:50:39 --> 404 Page Not Found: /index
ERROR - 2021-12-29 05:50:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 05:50:58 --> 404 Page Not Found: /index
ERROR - 2021-12-29 05:59:47 --> 404 Page Not Found: /index
ERROR - 2021-12-29 05:59:54 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:00:04 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:05:26 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:05:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:05:47 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:05:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:06:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:06:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:06:19 --> 404 Page Not Found: /index
ERROR - 2021-12-29 01:06:25 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-29 06:06:26 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:06:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 01:07:31 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-29 06:08:06 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:08:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 01:08:17 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-29 06:08:26 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:08:34 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:10:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:10:42 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:11:42 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:12:07 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:13:21 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:13:38 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:14:36 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:14:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:15:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:15:57 --> 404 Page Not Found: /index
ERROR - 2021-12-29 06:15:57 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:24:23 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:28:57 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:29:41 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:29:54 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:30:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:33:31 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:34:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:34:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:36:25 --> 404 Page Not Found: /index
ERROR - 2021-12-29 08:05:24 --> 404 Page Not Found: /index
ERROR - 2021-12-29 08:43:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 08:44:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:13:06 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:13:18 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:13:23 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:15:02 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:16:20 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:17:14 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:18:12 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:19:51 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:19:54 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:20:03 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:20:14 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:20:36 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:20:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:20:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:21:15 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:21:42 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:21:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:21:50 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:21:52 --> 404 Page Not Found: /index
ERROR - 2021-12-29 04:21:59 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-29 09:22:05 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:22:07 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:22:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 04:22:11 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-29 09:22:13 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:22:14 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:22:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:22:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:22:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:23:22 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:23:39 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:24:15 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:26:01 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:26:33 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:26:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:26:51 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:27:25 --> 404 Page Not Found: /index
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 04:27:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 09:27:47 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:27:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:28:23 --> 404 Page Not Found: /index
ERROR - 2021-12-29 04:28:42 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-29 09:29:17 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:29:18 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:29:23 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:29:24 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:29:42 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:29:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:29:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:30:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:30:07 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:30:16 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:30:24 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:30:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:30:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 04:30:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 09:31:03 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:31:31 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:31:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:41:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:42:34 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:42:52 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:43:08 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:43:54 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:44:02 --> 404 Page Not Found: /index
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 04:44:13 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 09:44:20 --> 404 Page Not Found: /index
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 04:44:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 09:44:35 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:44:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:45:47 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:46:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:46:18 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:46:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:46:57 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:47:23 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:47:39 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:49:26 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:49:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 09:50:22 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:01:20 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:01:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:04:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:04:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:04:54 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:05:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:05:39 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:05:40 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:06:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:07:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:07:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:08:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:08:47 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:08:47 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:10:41 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:10:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:07 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:23 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:27 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 05:11:42 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-29 10:11:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:51 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:11:57 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:12:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:12:12 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:03 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:06 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 05:13:18 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-29 10:13:19 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:41 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:13:58 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:15:01 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:15:07 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:15:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:15:51 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:25:55 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:28:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:35:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:36:05 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:36:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:36:13 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:45:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:45:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:45:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:45:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:45:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:48:12 --> 404 Page Not Found: /index
ERROR - 2021-12-29 10:50:35 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:15:47 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:16:06 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:17:14 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:18:53 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:18:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:03 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:18 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:18 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:21 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:27 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:29 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:42 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:19:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:20:14 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:21:06 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:21:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:21:26 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:21:58 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:21:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:22:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:22:13 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:22:14 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:23:29 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:23:32 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:23:55 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:23:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:24:06 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:24:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:24:21 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-29 12:24:22 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:24:24 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:24:53 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:25:24 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:25:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:25:38 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-29 12:25:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:25:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:25:50 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:26:06 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:26:25 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:26:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:27:03 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:27:05 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:27:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:27:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:27:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:28:01 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:28:04 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:28:18 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:28:31 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 07:28:39 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 12:28:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 07:28:50 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 12:29:03 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:29:51 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:30:22 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:30:41 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:31:12 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:31:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:31:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:31:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:31:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:32:32 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:39:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:49:31 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:54:01 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:55:21 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:55:25 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:55:49 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:56:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:56:13 --> 404 Page Not Found: /index
ERROR - 2021-12-29 07:56:18 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-29 12:56:24 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:56:25 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:56:28 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:56:32 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:56:34 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:56:51 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:57:12 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:57:28 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:57:31 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:57:34 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:57:39 --> 404 Page Not Found: /index
ERROR - 2021-12-29 12:59:59 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:00:05 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:00:13 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:00:19 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:00:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:00:38 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:00:49 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:00:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:01:04 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:01:27 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:05:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:06:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:06:56 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:09:10 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:09:44 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:10:23 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:10:25 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:10:30 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:10:33 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:32:00 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:32:21 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:32:41 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:33:17 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:33:40 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:34:05 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:34:24 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:34:27 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:34:34 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:34:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 08:35:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 13:35:13 --> 404 Page Not Found: /index
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 08:35:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-29 13:35:26 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:35:27 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:35:37 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:35:49 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:36:12 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:36:40 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:37:48 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:38:25 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:38:29 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:38:31 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:38:33 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:38:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:39:09 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:39:36 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:39:43 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:39:49 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:40:04 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:40:11 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:40:35 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:40:45 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:40:51 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:41:46 --> 404 Page Not Found: /index
ERROR - 2021-12-29 13:48:45 --> 404 Page Not Found: /index
