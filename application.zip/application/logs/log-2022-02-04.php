<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-04 10:22:12 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:32:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-04 10:32:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-04 10:32:35 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:32:37 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:35:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-04 10:35:50 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:38:37 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:38:43 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:38:48 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:47:55 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:47:57 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:48:07 --> 404 Page Not Found: /index
ERROR - 2022-02-04 10:48:10 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:01:01 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:01:03 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:01:47 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:04:09 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:37:10 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:37:15 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:37:20 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:39:38 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:39:44 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:39:49 --> Severity: Notice --> Undefined index: assign_titles C:\xampp\htdocs\brienza\application\modules\Admin\models\Admin_model.php 19
ERROR - 2022-02-04 11:40:00 --> 404 Page Not Found: /index
ERROR - 2022-02-04 11:40:02 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:35:17 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:38:32 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:46:20 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:46:51 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:47:11 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:47:27 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:47:37 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:47:56 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:48:04 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:51:09 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:51:14 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:51:21 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:51:33 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:52:05 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:52:13 --> 404 Page Not Found: /index
ERROR - 2022-02-04 12:52:25 --> 404 Page Not Found: /index
ERROR - 2022-02-04 13:02:58 --> 404 Page Not Found: /index
ERROR - 2022-02-04 13:03:26 --> Severity: Notice --> Undefined index: assign_titles C:\xampp\htdocs\brienza\application\modules\Admin\models\Admin_model.php 19
ERROR - 2022-02-04 13:03:50 --> 404 Page Not Found: /index
ERROR - 2022-02-04 13:04:01 --> Severity: Notice --> Undefined index: assign_titles C:\xampp\htdocs\brienza\application\modules\Admin\models\Admin_model.php 19
