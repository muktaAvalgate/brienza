<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-11 07:18:41 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:19:04 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:19:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-11 07:19:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-11 07:19:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:20:03 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-11 07:20:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-11 07:20:18 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-11 07:20:20 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:20:45 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:20:52 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:21:00 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:21:04 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:26:13 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:26:30 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:26:34 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:26:41 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:26:47 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:27:54 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:28:36 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:29:44 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:30:10 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:30:23 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 59
ERROR - 2022-08-11 07:35:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 59
ERROR - 2022-08-11 07:37:02 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:37:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:37:14 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:37:55 --> 404 Page Not Found: /index
ERROR - 2022-08-11 07:37:57 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:03:40 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:03:46 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:11:26 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:11:39 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:11:50 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:12:34 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:12:40 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:12:49 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:12:49 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:12:55 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:12:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:13:08 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:13:41 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:13:53 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:14:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:14:10 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:14:23 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:16:30 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:16:33 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:16:58 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:17:20 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:18:15 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:18:17 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:18:25 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:18:34 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:18:37 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:26:03 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:26:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:26:12 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:26:15 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:31:43 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:31:47 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:31:53 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:31:56 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:32:05 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:02 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:06 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:18 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:21 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:27 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:31 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:43 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:50:45 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:51:56 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:51:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:52:24 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:52:47 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:54:17 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:54:26 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:54:30 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:55:39 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:55:42 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:55:49 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:57:31 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:57:33 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:58:22 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:58:26 --> 404 Page Not Found: /index
ERROR - 2022-08-11 08:58:35 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:05:53 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:05:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:16:33 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:16:38 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:15 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:21 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:33 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:37 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:46 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:50 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:52 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:17:54 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:20:19 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:20:38 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:20:57 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:21:56 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:21:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:22:02 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:22:06 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:22:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:29:20 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:29:21 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:31:36 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:31:37 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:33:19 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:33:21 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:36:40 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:36:41 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:38:48 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:38:48 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:42:43 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:42:44 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:42:50 --> Severity: error --> Exception: Call to undefined method App_model::update_for_old_row() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 1931
ERROR - 2022-08-11 09:44:37 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:44:38 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:44:46 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:44:46 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:47:08 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:47:09 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:47:16 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:47:16 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:53:08 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:53:08 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:53:20 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:53:21 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:54:43 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:54:43 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:55:01 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:55:02 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:55:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:55:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:56:35 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:56:36 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:56:51 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:56:51 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:59:56 --> 404 Page Not Found: /index
ERROR - 2022-08-11 09:59:57 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:00:04 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:00:05 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:00:37 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:00:38 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:07:51 --> 404 Page Not Found: ../modules/App/controllers/Orders/C:
ERROR - 2022-08-11 10:14:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:00 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:10 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:11 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:11 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:12 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:12 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:27 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:15:33 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:16:04 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:17:34 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:17:35 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:17:40 --> 404 Page Not Found: /index
ERROR - 2022-08-11 10:17:40 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:18:47 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:20:24 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:20:32 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:20:45 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:20:49 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:20:52 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:21:46 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:21:50 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:21:58 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:24:53 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:24:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:25:00 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:25:08 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:25:08 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:26:42 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:26:43 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:27:16 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:27:16 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:27:58 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:28:21 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:28:24 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:28:35 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:28:39 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:28:46 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:28:49 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:31:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:31:18 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:31:22 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:31:48 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:32:10 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:32:52 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:32:55 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:33:04 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:33:37 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:33:46 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:33:49 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:33:51 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:34:59 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:35:07 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:35:11 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:35:21 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:45:54 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:47:32 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:47:39 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:47:39 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:49:12 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:49:12 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:50:03 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:50:03 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:52:14 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:52:15 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:52:29 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:52:35 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:53:56 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:53:58 --> 404 Page Not Found: /index
ERROR - 2022-08-11 11:54:13 --> 404 Page Not Found: /index
