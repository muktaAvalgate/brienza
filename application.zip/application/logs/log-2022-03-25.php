<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-25 06:21:54 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:22:12 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:22:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-25 06:22:24 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-25 06:22:25 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:23:31 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:23:34 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:25:11 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:25:59 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-25 06:26:02 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:30:49 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:30:52 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:31:23 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:31:51 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:34:16 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:34:20 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:36:49 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:38:32 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:39:47 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:49:10 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:57:17 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:57:27 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-25 06:57:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-25 06:57:29 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:58:05 --> 404 Page Not Found: /index
ERROR - 2022-03-25 06:58:07 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:33:55 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:34:57 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:36:00 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:37:41 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:39:07 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:43:57 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:45:11 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:46:40 --> 404 Page Not Found: /index
ERROR - 2022-03-25 07:50:06 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:00:42 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:01:20 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:09:29 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:11:08 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:12:24 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:13:01 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:13:31 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:17:05 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:20:51 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:20:52 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 485
ERROR - 2022-03-25 08:26:00 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:27:30 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:28:32 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:28:39 --> Severity: Notice --> Undefined variable: temp C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 494
ERROR - 2022-03-25 08:35:29 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:37:12 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:44:25 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:45:52 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:47:07 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:48:39 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:48:52 --> 404 Page Not Found: /index
ERROR - 2022-03-25 08:56:17 --> 404 Page Not Found: /index
ERROR - 2022-03-25 10:23:13 --> 404 Page Not Found: /index
ERROR - 2022-03-25 10:23:55 --> 404 Page Not Found: /index
ERROR - 2022-03-25 10:24:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-25 10:24:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-25 10:24:07 --> 404 Page Not Found: /index
