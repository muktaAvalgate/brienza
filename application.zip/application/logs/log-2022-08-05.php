<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-05 07:34:42 --> 404 Page Not Found: /index
ERROR - 2022-08-05 07:35:08 --> 404 Page Not Found: /index
ERROR - 2022-08-05 07:35:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-05 07:35:46 --> 404 Page Not Found: /index
ERROR - 2022-08-05 07:36:17 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-05 07:36:19 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-05 07:36:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-05 07:36:48 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-05 07:36:48 --> 404 Page Not Found: /index
ERROR - 2022-08-05 07:49:54 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:04:25 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:04:36 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:04:54 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:04:59 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:05:02 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:05:06 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:05:16 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:05:21 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:05:24 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:07:29 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-05 08:16:09 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:16:52 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:17:29 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:17:56 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:17:59 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:18:02 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:30:18 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-08-05 08:30:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-08-05 08:32:31 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-05 08:32:31 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:32:34 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:32:40 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:32:54 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:33:05 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:34:37 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:34:41 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:34:49 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:34:53 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:34:58 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:35:05 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:35:08 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:36:44 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:36:49 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:43:53 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:45:46 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:45:51 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:46:00 --> 404 Page Not Found: /index
ERROR - 2022-08-05 08:46:02 --> 404 Page Not Found: /index
ERROR - 2022-08-05 14:20:16 --> 404 Page Not Found: /index
ERROR - 2022-08-05 14:20:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-05 14:20:35 --> 404 Page Not Found: /index
ERROR - 2022-08-05 14:20:45 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-05 14:20:45 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-05 14:20:55 --> 404 Page Not Found: /index
ERROR - 2022-08-05 14:21:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-05 14:21:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-05 14:21:12 --> 404 Page Not Found: /index
