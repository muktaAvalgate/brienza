<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 11:55:03 --> 404 Page Not Found: /index
ERROR - 2022-02-17 11:55:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-17 11:55:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-17 11:55:14 --> 404 Page Not Found: /index
ERROR - 2022-02-17 11:56:29 --> 404 Page Not Found: /index
ERROR - 2022-02-17 11:56:35 --> 404 Page Not Found: /index
ERROR - 2022-02-17 11:57:59 --> 404 Page Not Found: /index
ERROR - 2022-02-17 11:58:53 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:00:37 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:08:58 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:14:51 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:17:38 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:31:21 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:31:54 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:34:18 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:34:41 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:35:05 --> 404 Page Not Found: /index
ERROR - 2022-02-17 12:48:55 --> 404 Page Not Found: /index
ERROR - 2022-02-17 13:52:30 --> 404 Page Not Found: /index
ERROR - 2022-02-17 13:55:21 --> 404 Page Not Found: /index
ERROR - 2022-02-17 14:13:16 --> 404 Page Not Found: /index
ERROR - 2022-02-17 14:13:19 --> 404 Page Not Found: /index
ERROR - 2022-02-17 14:13:20 --> 404 Page Not Found: /index
