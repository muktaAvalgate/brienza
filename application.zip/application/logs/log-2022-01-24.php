<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-24 10:32:44 --> 404 Page Not Found: /index
ERROR - 2022-01-24 10:52:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-24 10:52:50 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-24 10:52:50 --> 404 Page Not Found: /index
ERROR - 2022-01-24 10:52:59 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:17:00 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:17:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-24 11:17:38 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:17:54 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:23:10 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:23:12 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:24:35 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:36:38 --> 404 Page Not Found: /index
ERROR - 2022-01-24 11:36:38 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:12:46 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:12:47 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:12:57 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:12:57 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:13:27 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:13:27 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:13:59 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:14:00 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:14:04 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:14:05 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:30:46 --> 404 Page Not Found: /index
ERROR - 2022-01-24 12:30:55 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:04:03 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:04:18 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:08:46 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:08:50 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:08:53 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:18:36 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:18:42 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:18:45 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:19:19 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:20:32 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:21:15 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:22:04 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:22:33 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:23:51 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:24:22 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-01-24 13:24:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-01-24 13:24:30 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:25:44 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:26:29 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:26:43 --> 404 Page Not Found: /index
ERROR - 2022-01-24 13:27:13 --> 404 Page Not Found: /index
ERROR - 2022-01-24 14:08:54 --> 404 Page Not Found: /index
ERROR - 2022-01-24 14:09:04 --> 404 Page Not Found: /index
ERROR - 2022-01-24 14:09:33 --> 404 Page Not Found: /index
ERROR - 2022-01-24 14:09:42 --> 404 Page Not Found: /index
