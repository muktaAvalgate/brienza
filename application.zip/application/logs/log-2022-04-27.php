<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-27 08:03:55 --> 404 Page Not Found: /index
