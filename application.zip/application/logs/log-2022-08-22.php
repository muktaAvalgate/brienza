<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-22 08:04:58 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:05:20 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:05:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-22 08:05:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-22 08:06:01 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-22 08:06:04 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:06:13 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-22 08:06:14 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-22 08:06:15 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:06:29 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:06:46 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:11:19 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:11:31 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:51:12 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:51:14 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:51:14 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:51:14 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:51:15 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:51:46 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:51:47 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:52:11 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:52:35 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:36 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:36 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 5004
ERROR - 2022-08-22 08:53:56 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:54:11 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:55:00 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:55:49 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:55:50 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-22 08:55:51 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:56:00 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:56:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:56:16 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:56:23 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:56:31 --> 404 Page Not Found: /index
ERROR - 2022-08-22 08:56:33 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:03:34 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:03:58 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:04:11 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-22 09:05:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-22 09:05:22 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:05:30 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:05:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:06:24 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:06:32 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:08:23 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:08:26 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:10:42 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:41:38 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:44:24 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:44:27 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:44:35 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:44:37 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:45:29 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:45:33 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:45:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:45:56 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:49:36 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:49:39 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:49:44 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:50:05 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:50:09 --> 404 Page Not Found: /index
ERROR - 2022-08-22 09:50:12 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:05:31 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:05:44 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:07:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:07:37 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:07:42 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:07:54 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:07:57 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:09:25 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:09:27 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:09:38 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:09:47 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:10:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:10:16 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:10:21 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:10:31 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:10:37 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:10:39 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:23:35 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:25:27 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:27:52 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:40:19 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:40:21 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:40:46 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:51:32 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> Severity: Notice --> Undefined index: Teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:56:34 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 11:59:04 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:59:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 11:59:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:43 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:00:44 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:00:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> Severity: Notice --> Undefined index: teacher_Report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:03:21 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:03:22 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:12:54 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:12:54 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:13:44 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:13:44 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:15:49 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:15:49 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 162
ERROR - 2022-08-22 12:19:03 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:19:03 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:21:27 --> Severity: Notice --> Undefined variable: render_action C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 135
ERROR - 2022-08-22 12:21:27 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:21:27 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:24:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:24:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:28:06 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:28:06 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:32 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:30:32 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:30:52 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:30:53 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:34:27 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:34:28 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:35:08 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:35:09 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:39:12 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:39:12 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:41:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:41:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:42:29 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:42:30 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:43:46 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:43:58 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:43:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:46:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:46:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:02 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:48:02 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:48:15 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:48:15 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:03 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:49:03 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:49:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:49:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:52:08 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:52:09 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:53:22 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:53:22 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:57:46 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:57:46 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:58:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:58:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 12:59:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 12:59:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:41 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:00:41 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:00:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:00:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:33 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:34 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:01:34 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:01:48 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:01:48 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:05 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:02:05 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:17 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:02:17 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:02:37 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:02:37 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:05 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:06 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:03:06 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:32 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:03:32 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:03:49 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:03:49 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:23 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:23 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:36 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:36 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:04:53 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:04:54 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:11 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:11 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:29 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:30 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:35 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:35 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:05:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:05:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:11 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:06:12 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:06:25 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:06:26 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:08:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:08:13 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:09:44 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:09:54 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:09:54 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:10:37 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:10:41 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:10:42 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:11:35 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:11:36 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:24 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:12:25 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:12:25 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:02 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:13:02 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:13:28 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:13:29 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:01 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:27:01 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:27:54 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:27:55 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 13:29:25 --> 404 Page Not Found: /index
ERROR - 2022-08-22 13:29:26 --> 404 Page Not Found: /index
ERROR - 2022-08-22 14:08:47 --> 404 Page Not Found: /index
ERROR - 2022-08-22 14:08:47 --> 404 Page Not Found: /index
ERROR - 2022-08-22 14:28:25 --> 404 Page Not Found: /index
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 14:28:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 14:28:45 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:06:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:06:59 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:07:29 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:07:29 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:08:36 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:08:36 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:11:15 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:16 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:11:16 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:11:35 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:11:35 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:12:04 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:12:05 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-22 15:17:07 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:17:07 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:23:14 --> 404 Page Not Found: /index
ERROR - 2022-08-22 15:23:14 --> 404 Page Not Found: /index
