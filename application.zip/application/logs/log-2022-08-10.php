<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-10 07:34:30 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:35:00 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:35:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 07:35:14 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:35:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 07:35:42 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-10 07:36:11 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:36:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 07:36:21 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-10 07:36:22 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:39:37 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:40:16 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:40:22 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:40:25 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:52:10 --> 404 Page Not Found: /index
ERROR - 2022-08-10 07:52:13 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:12:18 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:12:34 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:18:05 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:18:44 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:18:46 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:19:10 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:19:11 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:19:12 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:19:43 --> 404 Page Not Found: /index
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-08-10 08:26:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-08-10 11:24:59 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 11:25:01 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-10 11:26:42 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:27:00 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 11:27:02 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:27:11 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:27:16 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:27:35 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:27:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 11:27:50 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-10 11:27:51 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:27:59 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:28:03 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:28:08 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:28:23 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:29:27 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:29:37 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:29:43 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:31:46 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:33:41 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:33:50 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:34:20 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:34:26 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:34:42 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:34:45 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:34:48 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:34:50 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:34:56 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:35:04 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:35:06 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:35:08 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:37:01 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:37:16 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:37:28 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:38:12 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:38:15 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:38:35 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:38:42 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:38:47 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:38:50 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:38:59 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:39:01 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:39:52 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:39:56 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:40:09 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:41:12 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:41:15 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:41:17 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:41:21 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:41:50 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:42:26 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:42:27 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:42:33 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:42:44 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:42:54 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:45:04 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:45:55 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:46:09 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:46:11 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:47:34 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:47:40 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:47:43 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:47:54 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:51:59 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:52:21 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:52:25 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:52:38 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:52:49 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:56:41 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:56:43 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:56:46 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:56:53 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:57:03 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:57:05 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:57:53 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:57:56 --> 404 Page Not Found: /index
ERROR - 2022-08-10 11:58:09 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:11:12 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:11:16 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:12:12 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:12:21 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:12:32 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:12:43 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:13:54 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:13:57 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:14:03 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:14:15 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:14:18 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:14:52 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:14:55 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:15:06 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:25:35 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:25:38 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:25:40 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:25:44 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:25:47 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:25:57 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:26:03 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:26:10 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:26:12 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:27:21 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:27:24 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:27:37 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:27:46 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:29:20 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:29:42 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:29:56 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:29:59 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:30:34 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:30:37 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:30:45 --> 404 Page Not Found: /index
ERROR - 2022-08-10 12:54:18 --> 404 Page Not Found: /index
ERROR - 2022-08-10 13:48:15 --> 404 Page Not Found: /index
ERROR - 2022-08-10 14:55:09 --> 404 Page Not Found: /index
ERROR - 2022-08-10 14:55:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 14:55:25 --> 404 Page Not Found: /index
ERROR - 2022-08-10 14:55:32 --> 404 Page Not Found: /index
ERROR - 2022-08-10 14:55:40 --> 404 Page Not Found: /index
ERROR - 2022-08-10 14:56:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-10 14:56:22 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-10 14:56:34 --> 404 Page Not Found: /index
ERROR - 2022-08-10 14:56:38 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:24:36 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:24:43 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:24:49 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:24:57 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:24:59 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:02 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:05 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:07 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:10 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:17 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:20 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:22 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:23 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:25 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:26 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:28 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:30 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:32 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:52 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:25:55 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:26:00 --> 404 Page Not Found: /index
ERROR - 2022-08-10 15:26:06 --> 404 Page Not Found: /index
