<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-24 06:12:01 --> 404 Page Not Found: /index
