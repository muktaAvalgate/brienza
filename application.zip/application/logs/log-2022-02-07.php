<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-07 10:54:09 --> 404 Page Not Found: /index
ERROR - 2022-02-07 10:55:24 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-07 10:55:25 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-07 10:55:26 --> 404 Page Not Found: /index
ERROR - 2022-02-07 10:56:15 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:06:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-07 12:06:57 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:10:36 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:10:41 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:10:48 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:10:50 --> Severity: Notice --> Undefined property: stdClass::$grade_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-07 12:10:50 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-07 12:10:50 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-07 12:10:50 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:11:12 --> Severity: Notice --> Undefined property: stdClass::$grade_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-07 12:11:12 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-07 12:11:12 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-07 12:11:12 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:13:41 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:14:53 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:15:16 --> 404 Page Not Found: /index
ERROR - 2022-02-07 12:56:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-07 12:56:11 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:38:56 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:39:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-07 13:39:11 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:39:20 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:39:31 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:40:06 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:54:02 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:54:15 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:54:39 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:55:06 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:55:18 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:55:41 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:55:41 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:55:52 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:55:52 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:56:13 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:56:13 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:56:40 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:56:40 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:56:59 --> 404 Page Not Found: /index
ERROR - 2022-02-07 13:56:59 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:00:02 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:00:03 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:00:13 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:00:13 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:00:32 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:00:37 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:00:42 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:01:47 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:01:59 --> 404 Page Not Found: /index
ERROR - 2022-02-07 14:02:09 --> 404 Page Not Found: /index
