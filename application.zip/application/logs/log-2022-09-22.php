<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-22 07:27:23 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:27:50 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:27:52 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:28:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-22 07:28:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:28:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:28:25 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:29:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-22 07:29:58 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-22 07:29:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:29:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:30:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-22 07:30:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-22 07:30:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:30:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:30:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:30:43 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:40:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:40:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:14 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:40:15 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:40:18 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 07:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 07:40:18 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 07:40:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 07:40:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:40:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:19 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:40:32 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 07:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 07:40:32 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 07:40:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 07:40:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:40:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:33 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:40:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:40:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:40:39 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:51:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:51:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:51:16 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:51:17 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:51:18 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 07:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 07:51:18 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 07:51:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 07:51:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:51:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:51:18 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:51:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:51:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:51:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:51:20 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:53:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:53:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:53:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:54:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:54:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:54:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:54:08 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-22 07:57:41 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 8
ERROR - 2022-09-22 07:57:41 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 11
ERROR - 2022-09-22 07:57:41 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 24
ERROR - 2022-09-22 07:57:41 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 38
ERROR - 2022-09-22 07:57:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:57:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:57:41 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 07:57:41 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:58:26 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 8
ERROR - 2022-09-22 07:58:26 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 11
ERROR - 2022-09-22 07:58:26 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 24
ERROR - 2022-09-22 07:58:26 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 38
ERROR - 2022-09-22 07:58:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:58:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:58:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:58:26 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 07:58:26 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:59:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:59:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:59:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:59:32 --> 404 Page Not Found: /index
ERROR - 2022-09-22 07:59:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 07:59:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:59:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 07:59:41 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:01:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:01:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:01:34 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:03:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:03:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:03:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:03:27 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:03:27 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:13:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:13:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:13:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:13:51 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:13:51 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:14:01 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:14:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:14:01 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:14:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:14:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:14:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:01 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:14:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:14:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:02 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:14:03 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:14:03 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:14:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:14:03 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:14:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:04 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:14:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:14:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:14:10 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:14:11 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:15:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:15:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:15:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:15:37 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:15:37 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:16:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:16:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:19 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:16:19 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:16:25 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:16:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:16:25 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:16:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:16:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:16:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:26 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:16:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:16:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:30 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:16:30 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:16:35 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:16:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-22 08:16:35 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:16:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-22 08:16:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:16:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:35 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:16:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:16:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:16:42 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:16:42 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:17:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:17:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:17:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:17:16 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:17:16 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:17:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:17:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:17:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:17:37 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:17:37 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:18:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:18:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:18:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:18:10 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:18:10 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:18:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:18:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:18:34 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:18:34 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:19:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:19:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:19:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:19:30 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:19:30 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:20:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:20:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:20:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:20:23 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:20:23 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:23:25 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 7
ERROR - 2022-09-22 08:23:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:23:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:23:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:23:26 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:23:26 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:41:41 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_templates.php 7
ERROR - 2022-09-22 08:41:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:41:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:41:43 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:41:43 --> 404 Page Not Found: /index
ERROR - 2022-09-22 08:42:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 08:42:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 08:42:22 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-22 08:42:22 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:25:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-22 11:25:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-22 11:25:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:25:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:25:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:25:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:25:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:36 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:25:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-22 11:25:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:25:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:25:59 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:26:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:26:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:08 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:26:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:26:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:10 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:26:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:26:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:30 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:26:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:26:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:26:36 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:27:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:28:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:28:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:28:47 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:29:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:29:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:29:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:29:21 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:29:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 11:29:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 11:29:27 --> 404 Page Not Found: /index
ERROR - 2022-09-22 11:57:21 --> Severity: Notice --> Undefined variable: order_ids C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4765
ERROR - 2022-09-22 12:21:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:22:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:22:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:22:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:22:10 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:22:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:22:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:22:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:22:15 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:23:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:23:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:23:25 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:23:35 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:24:15 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:24:22 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:24:35 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:24:38 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:24:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:24:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:24:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:24:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:26:14 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-09-22 12:26:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-09-22 12:26:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:26:16 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-22 12:26:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:40:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:40:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:40:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:41:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:41:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:41:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:41:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:41:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:41:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:41:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:03 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:42:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 12:42:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 12:51:29 --> 404 Page Not Found: /index
ERROR - 2022-09-22 12:51:32 --> 404 Page Not Found: /index
ERROR - 2022-09-22 14:24:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 14:24:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 14:24:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:24:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:24:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 14:25:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 14:25:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:25:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:25:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 14:25:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 14:25:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:25:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:53:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 14:53:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:53:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 14:53:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 15:05:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 15:05:07 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-09-22 15:05:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-09-22 15:05:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:05:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:05:08 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-22 15:05:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 15:05:17 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-09-22 15:05:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-09-22 15:05:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:05:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:05:17 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-22 15:05:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 15:07:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 15:07:21 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-09-22 15:07:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-09-22 15:07:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:07:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:07:22 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-22 15:08:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 15:10:09 --> 404 Page Not Found: /index
ERROR - 2022-09-22 15:10:14 --> 404 Page Not Found: /index
ERROR - 2022-09-22 15:10:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-22 15:10:22 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-09-22 15:10:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-09-22 15:10:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:10:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-22 15:10:22 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-22 15:10:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
