<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-16 07:26:32 --> 404 Page Not Found: /index
ERROR - 2022-09-16 07:28:39 --> 404 Page Not Found: /index
ERROR - 2022-09-16 07:31:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-16 07:31:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:31:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:32:00 --> 404 Page Not Found: /index
ERROR - 2022-09-16 07:32:23 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-16 07:32:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-16 07:32:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:32:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-16 07:32:40 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-16 07:32:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:32:40 --> 404 Page Not Found: /index
ERROR - 2022-09-16 07:34:29 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:34:29 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:34:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:34:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:46:19 --> Severity: Compile Error --> Cannot redeclare App_model::get_school_name() C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-16 07:46:41 --> Severity: Compile Error --> Cannot redeclare App_model::get_school_name() C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-16 07:47:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-16 07:47:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:47:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:47:36 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:47:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:47:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:47:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:49:39 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:49:39 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:49:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:49:40 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:49:40 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:49:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:49:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:49:42 --> Severity: Notice --> Undefined index: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4977
ERROR - 2022-09-16 07:51:11 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:51:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:51:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:51:12 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:51:12 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:51:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:51:14 --> Severity: Notice --> Undefined variable: presenter_id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4870
ERROR - 2022-09-16 07:51:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `user_meta`.`meta_key` = 'school_name'' at line 3 - Invalid query: SELECT `user_meta`.`meta_value` as `school_name`
FROM `user_meta`
JOIN `orders` ON `user_meta`.`user_id` = `orders`.`school_id` AND `orders`.`presenter_id` =   AND `user_meta`.`meta_key` = 'school_name'
ERROR - 2022-09-16 07:52:26 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:52:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:52:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:52:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:52:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:52:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:52:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:52:29 --> Severity: error --> Exception: Too few arguments to function App_model::get_school_name_for_provider(), 1 passed in C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php on line 2361 and exactly 2 expected C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-16 07:53:35 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:53:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:53:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:53:36 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:53:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 07:53:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:53:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 07:53:38 --> Query error: Unknown column 'school_name' in 'on clause' - Invalid query: SELECT `user_meta`.`meta_value` as `school_name`
FROM `user_meta`
JOIN `orders` ON `user_meta`.`user_id` = `orders`.`school_id` AND `orders`.`presenter_id` = `school_name` AND `user_meta`.`meta_key` = 'school_name'
ERROR - 2022-09-16 08:08:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:08:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:08:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:08:28 --> Severity: Notice --> Undefined index: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4977
ERROR - 2022-09-16 08:10:35 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:10:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:10:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:10:37 --> Severity: Notice --> Undefined index: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4977
ERROR - 2022-09-16 08:11:13 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:11:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:11:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:11:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:11:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:11:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:11:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:14:07 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:14:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:14:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:14:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:14:17 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:14:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:14:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:17:30 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:17:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:17:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:04 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:04 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:08 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:28 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:32 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:19:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:20:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:20:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:20:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:20:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:20:32 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:20:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:20:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:20:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:24:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:24:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:24:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:24:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:24:29 --> Severity: error --> Exception: Call to undefined method App_model::get_school_name_for_provider() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2361
ERROR - 2022-09-16 08:25:02 --> Severity: error --> Exception: Call to undefined method App_model::get_school_name_for_provider() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2361
ERROR - 2022-09-16 08:25:03 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:25:03 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:25:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:25:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:25:05 --> Severity: error --> Exception: Call to undefined method App_model::get_school_name_for_provider() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2361
ERROR - 2022-09-16 08:27:39 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:27:39 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:27:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:27:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:27:41 --> Severity: error --> Exception: Call to undefined method App_model::get_school_name_for_provider() C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4979
ERROR - 2022-09-16 08:28:11 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:13 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4980
ERROR - 2022-09-16 08:28:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:23 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4980
ERROR - 2022-09-16 08:28:25 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:29 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4980
ERROR - 2022-09-16 08:28:45 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:28:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:32:10 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:32:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:32:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:32:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:33:37 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:33:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:33:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:33:49 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:33:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:33:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:33:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-16 08:33:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-16 08:33:53 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:33:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:33:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:33:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-16 08:33:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-16 08:33:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-16 08:34:48 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:34:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:34:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:37:54 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:37:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:37:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:37:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:50:44 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:50:44 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:50:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:50:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:55:55 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:55:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:55:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:55:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:57:51 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:57:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:57:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:57:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:59:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:59:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 08:59:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:59:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 08:59:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4992
ERROR - 2022-09-16 08:59:58 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4992
ERROR - 2022-09-16 08:59:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4992
ERROR - 2022-09-16 08:59:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4992
ERROR - 2022-09-16 08:59:59 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4992
ERROR - 2022-09-16 08:59:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4992
ERROR - 2022-09-16 09:00:09 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:00:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:00:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:00:11 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:00:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:00:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:00:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:02:31 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:02:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:02:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:02:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:02:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php:2363) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-16 09:02:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php:2363) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-16 09:06:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:06:09 --> 404 Page Not Found: /index
ERROR - 2022-09-16 09:06:10 --> 404 Page Not Found: /index
ERROR - 2022-09-16 09:26:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php:2363) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-16 09:26:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php:2363) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-16 09:26:51 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:26:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:26:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:26:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:26:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php:2363) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-16 09:26:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php:2363) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-16 09:30:42 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:30:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 09:30:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 09:30:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:22:45 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:22:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:22:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:22:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:22:51 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:23:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-16 11:23:08 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-16 11:23:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:23:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:23:08 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:23:23 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:23:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-16 11:23:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:23:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:23:38 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:25:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:25:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:25:18 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:25:57 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:26:51 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:28:46 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:29:07 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:29:10 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:29:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:29:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:30:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:30:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:30:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:30:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:30:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:30:30 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:30:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:30:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:30:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:31:53 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:32:01 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:33:22 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:33:24 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:33:38 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:33:42 --> 404 Page Not Found: /index
ERROR - 2022-09-16 11:34:06 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:34:06 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:34:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:34:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:34:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 11:34:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:35:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:35:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:35:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:35:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:35:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 11:35:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:23:48 --> Severity: Notice --> Undefined variable: grade_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4977
ERROR - 2022-09-16 12:23:48 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4977
ERROR - 2022-09-16 12:23:52 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:23:52 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:23:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:23:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:23:53 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:23:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:23:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:23:54 --> Severity: Notice --> Undefined variable: grade_name C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4977
ERROR - 2022-09-16 12:23:54 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4977
ERROR - 2022-09-16 12:24:24 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:24:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:24:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:24:52 --> Severity: Notice --> Undefined index: $resultArray C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4992
ERROR - 2022-09-16 12:45:26 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:45:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-16 12:45:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-16 12:45:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
