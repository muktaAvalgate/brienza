<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-28 05:47:37 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:51:18 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:51:43 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-28 05:51:47 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:51:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-28 05:51:56 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-28 05:51:56 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:53:47 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:53:58 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:58:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-28 05:58:56 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-28 05:59:11 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:59:34 --> 404 Page Not Found: /index
ERROR - 2022-01-28 05:59:34 --> 404 Page Not Found: /index
ERROR - 2022-01-28 06:08:52 --> 404 Page Not Found: /index
ERROR - 2022-01-28 06:08:59 --> 404 Page Not Found: /index
ERROR - 2022-01-28 06:09:01 --> 404 Page Not Found: /index
ERROR - 2022-01-28 06:09:05 --> 404 Page Not Found: /index
ERROR - 2022-01-28 06:10:59 --> 404 Page Not Found: /index
ERROR - 2022-01-28 08:25:12 --> 404 Page Not Found: /index
ERROR - 2022-01-28 08:26:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-28 08:26:06 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-28 08:26:07 --> 404 Page Not Found: /index
ERROR - 2022-01-28 08:26:08 --> 404 Page Not Found: /index
ERROR - 2022-01-28 08:26:13 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:15:34 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:15:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-28 12:15:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-28 12:15:43 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:23:39 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:23:42 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:39:49 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:39:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-28 12:39:59 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:40:33 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:40:41 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:41:16 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:41:19 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:41:55 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:45:03 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:45:14 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:45:20 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:45:23 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:46:08 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:46:46 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:47:33 --> 404 Page Not Found: /index
ERROR - 2022-01-28 12:52:02 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:01:39 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:01:39 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:02:33 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:02:34 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:11:00 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:11:01 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:16:26 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:16:26 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:16:26 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:16:26 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:16:27 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:22:03 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:22:03 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:22:06 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:22:06 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:22:06 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:22:06 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:23:40 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:23:40 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:57:41 --> 404 Page Not Found: /index
ERROR - 2022-01-28 13:57:42 --> 404 Page Not Found: /index
