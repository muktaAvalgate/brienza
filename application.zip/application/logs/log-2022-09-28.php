<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-28 07:24:50 --> 404 Page Not Found: /index
ERROR - 2022-09-28 07:25:01 --> 404 Page Not Found: /index
ERROR - 2022-09-28 07:25:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-28 07:25:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 07:25:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:25:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:25:35 --> 404 Page Not Found: /index
ERROR - 2022-09-28 07:25:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-28 07:25:47 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-28 07:25:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 07:25:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:26:05 --> 404 Page Not Found: /index
ERROR - 2022-09-28 07:26:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-28 07:26:18 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-28 07:26:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 07:26:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:26:20 --> 404 Page Not Found: /index
ERROR - 2022-09-28 07:33:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 07:33:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:33:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:33:49 --> 404 Page Not Found: /index
ERROR - 2022-09-28 07:35:49 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-28 07:35:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-28 07:35:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 07:35:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:35:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:40:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 07:40:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:40:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:40:46 --> 404 Page Not Found: /index
ERROR - 2022-09-28 07:46:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 07:46:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:46:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 07:46:23 --> 404 Page Not Found: /index
ERROR - 2022-09-28 14:24:37 --> 404 Page Not Found: /index
ERROR - 2022-09-28 14:24:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-28 14:24:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 14:24:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 14:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 14:24:48 --> 404 Page Not Found: /index
ERROR - 2022-09-28 14:24:56 --> 404 Page Not Found: /index
ERROR - 2022-09-28 14:25:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-09-28 14:25:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 14:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-09-28 14:25:00 --> 404 Page Not Found: /index
