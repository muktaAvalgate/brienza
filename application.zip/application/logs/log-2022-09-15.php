<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-15 07:33:19 --> 404 Page Not Found: /index
ERROR - 2022-09-15 07:33:23 --> 404 Page Not Found: /index
ERROR - 2022-09-15 07:34:14 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-15 07:34:16 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-15 07:34:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-15 07:34:31 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-15 07:34:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-15 07:34:44 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-15 07:35:54 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-15 07:36:15 --> Severity: error --> Exception: syntax error, unexpected '<', expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-15 07:36:28 --> Severity: error --> Exception: syntax error, unexpected '<', expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-15 07:36:29 --> Severity: error --> Exception: syntax error, unexpected '<', expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-15 07:38:51 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-15 07:38:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:38:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:38:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:38:55 --> 404 Page Not Found: /index
ERROR - 2022-09-15 07:38:57 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-15 07:38:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:38:57 --> 404 Page Not Found: /index
ERROR - 2022-09-15 07:39:05 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:39:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:39:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:39:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:39:06 --> 404 Page Not Found: ../modules/App/controllers/Presenters/export_teacher_report_from_provider
ERROR - 2022-09-15 07:39:08 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:39:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:39:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:41:53 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-15 07:46:15 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:46:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:46:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:51:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4886
ERROR - 2022-09-15 07:51:09 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:51:26 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:51:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:51:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:51:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:51:28 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:51:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:51:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:51:30 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4886
ERROR - 2022-09-15 07:51:30 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:57:57 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:57:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:57:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:57:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:57:59 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 07:58:00 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:58:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:58:03 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:58:03 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:58:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:58:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:58:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 07:58:05 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:58:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:58:06 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:58:06 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:58:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:08 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 07:59:09 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:59:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:59:11 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:38 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:38 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:40 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 07:59:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 07:59:41 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:59:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 07:59:43 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 07:59:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 07:59:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:01:14 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:01:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:01:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:01:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:01:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 08:01:16 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 08:01:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 08:01:24 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:01:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:01:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:01:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:03:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:03:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:03:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:03:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:06:45 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:06:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:06:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:06:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:06:47 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:06:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:06:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:06:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:25:59 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:25:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:25:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:25:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:26:01 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:26:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:26:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:26:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: school_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 08:26:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 08:26:03 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 08:26:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 08:26:05 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:26:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:26:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:29:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:29:32 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:30:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:30:48 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:30:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:30:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:30:58 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:31:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:01 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:31:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:29 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:31:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:32 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:31:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:52 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:31:55 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:31:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:31:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:32:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:32:32 --> 404 Page Not Found: /index
ERROR - 2022-09-15 08:43:25 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:43:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:43:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:43:28 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:43:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:43:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:43:43 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:43:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 08:43:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:43:45 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 08:45:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 08:45:15 --> 404 Page Not Found: /index
ERROR - 2022-09-15 09:04:30 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:04:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:04:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:04:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2361
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:04:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 09:04:32 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 09:04:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 09:05:20 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:05:20 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:05:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:05:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:05:22 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 09:08:32 --> 404 Page Not Found: /index
ERROR - 2022-09-15 09:08:32 --> 404 Page Not Found: /index
ERROR - 2022-09-15 09:16:09 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:16:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:16:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2361
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-15 09:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-15 09:16:11 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 09:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 09:16:12 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:16:12 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:16:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:16:30 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:16:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:16:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:16:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:16:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2361
ERROR - 2022-09-15 09:17:27 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:17:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:17:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:17:29 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:17:29 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:17:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:17:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:17:30 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 09:17:57 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:17:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:17:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:17:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:17:58 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-15 09:44:51 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:44:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:44:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:44:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:47:50 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:47:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:47:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:47:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:47:51 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:47:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:47:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:47:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:51:32 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:51:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:51:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:51:40 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:51:40 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:51:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:51:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:58:30 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:58:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:58:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:58:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:58:46 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:58:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 09:58:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 09:58:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:11:28 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:11:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:11:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:19:35 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:19:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:19:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:19:54 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:19:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:19:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:19:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:20:51 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:20:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 10:20:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 10:20:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:09:43 --> Query error: Unknown column 'orders.school_id' in 'on clause' - Invalid query: SELECT `order_schedules`.*, `Order`.`session_id` AS `session_id`, `user_meta`.`meta_value` as `school_name`, `Order`.`school_id` AS `school_id`
FROM `order_schedules`
JOIN `orders` AS `Order` ON `Order`.`id` = `order_schedules`.`order_id`
JOIN `user_meta` ON `user_meta`.`user_id` = `orders`.`school_id` AND `orders`.`presenter_id` = 15 AND `user_meta`.`meta_key` = 'school_name'
WHERE `order_schedules`.`order_id` IN('2', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '289', '293', '294', '295', '298', '299', '300', '301', '302', '303', '304', '382', '383', '401', '410', '671', '672', '673', '675', '676', '677', '678', '679', '681', '684', '685', '686', '687', '688', '689', '691', '693', '694', '695', '696', '697', '698', '699', '701', '702', '703', '704', '705', '706', '707', '708', '709', '710', '711', '712', '713', '714', '715', '716', '717', '720', '721', '723', '724', '725', '726', '727', '728', '729', '730', '731', '732', '733', '734', '735', '736', '737', '738', '739', '740', '741', '742', '743', '744', '745', '746')
AND `Order`.`presenter_id` = '15'
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-15 12:09:45 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:09:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:09:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:09:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:09:47 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:09:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:09:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:09:49 --> Query error: Unknown column 'orders.school_id' in 'on clause' - Invalid query: SELECT `order_schedules`.*, `Order`.`session_id` AS `session_id`, `user_meta`.`meta_value` as `school_name`, `Order`.`school_id` AS `school_id`
FROM `order_schedules`
JOIN `orders` AS `Order` ON `Order`.`id` = `order_schedules`.`order_id`
JOIN `user_meta` ON `user_meta`.`user_id` = `orders`.`school_id` AND `orders`.`presenter_id` = 15 AND `user_meta`.`meta_key` = 'school_name'
WHERE `order_schedules`.`order_id` IN('2', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '289', '293', '294', '295', '298', '299', '300', '301', '302', '303', '304', '382', '383', '401', '410', '671', '672', '673', '675', '676', '677', '678', '679', '681', '684', '685', '686', '687', '688', '689', '691', '693', '694', '695', '696', '697', '698', '699', '701', '702', '703', '704', '705', '706', '707', '708', '709', '710', '711', '712', '713', '714', '715', '716', '717', '720', '721', '723', '724', '725', '726', '727', '728', '729', '730', '731', '732', '733', '734', '735', '736', '737', '738', '739', '740', '741', '742', '743', '744', '745', '746')
AND `Order`.`presenter_id` = '15'
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-15 12:10:12 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:10:12 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:10:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:12:57 --> Query error: Unknown column 'orders.school_id' in 'on clause' - Invalid query: SELECT `order_schedules`.*, `Order`.`session_id` AS `session_id`, `user_meta`.`meta_value` as `school_name`, `Order`.`school_id` AS `school_id`
FROM `order_schedules`
JOIN `orders` AS `Order` ON `Order`.`id` = `order_schedules`.`order_id`
JOIN `user_meta` ON `user_meta`.`user_id` = `orders`.`school_id` AND `orders`.`presenter_id` = 15 AND `user_meta`.`meta_key` = 'school_name'
WHERE `order_schedules`.`order_id` IN('2', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '289', '293', '294', '295', '298', '299', '300', '301', '302', '303', '304', '382', '383', '401', '410', '671', '672', '673', '675', '676', '677', '678', '679', '681', '684', '685', '686', '687', '688', '689', '691', '693', '694', '695', '696', '697', '698', '699', '701', '702', '703', '704', '705', '706', '707', '708', '709', '710', '711', '712', '713', '714', '715', '716', '717', '720', '721', '723', '724', '725', '726', '727', '728', '729', '730', '731', '732', '733', '734', '735', '736', '737', '738', '739', '740', '741', '742', '743', '744', '745', '746')
AND `Order`.`presenter_id` = '15'
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-15 12:14:12 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:14:12 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:14:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:14:14 --> Query error: Unknown column 'Orders.school_id' in 'on clause' - Invalid query: SELECT `order_schedules`.*, `Order`.`session_id` AS `session_id`, `user_meta`.`meta_value` as `school_name`, `Order`.`school_id` AS `school_id`
FROM `order_schedules`
JOIN `orders` AS `Order` ON `Order`.`id` = `order_schedules`.`order_id`
JOIN `user_meta` ON `user_meta`.`user_id` = `Orders`.`school_id` AND `Orders`.`presenter_id` = 15 AND `user_meta`.`meta_key` = 'school_name'
WHERE `order_schedules`.`order_id` IN('2', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '289', '293', '294', '295', '298', '299', '300', '301', '302', '303', '304', '382', '383', '401', '410', '671', '672', '673', '675', '676', '677', '678', '679', '681', '684', '685', '686', '687', '688', '689', '691', '693', '694', '695', '696', '697', '698', '699', '701', '702', '703', '704', '705', '706', '707', '708', '709', '710', '711', '712', '713', '714', '715', '716', '717', '720', '721', '723', '724', '725', '726', '727', '728', '729', '730', '731', '732', '733', '734', '735', '736', '737', '738', '739', '740', '741', '742', '743', '744', '745', '746')
AND `Order`.`presenter_id` = '15'
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-15 12:14:19 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:14:19 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 12:14:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 12:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:13:37 --> 404 Page Not Found: /index
ERROR - 2022-09-15 13:13:50 --> 404 Page Not Found: /index
ERROR - 2022-09-15 13:14:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-15 13:14:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:14:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:14:07 --> 404 Page Not Found: /index
ERROR - 2022-09-15 13:15:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:15:17 --> 404 Page Not Found: /index
ERROR - 2022-09-15 13:18:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:18:39 --> 404 Page Not Found: /index
ERROR - 2022-09-15 13:18:44 --> 404 Page Not Found: /index
ERROR - 2022-09-15 13:32:43 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 13:32:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 13:32:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:32:45 --> Query error: Unknown column 'Orders.school_id' in 'on clause' - Invalid query: SELECT `order_schedules`.*, `Order`.`session_id` AS `session_id`, `user_meta`.`meta_value` as `school_name`, `Order`.`school_id` AS `school_id`
FROM `orders` AS `Order`
JOIN `order_schedules` ON `Order`.`id` = `order_schedules`.`order_id`
JOIN `user_meta` ON `user_meta`.`user_id` = `Orders`.`school_id` AND `Orders`.`presenter_id` = 15 AND `user_meta`.`meta_key` = 'school_name'
WHERE `order_schedules`.`order_id` IN('2', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '289', '293', '294', '295', '298', '299', '300', '301', '302', '303', '304', '382', '383', '401', '410', '671', '672', '673', '675', '676', '677', '678', '679', '681', '684', '685', '686', '687', '688', '689', '691', '693', '694', '695', '696', '697', '698', '699', '701', '702', '703', '704', '705', '706', '707', '708', '709', '710', '711', '712', '713', '714', '715', '716', '717', '720', '721', '723', '724', '725', '726', '727', '728', '729', '730', '731', '732', '733', '734', '735', '736', '737', '738', '739', '740', '741', '742', '743', '744', '745', '746')
AND `Order`.`presenter_id` = '15'
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-15 13:33:41 --> Query error: Unknown column 'orders.school_id' in 'on clause' - Invalid query: SELECT `order_schedules`.*, `Order`.`session_id` AS `session_id`, `user_meta`.`meta_value` as `school_name`, `Order`.`school_id` AS `school_id`
FROM `orders` AS `Order`
JOIN `order_schedules` ON `Order`.`id` = `order_schedules`.`order_id`
JOIN `user_meta` ON `user_meta`.`user_id` = `orders`.`school_id` AND `orders`.`presenter_id` = 15 AND `user_meta`.`meta_key` = 'school_name'
WHERE `order_schedules`.`order_id` IN('2', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '289', '293', '294', '295', '298', '299', '300', '301', '302', '303', '304', '382', '383', '401', '410', '671', '672', '673', '675', '676', '677', '678', '679', '681', '684', '685', '686', '687', '688', '689', '691', '693', '694', '695', '696', '697', '698', '699', '701', '702', '703', '704', '705', '706', '707', '708', '709', '710', '711', '712', '713', '714', '715', '716', '717', '720', '721', '723', '724', '725', '726', '727', '728', '729', '730', '731', '732', '733', '734', '735', '736', '737', '738', '739', '740', '741', '742', '743', '744', '745', '746')
AND `Order`.`presenter_id` = '15'
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-15 13:33:42 --> Query error: Unknown column 'orders.school_id' in 'on clause' - Invalid query: SELECT `order_schedules`.*, `Order`.`session_id` AS `session_id`, `user_meta`.`meta_value` as `school_name`, `Order`.`school_id` AS `school_id`
FROM `orders` AS `Order`
JOIN `order_schedules` ON `Order`.`id` = `order_schedules`.`order_id`
JOIN `user_meta` ON `user_meta`.`user_id` = `orders`.`school_id` AND `orders`.`presenter_id` = 15 AND `user_meta`.`meta_key` = 'school_name'
WHERE `order_schedules`.`order_id` IN('2', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '289', '293', '294', '295', '298', '299', '300', '301', '302', '303', '304', '382', '383', '401', '410', '671', '672', '673', '675', '676', '677', '678', '679', '681', '684', '685', '686', '687', '688', '689', '691', '693', '694', '695', '696', '697', '698', '699', '701', '702', '703', '704', '705', '706', '707', '708', '709', '710', '711', '712', '713', '714', '715', '716', '717', '720', '721', '723', '724', '725', '726', '727', '728', '729', '730', '731', '732', '733', '734', '735', '736', '737', '738', '739', '740', '741', '742', '743', '744', '745', '746')
AND `Order`.`presenter_id` = '15'
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-15 13:34:44 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 13:34:44 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 13:34:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 13:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 15:29:02 --> 404 Page Not Found: /index
ERROR - 2022-09-15 15:29:45 --> Severity: Compile Error --> Cannot redeclare App_model::get_school_name() C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-15 15:29:47 --> Severity: Compile Error --> Cannot redeclare App_model::get_school_name() C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4866
ERROR - 2022-09-15 15:29:47 --> 404 Page Not Found: /index
ERROR - 2022-09-15 15:29:47 --> 404 Page Not Found: /index
ERROR - 2022-09-15 15:30:06 --> 404 Page Not Found: /index
ERROR - 2022-09-15 15:30:12 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 15:30:12 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-15 15:30:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 15:30:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 15:30:20 --> 404 Page Not Found: /index
ERROR - 2022-09-15 15:30:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-15 15:30:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 15:30:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 15:30:42 --> 404 Page Not Found: /index
ERROR - 2022-09-15 15:30:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 15:30:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-15 15:30:46 --> 404 Page Not Found: /index
