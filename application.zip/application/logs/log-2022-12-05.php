<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-05 06:25:31 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:26:16 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:26:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-05 06:26:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-05 06:31:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-05 06:31:52 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:33:39 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:34:11 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:34:35 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:34:39 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:34:52 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:38:38 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:39:19 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:39:25 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:39:41 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:39:52 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 06:41:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 06:42:53 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:42:53 --> 404 Page Not Found: /index
ERROR - 2022-12-05 06:42:55 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:37:56 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:37:56 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:37:58 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:38:06 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:38:10 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:38:15 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:38:18 --> 404 Page Not Found: /index
ERROR - 2022-12-05 07:38:21 --> 404 Page Not Found: /index
ERROR - 2022-12-05 08:31:41 --> 404 Page Not Found: /index
ERROR - 2022-12-05 08:31:41 --> 404 Page Not Found: /index
ERROR - 2022-12-05 08:31:43 --> 404 Page Not Found: /index
ERROR - 2022-12-05 09:52:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-05 09:52:36 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 111
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 111
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 115
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 115
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-12-05 09:56:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-12-05 10:23:37 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-05 10:23:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-05 10:31:51 --> 404 Page Not Found: /index
ERROR - 2022-12-05 10:32:04 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-05 10:32:06 --> 404 Page Not Found: /index
ERROR - 2022-12-05 10:32:08 --> 404 Page Not Found: /index
ERROR - 2022-12-05 10:32:08 --> 404 Page Not Found: /index
ERROR - 2022-12-05 10:32:10 --> 404 Page Not Found: /index
ERROR - 2022-12-05 10:32:11 --> 404 Page Not Found: /index
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-05 10:58:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-05 11:26:33 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2896
ERROR - 2022-12-05 11:26:47 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2896
ERROR - 2022-12-05 11:28:20 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2896
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:28:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:28:52 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2896
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:29:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:29:38 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2894
ERROR - 2022-12-05 11:30:49 --> Severity: error --> Exception: Call to undefined method App_model::get_brienza_template() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 1815
ERROR - 2022-12-05 11:30:51 --> Severity: error --> Exception: Call to undefined method App_model::get_brienza_template() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 1815
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5640
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: topic_id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5640
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:31:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:31:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:31:35 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2896
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:31:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:31:55 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2896
ERROR - 2022-12-05 11:36:34 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2896
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 60
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 75
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 117
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 11:39:00 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-12-05 12:17:55 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-05 12:17:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-05 12:22:07 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-05 12:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-12-05 12:22:07 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 58
ERROR - 2022-12-05 12:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 58
ERROR - 2022-12-05 12:38:08 --> 404 Page Not Found: /index
ERROR - 2022-12-05 12:38:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-05 12:38:24 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-05 12:38:25 --> 404 Page Not Found: /index
ERROR - 2022-12-05 12:38:28 --> 404 Page Not Found: /index
ERROR - 2022-12-05 12:38:31 --> 404 Page Not Found: /index
ERROR - 2022-12-05 12:38:33 --> 404 Page Not Found: /index
ERROR - 2022-12-05 12:38:35 --> 404 Page Not Found: /index
ERROR - 2022-12-05 12:38:40 --> 404 Page Not Found: /index
