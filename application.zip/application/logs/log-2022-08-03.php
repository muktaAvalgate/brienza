<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-03 07:17:17 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:19:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 07:19:24 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:20:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 07:20:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-03 07:26:32 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:26:40 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:27:02 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:27:06 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:27:21 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:32:20 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:32:24 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:34:01 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:34:09 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:34:12 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:35:49 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:36:14 --> Severity: Warning --> require_once(Mail.php): failed to open stream: No such file or directory C:\xampp\htdocs\brienza_backup\application\libraries\Mail_template.php 3
ERROR - 2022-08-03 07:36:14 --> Severity: Compile Error --> require_once(): Failed opening required 'Mail.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\brienza_backup\application\libraries\Mail_template.php 3
ERROR - 2022-08-03 07:36:22 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:36:38 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:36:59 --> Severity: Warning --> require_once(Mail.php): failed to open stream: No such file or directory C:\xampp\htdocs\brienza_backup\application\libraries\Mail_template.php 3
ERROR - 2022-08-03 07:36:59 --> Severity: Compile Error --> require_once(): Failed opening required 'Mail.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\brienza_backup\application\libraries\Mail_template.php 3
ERROR - 2022-08-03 07:37:21 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:37:44 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:37:57 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:38:23 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:38:33 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:38:50 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:38:54 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:39:10 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:39:21 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:40:54 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:41:01 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:41:19 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:41:32 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:49:59 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:51:42 --> 404 Page Not Found: /index
ERROR - 2022-08-03 07:51:54 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:02:52 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 56
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 56
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 08:03:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 08:41:20 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:41:23 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:49:26 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:49:29 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 08:53:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 08:55:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 08:55:50 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:56:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 08:56:47 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-03 08:57:25 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:57:32 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:57:38 --> 404 Page Not Found: /index
ERROR - 2022-08-03 08:58:29 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 08:58:29 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-03 08:58:44 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-08-03 08:58:49 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-08-03 08:58:53 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-08-03 08:59:06 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-08-03 09:02:59 --> 404 Page Not Found: /index
ERROR - 2022-08-03 09:03:15 --> 404 Page Not Found: /index
ERROR - 2022-08-03 09:03:40 --> 404 Page Not Found: /index
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 09:03:48 --> 404 Page Not Found: /index
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 09:03:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 09:14:43 --> 404 Page Not Found: /index
ERROR - 2022-08-03 09:14:47 --> 404 Page Not Found: /index
ERROR - 2022-08-03 11:18:27 --> 404 Page Not Found: /index
ERROR - 2022-08-03 11:19:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 11:19:05 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-03 11:19:05 --> 404 Page Not Found: /index
ERROR - 2022-08-03 11:19:11 --> 404 Page Not Found: /index
ERROR - 2022-08-03 11:19:20 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 12:09:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 12:15:00 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:15:33 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 12:15:35 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:15:49 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:15:52 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:16:19 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:16:42 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:16:49 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:16:54 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:16:59 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:17:04 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:29:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 12:29:48 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-03 12:29:52 --> Severity: Notice --> Undefined index: principal_name C:\xampp\htdocs\brienza_backup\application\modules\Admin\views\users\profile.php 73
ERROR - 2022-08-03 12:30:04 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-03 12:30:13 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-03 12:30:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-03 12:32:44 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:32:47 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:54:33 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:54:41 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:55:07 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:55:51 --> Severity: Notice --> Undefined index: profile_pic C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 334
ERROR - 2022-08-03 12:55:53 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:55:57 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:56:04 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:56:08 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:56:11 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:56:23 --> Severity: Notice --> Undefined index: profile_pic C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 334
ERROR - 2022-08-03 12:56:25 --> 404 Page Not Found: /index
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 57
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 58
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 62
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 66
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 12:57:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 12:58:51 --> 404 Page Not Found: /index
ERROR - 2022-08-03 14:19:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 65
ERROR - 2022-08-03 14:19:36 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 65
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 65
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 65
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-08-03 14:20:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
