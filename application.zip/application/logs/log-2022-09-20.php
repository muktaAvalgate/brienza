<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-20 07:27:22 --> 404 Page Not Found: /index
ERROR - 2022-09-20 07:28:53 --> 404 Page Not Found: /index
ERROR - 2022-09-20 07:29:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-20 07:30:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 07:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 07:30:01 --> 404 Page Not Found: /index
ERROR - 2022-09-20 07:30:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-20 07:30:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-20 07:30:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 07:30:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 07:30:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-20 07:30:31 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-20 07:30:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 07:30:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 07:30:32 --> 404 Page Not Found: /index
ERROR - 2022-09-20 07:30:59 --> 404 Page Not Found: /index
ERROR - 2022-09-20 07:54:52 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-20 07:54:52 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-20 07:54:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 07:54:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:22:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:22:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:22:33 --> 404 Page Not Found: /index
ERROR - 2022-09-20 08:26:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:26:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:26:19 --> 404 Page Not Found: /index
ERROR - 2022-09-20 08:26:27 --> 404 Page Not Found: /index
ERROR - 2022-09-20 08:26:34 --> 404 Page Not Found: /index
ERROR - 2022-09-20 08:26:50 --> 404 Page Not Found: /index
ERROR - 2022-09-20 08:27:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:27:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:27:27 --> 404 Page Not Found: /index
ERROR - 2022-09-20 08:27:27 --> 404 Page Not Found: /index
ERROR - 2022-09-20 08:35:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 08:35:35 --> 404 Page Not Found: /index
ERROR - 2022-09-20 09:31:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 09:31:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 11:00:51 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-20 11:00:53 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-20 11:00:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 11:00:59 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-20 11:00:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-20 11:00:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 11:00:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 11:02:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 11:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 12:01:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 12:01:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 12:49:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 12:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 12:49:19 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-20 12:54:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-20 12:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
