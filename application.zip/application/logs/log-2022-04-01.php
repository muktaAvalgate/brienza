<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-01 07:10:22 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:10:25 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:11:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-01 07:11:20 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-01 07:11:21 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:11:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-01 07:11:32 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:26:04 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:33:34 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:43:34 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:58:15 --> 404 Page Not Found: /index
ERROR - 2022-04-01 07:58:17 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:06:42 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:23:17 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:23:29 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:23:38 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:23:42 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:23:51 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-01 08:23:54 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:26:50 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:28:08 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:29:23 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:30:59 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:31:43 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:32:05 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:32:59 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:33:03 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:33:35 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:33:40 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:34:01 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:39:10 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:41:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-01 08:41:55 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-01 08:41:58 --> Severity: Notice --> Undefined variable: purchase_orders C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-04-01 08:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-04-01 08:42:51 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:53:16 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:53:19 --> 404 Page Not Found: /index
ERROR - 2022-04-01 08:53:36 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:05:28 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:05:50 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:33:56 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:34:07 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:36:16 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:36:29 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:36:33 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:36:37 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:46:21 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:46:42 --> 404 Page Not Found: /index
ERROR - 2022-04-01 09:47:03 --> 404 Page Not Found: /index
ERROR - 2022-04-01 11:13:01 --> 404 Page Not Found: /index
ERROR - 2022-04-01 11:13:06 --> 404 Page Not Found: /index
ERROR - 2022-04-01 11:13:22 --> 404 Page Not Found: /index
ERROR - 2022-04-01 11:21:14 --> 404 Page Not Found: /index
ERROR - 2022-04-01 11:21:15 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:18:23 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:18:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-01 13:18:39 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:18:53 --> 404 Page Not Found: /index
ERROR - 2022-04-01 13:19:16 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:03:05 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:03:11 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:03:11 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:03:47 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:03:47 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:03:57 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:03:57 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:04:41 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:04:41 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:04:52 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:04:52 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:06:31 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:06:31 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:06:48 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:06:48 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:07:01 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:07:01 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:07:09 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:07:10 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:07:18 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:07:18 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:13:24 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:13:28 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:13:28 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:13:49 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:13:49 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:18:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-01 14:18:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-01 14:34:00 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:34:00 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:34:18 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:34:18 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:34:24 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:34:24 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:35:12 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:35:12 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:35:31 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:35:31 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:41:00 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:41:10 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:41:45 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:41:51 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:42:22 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:42:23 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:46:04 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:48:56 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:49:41 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:49:57 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:50:01 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:50:13 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:53:43 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:53:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-01 14:53:56 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-01 14:53:57 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:53:59 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:54:02 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:54:04 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:54:05 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:54:15 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:54:51 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:54:52 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:55:49 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:56:01 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:56:05 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:56:08 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:57:30 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:58:02 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:58:09 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:59:11 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:59:17 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:59:28 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:59:33 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:59:43 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:59:44 --> 404 Page Not Found: /index
ERROR - 2022-04-01 14:59:50 --> 404 Page Not Found: /index
ERROR - 2022-04-01 15:00:02 --> 404 Page Not Found: /index
ERROR - 2022-04-01 15:00:04 --> 404 Page Not Found: /index
ERROR - 2022-04-01 15:00:23 --> 404 Page Not Found: /index
