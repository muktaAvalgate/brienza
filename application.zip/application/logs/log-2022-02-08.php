<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-08 11:05:13 --> 404 Page Not Found: /index
ERROR - 2022-02-08 11:08:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-08 11:08:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-08 11:08:10 --> 404 Page Not Found: /index
ERROR - 2022-02-08 11:08:17 --> 404 Page Not Found: /index
ERROR - 2022-02-08 11:08:18 --> Severity: Notice --> Undefined property: stdClass::$grade_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 11:08:18 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 11:08:18 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 11:08:18 --> 404 Page Not Found: /index
ERROR - 2022-02-08 11:38:54 --> Severity: Notice --> Undefined property: stdClass::$grade_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 11:38:54 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 11:38:54 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 11:38:54 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:50:53 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza\system\core\Common.php 407
ERROR - 2022-02-08 13:51:12 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:51:12 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:51:20 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza\system\core\Common.php 407
ERROR - 2022-02-08 13:52:46 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:52:57 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:53:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-08 13:53:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-08 13:53:13 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:53:13 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:53:16 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:53:16 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:53:18 --> Severity: Notice --> Undefined property: stdClass::$grade_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 13:53:18 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 13:53:18 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-02-08 13:53:19 --> 404 Page Not Found: /index
ERROR - 2022-02-08 13:53:19 --> 404 Page Not Found: /index
