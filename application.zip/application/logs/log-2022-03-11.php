<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-11 06:10:40 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:03:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-11 10:03:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-11 10:03:13 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:03:23 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:04:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-11 10:04:05 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:04:13 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:05:53 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:05:57 --> Severity: Notice --> Undefined property: stdClass::$grade_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-03-11 10:05:57 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-03-11 10:05:57 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-03-11 10:05:57 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:11:34 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:12:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-11 10:12:16 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-11 10:43:45 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:43:49 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:43:51 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:43:54 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:44:01 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:45:37 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:46:31 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:48:57 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:48:58 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:49:00 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:49:52 --> Severity: Notice --> Undefined variable: topic_id C:\xampp\htdocs\brienza\application\modules\App\models\App_model.php 4453
ERROR - 2022-03-11 10:49:52 --> Query error: Column 'grade_id' cannot be null - Invalid query: INSERT INTO `teachers` (`school_id`, `title_id`, `grade_id`, `created_by`) VALUES ('14', '78', NULL, '15')
ERROR - 2022-03-11 10:50:42 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:54:30 --> 404 Page Not Found: /index
ERROR - 2022-03-11 10:55:41 --> 404 Page Not Found: /index
ERROR - 2022-03-11 11:01:05 --> 404 Page Not Found: /index
ERROR - 2022-03-11 11:01:26 --> 404 Page Not Found: /index
ERROR - 2022-03-11 11:01:51 --> 404 Page Not Found: /index
ERROR - 2022-03-11 11:02:43 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:22:03 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:22:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-11 13:22:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-11 13:22:13 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:22:17 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:22:31 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:22:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-11 13:22:44 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:22:59 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:24:44 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:24:55 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:24:59 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:41:10 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:41:14 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:02 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:08 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:11 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:14 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:17 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:20 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:23 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:27 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:29 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:31 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:33 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:45 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:47 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:50 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:54 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:43:56 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:44:00 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:44:34 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:44:53 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:47:49 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:47:54 --> 404 Page Not Found: /index
ERROR - 2022-03-11 13:54:37 --> 404 Page Not Found: /index
ERROR - 2022-03-11 14:01:49 --> 404 Page Not Found: /index
