<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-12 07:32:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-12 07:32:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-12 07:33:02 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:33:09 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:33:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-12 07:33:20 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:33:32 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:33:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-12 07:33:40 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-12 07:33:41 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:34:10 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:34:13 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:45:27 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:06 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:12 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:19 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:24 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:38 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:45 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:51 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:46:56 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:47:02 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:47:06 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:47:49 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-12 07:53:11 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:53:14 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:53:37 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:53:52 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-12 07:54:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-12 07:55:06 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:55:09 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:55:29 --> 404 Page Not Found: /index
ERROR - 2022-08-12 07:55:35 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:16:22 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:16:26 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:17:07 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:17:16 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:17:47 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:17:50 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:17:55 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:18:00 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:18:08 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:18:10 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:18:13 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:18:15 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:24:56 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:31:36 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:31:48 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:31:59 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:36:32 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:43:27 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:43:36 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:43:40 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:44:09 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:45:45 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:46:14 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:46:54 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:47:04 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:48:05 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:48:13 --> 404 Page Not Found: /index
ERROR - 2022-08-12 08:48:28 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:17:07 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:17:10 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:41:09 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:51:31 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:55:01 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:57:25 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:57:40 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:57:48 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:57:50 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:57:52 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:57:54 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:57:56 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:58:06 --> 404 Page Not Found: /index
ERROR - 2022-08-12 09:58:08 --> 404 Page Not Found: /index
ERROR - 2022-08-12 10:00:27 --> 404 Page Not Found: /index
ERROR - 2022-08-12 10:00:33 --> 404 Page Not Found: /index
ERROR - 2022-08-12 10:00:33 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:11:01 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:11:12 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:11:14 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:12:34 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:12:55 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:13:09 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:13:50 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:13:52 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:13:54 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:14:01 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:14:03 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:14:08 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:14:42 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:14:50 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:14:57 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:15:10 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:15:22 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:16:32 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:16:58 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:17:11 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:17:17 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:17:20 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:17:20 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:17:21 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:23:49 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:23:50 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:24:06 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:24:10 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:24:17 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:26:45 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:27:00 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:27:23 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:27:34 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:29:05 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:29:09 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:29:25 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:29:51 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:29:59 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:31:28 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:32:20 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:32:22 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:32:26 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:32:36 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:37:40 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:37:52 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:37:55 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:47:22 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:47:24 --> 404 Page Not Found: /index
ERROR - 2022-08-12 11:47:28 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:20:54 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:20:57 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:29:27 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:29:35 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:29:37 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:29:39 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:29:41 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:29:43 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:43:28 --> 404 Page Not Found: /index
ERROR - 2022-08-12 12:43:31 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:13:42 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:14:12 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:14:37 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:14:42 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:14:57 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:15:00 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:15:06 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:16:03 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:16:07 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:16:18 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:16:30 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:18:04 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:18:10 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:18:53 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:18:53 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:19:02 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:19:03 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:07 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:11 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:15 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:21 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:21 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:32 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:32 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:50 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:21:50 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:22:08 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:22:43 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:22:43 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:22:54 --> 404 Page Not Found: /index
ERROR - 2022-08-12 13:22:54 --> 404 Page Not Found: /index
