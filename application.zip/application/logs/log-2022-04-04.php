<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-04 07:07:49 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:36:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-04 07:36:49 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-04 07:36:51 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:38:59 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:39:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-04 07:39:10 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:40:53 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:41:23 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:42:28 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:42:35 --> 404 Page Not Found: /index
ERROR - 2022-04-04 07:43:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-04 07:43:37 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-04 08:18:42 --> 404 Page Not Found: /index
ERROR - 2022-04-04 08:18:45 --> 404 Page Not Found: /index
ERROR - 2022-04-04 08:18:58 --> 404 Page Not Found: /index
ERROR - 2022-04-04 09:28:42 --> 404 Page Not Found: /index
ERROR - 2022-04-04 11:26:23 --> 404 Page Not Found: /index
ERROR - 2022-04-04 11:26:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-04 11:26:34 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-04 11:26:34 --> 404 Page Not Found: /index
ERROR - 2022-04-04 11:26:38 --> 404 Page Not Found: /index
ERROR - 2022-04-04 11:26:43 --> 404 Page Not Found: /index
ERROR - 2022-04-04 11:26:45 --> 404 Page Not Found: /index
ERROR - 2022-04-04 11:26:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-04 11:26:55 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-04 11:43:22 --> 404 Page Not Found: /index
ERROR - 2022-04-04 11:43:38 --> 404 Page Not Found: /index
ERROR - 2022-04-04 12:01:05 --> 404 Page Not Found: /index
ERROR - 2022-04-04 12:01:07 --> 404 Page Not Found: /index
ERROR - 2022-04-04 12:10:07 --> 404 Page Not Found: /index
ERROR - 2022-04-04 12:10:07 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:22:43 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:22:43 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:24:23 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:24:23 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:24:25 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:24:26 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:24:58 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:24:58 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:25:04 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:25:04 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:32:19 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:32:19 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:32:50 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:32:50 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:33:00 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:33:01 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:33:54 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:33:54 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:57:18 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:57:18 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:57:20 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:57:20 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:58:23 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:58:23 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:58:25 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:58:35 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:58:35 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:59:27 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:59:28 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:59:49 --> 404 Page Not Found: /index
ERROR - 2022-04-04 13:59:49 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:00:33 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:00:34 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:00:50 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:01:07 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:07:27 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:07:43 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:33:43 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:33:50 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:33:50 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:37:51 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:37:51 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:37:53 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:37:53 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:38:12 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:38:12 --> 404 Page Not Found: /index
ERROR - 2022-04-04 14:38:36 --> Severity: Notice --> Undefined variable: session_to C:\xampp\htdocs\brienza\application\modules\App\models\App_model.php 4490
ERROR - 2022-04-04 14:39:00 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:21:02 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:21:30 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:22:49 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:23:09 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:23:09 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:24:26 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:24:26 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:24:30 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:24:30 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:24:48 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:24:48 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:26:50 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:26:50 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:26:52 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:26:52 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:27:28 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:27:28 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:27:29 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:27:29 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:32:05 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:32:06 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:32:08 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:32:09 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:33:00 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:33:01 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:33:17 --> 404 Page Not Found: /index
ERROR - 2022-04-04 15:33:36 --> 404 Page Not Found: /index
