<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-16 11:38:16 --> 404 Page Not Found: /index
ERROR - 2022-02-16 11:56:23 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-16 11:56:27 --> 404 Page Not Found: /index
ERROR - 2022-02-16 11:57:38 --> 404 Page Not Found: /index
ERROR - 2022-02-16 11:58:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-16 11:58:35 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-16 11:58:35 --> 404 Page Not Found: /index
ERROR - 2022-02-16 12:14:22 --> 404 Page Not Found: /index
ERROR - 2022-02-16 12:17:21 --> 404 Page Not Found: /index
ERROR - 2022-02-16 13:31:32 --> 404 Page Not Found: /index
ERROR - 2022-02-16 13:48:29 --> 404 Page Not Found: /index
ERROR - 2022-02-16 13:48:53 --> 404 Page Not Found: /index
ERROR - 2022-02-16 13:56:52 --> 404 Page Not Found: /index
ERROR - 2022-02-16 13:57:37 --> 404 Page Not Found: /index
ERROR - 2022-02-16 13:57:46 --> 404 Page Not Found: /index
ERROR - 2022-02-16 13:58:11 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:07:35 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:11:07 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:11:21 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:11:21 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:17:47 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:17:47 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:19:18 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:19:19 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:35:54 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:35:55 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:41:49 --> 404 Page Not Found: /index
ERROR - 2022-02-16 14:41:50 --> 404 Page Not Found: /index
