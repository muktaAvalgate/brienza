<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-13 08:16:08 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:16:20 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:16:35 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-13 08:16:35 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4860
ERROR - 2022-09-13 08:16:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4860
ERROR - 2022-09-13 08:16:38 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4860
ERROR - 2022-09-13 08:16:38 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4860
ERROR - 2022-09-13 08:16:38 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4860
ERROR - 2022-09-13 08:16:39 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4860
ERROR - 2022-09-13 08:16:39 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4860
ERROR - 2022-09-13 08:21:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:24 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:25 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:25 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:26 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:26 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:26 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:34 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:48 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:49 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:49 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:50 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:50 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:50 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:21:52 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:22:23 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-13 08:22:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:23:32 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4862
ERROR - 2022-09-13 08:30:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:30:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:30:37 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:30:50 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:30:52 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:30:52 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:30:53 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:30:53 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:30:53 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:30:53 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:30:53 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1013
ERROR - 2022-09-13 08:33:03 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-13 08:33:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:33:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:33:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:33:07 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:33:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1007
ERROR - 2022-09-13 08:33:09 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:33:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:33:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1007
ERROR - 2022-09-13 08:33:11 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:33:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:33:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:33:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:33:12 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:38:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1007
ERROR - 2022-09-13 08:38:23 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:38:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:41:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1007
ERROR - 2022-09-13 08:41:06 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:41:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:41:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1007
ERROR - 2022-09-13 08:41:09 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:41:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:41:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:41:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:41:55 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:41:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:41:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:41:57 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:42:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:42:04 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:42:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1007
ERROR - 2022-09-13 08:42:07 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:42:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 1008
ERROR - 2022-09-13 08:42:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:42:09 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:43:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:43:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:43:13 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:43:14 --> 404 Page Not Found: ../modules/App/controllers/Schools/teacher_report
ERROR - 2022-09-13 08:43:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:43:16 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:45:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:45:35 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:45:37 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:45:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 915
ERROR - 2022-09-13 08:45:38 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 916
ERROR - 2022-09-13 08:45:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 916
ERROR - 2022-09-13 08:46:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:46:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:46:04 --> 404 Page Not Found: /index
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-13 08:46:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 915
ERROR - 2022-09-13 08:46:57 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 916
ERROR - 2022-09-13 08:46:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 916
ERROR - 2022-09-13 08:49:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 08:49:26 --> 404 Page Not Found: /index
ERROR - 2022-09-13 11:59:26 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-13 11:59:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-13 11:59:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 11:59:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 11:59:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 11:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:13:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-13 14:13:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-13 14:13:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:13:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:13:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:17:33 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 18
ERROR - 2022-09-13 14:17:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 18
ERROR - 2022-09-13 14:17:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:17:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:18:13 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 19
ERROR - 2022-09-13 14:18:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 19
ERROR - 2022-09-13 14:18:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:18:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:22:30 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 19
ERROR - 2022-09-13 14:22:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 19
ERROR - 2022-09-13 14:22:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:22:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:22:31 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 19
ERROR - 2022-09-13 14:22:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 19
ERROR - 2022-09-13 14:22:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:28:00 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 20
ERROR - 2022-09-13 14:28:00 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 20
ERROR - 2022-09-13 14:28:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:28:02 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 20
ERROR - 2022-09-13 14:28:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 20
ERROR - 2022-09-13 14:28:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:28:16 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 20
ERROR - 2022-09-13 14:28:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 20
ERROR - 2022-09-13 14:28:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:28:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:29:08 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:29:10 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:29:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:29:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:29:35 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:29:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:29:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:29:54 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:29:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:29:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:29:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:04 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:04 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:13 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:32 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:45 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:55 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:30:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:31:12 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:31:12 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:31:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:31:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:31:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:31:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 30
ERROR - 2022-09-13 14:31:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:31:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:37:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-13 14:37:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:37:34 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:37:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:37:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:37:46 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:39:49 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:39:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:39:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:24 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:34 --> Severity: error --> Exception: syntax error, unexpected '$actual_link' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2358
ERROR - 2022-09-13 14:46:47 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:49 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:50 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 29
ERROR - 2022-09-13 14:46:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:46:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:48:38 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 31
ERROR - 2022-09-13 14:48:38 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 31
ERROR - 2022-09-13 14:48:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:48:40 --> 404 Page Not Found: ../modules/App/controllers/Presenters/export_teacher_report
ERROR - 2022-09-13 14:48:42 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 31
ERROR - 2022-09-13 14:48:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 31
ERROR - 2022-09-13 14:48:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:48:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:49:28 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:49:36 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:51:32 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:51:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:51:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:51:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:51:33 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:51:34 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:51:34 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:51:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:51:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:51:35 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:51:57 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:51:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:51:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:51:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:51:58 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:53:07 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:53:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:53:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:53:08 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:53:12 --> 404 Page Not Found: ../modules/App/controllers/Presenters/export_teacher_report
ERROR - 2022-09-13 14:53:13 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:53:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:53:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:53:14 --> 404 Page Not Found: /index
ERROR - 2022-09-13 14:53:30 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:53:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-13 14:53:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:53:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-13 14:53:31 --> 404 Page Not Found: /index
