<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-23 07:19:36 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:19:37 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:19:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-23 07:20:06 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:20:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-23 07:20:14 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-23 07:20:25 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:20:34 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:20:53 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:21:15 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:24:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-23 07:24:14 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-23 07:24:16 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:35:18 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 887
ERROR - 2022-08-23 07:36:08 --> Severity: Compile Error --> Cannot redeclare Schools::teacher_report() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 887
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:31 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:36:32 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:40:22 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:41:43 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:42:30 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:42:32 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:33 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:33 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:33 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:34 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:34 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:34 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:34 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:34 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:34 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:35 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:35 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:36 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:36 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:36 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:37 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:37 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:37 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:42:37 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:45:09 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:45:11 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:45:15 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:45:15 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:45:22 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:45:26 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:45:41 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:46:41 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:46:41 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:38 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 07:48:39 --> 404 Page Not Found: /index
ERROR - 2022-08-23 07:48:39 --> 404 Page Not Found: /index
ERROR - 2022-08-23 09:50:35 --> 404 Page Not Found: /index
ERROR - 2022-08-23 09:50:46 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-23 09:50:49 --> 404 Page Not Found: /index
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 09:50:53 --> 404 Page Not Found: /index
ERROR - 2022-08-23 09:50:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 09:50:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:13:48 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:13:50 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:13:51 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:13:51 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:13:51 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:21 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:22 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:14:23 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4715
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:11 --> 404 Page Not Found: /index
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 10:15:28 --> 404 Page Not Found: /index
ERROR - 2022-08-23 10:15:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 10:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 11:41:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 11:41:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:41:14 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:41:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 11:41:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:46:43 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:46:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:46:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:46:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:46:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:46:50 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:46:51 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:44 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:47:45 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:47:45 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 11:49:58 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:49:58 --> 404 Page Not Found: /index
ERROR - 2022-08-23 11:50:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:00:12 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:00:12 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:00:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 894
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:04:36 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:04:36 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:04:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 12:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:14:12 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:14:13 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 893
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:26 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:19:27 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:19:27 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:19:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 896
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:22:55 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:22:56 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:22:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 886
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:06 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:07 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:23:07 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:23:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 886
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:23:59 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:00 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:24:00 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:24:49 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:24:49 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:26:48 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:26:48 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:26:54 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:26:54 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:26:54 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:26:54 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:26:54 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:26:54 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:01 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:28:01 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:28:05 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:28:05 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:28:05 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:28:05 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:28:05 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:28:05 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:28:30 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:28:30 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:28:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:28:35 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 888
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:29:01 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:29:01 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:29:04 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:30:42 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:30:42 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'city' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'city' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'city' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'city' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'address' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'city' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 899
ERROR - 2022-08-23 12:30:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 906
ERROR - 2022-08-23 12:30:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 907
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:31:34 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:31:34 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:32:25 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:32:26 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:40:00 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:40:01 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:42:13 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:42:13 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:19 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:43:20 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:43:20 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:15 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:53:15 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 12:53:20 --> 404 Page Not Found: /index
ERROR - 2022-08-23 12:53:21 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:30 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:11:31 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:11:31 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:47 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:17:53 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:14 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:15 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:18:16 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:18:20 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:56 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:21:57 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:22:00 --> 404 Page Not Found: ../modules/App/controllers/Orders/teacher_report
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:03 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:51 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:22:53 --> 404 Page Not Found: ../modules/App/controllers/Orders/teacher_report
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:54 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:22:55 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:02 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:13 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:24:14 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:24:17 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:12 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:24 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:34:25 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:29 --> 404 Page Not Found: /index
ERROR - 2022-08-23 13:34:32 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 13:34:40 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:55 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:18:57 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:58 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:18:59 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:19:00 --> 404 Page Not Found: ../modules/App/controllers//index
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:01 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:19:02 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:21:35 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:22:20 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:34 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:24:35 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:30:51 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:15 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:16 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:23 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:24 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 161
ERROR - 2022-08-23 14:42:26 --> Severity: Notice --> Trying to get property 'grade_teachers' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\schools\edit.php 167
ERROR - 2022-08-23 14:42:26 --> 404 Page Not Found: /index
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> Severity: Notice --> Undefined index: teacher_report C:\xampp\htdocs\brienza_backup\application\helpers\template_helper.php 163
ERROR - 2022-08-23 14:42:28 --> 404 Page Not Found: /index
ERROR - 2022-08-23 15:11:54 --> 404 Page Not Found: /index
