<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-29 07:51:42 --> 404 Page Not Found: /index
ERROR - 2022-04-29 07:54:26 --> 404 Page Not Found: /index
ERROR - 2022-04-29 07:55:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-29 07:55:09 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:42:42 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:42:44 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:43:23 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:43:28 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:43:55 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:43:57 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:44:07 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:44:33 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-29 08:44:34 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-29 08:44:35 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:44:44 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:44:47 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:45:04 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:45:17 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:45:33 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:45:53 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:46:27 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:46:44 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:47:14 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:50:50 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:51:26 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:51:58 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:52:19 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:52:43 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:52:59 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:53:38 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:54:00 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:54:36 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:54:51 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:55:04 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:55:07 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:55:21 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:55:45 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:56:02 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:56:19 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:56:43 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:57:35 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:58:33 --> 404 Page Not Found: /index
ERROR - 2022-04-29 08:58:35 --> 404 Page Not Found: /index
ERROR - 2022-04-29 09:00:05 --> 404 Page Not Found: /index
ERROR - 2022-04-29 09:00:08 --> 404 Page Not Found: /index
ERROR - 2022-04-29 09:03:15 --> 404 Page Not Found: /index
