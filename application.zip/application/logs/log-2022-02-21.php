<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-21 10:56:28 --> 404 Page Not Found: /index
ERROR - 2022-02-21 10:59:25 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-21 10:59:27 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-21 10:59:28 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:06:15 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:06:59 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-21 11:07:01 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:07:10 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:15:14 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:15:20 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:15:41 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:15:42 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:33:47 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:33:47 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:36:46 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:36:46 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:54:09 --> 404 Page Not Found: /index
ERROR - 2022-02-21 11:54:09 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:00:13 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:00:13 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:06:06 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:06:06 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:27:56 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:27:57 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:29:51 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:29:51 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:31:14 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:31:15 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:31:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 216
ERROR - 2022-02-21 12:31:59 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:31:59 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:33:22 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:33:22 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:39:59 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:39:59 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:45:24 --> 404 Page Not Found: /index
ERROR - 2022-02-21 12:45:24 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:00:52 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:00:52 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:11:24 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:11:24 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:12:26 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:12:27 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:13:00 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:13:01 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:18:20 --> 404 Page Not Found: /index
ERROR - 2022-02-21 14:18:21 --> 404 Page Not Found: /index
