<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-19 11:27:11 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:27:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-19 11:27:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 11:27:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:27:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:27:47 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:27:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 11:27:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:27:59 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:27:59 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:28:02 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-19 11:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-19 11:28:02 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-19 11:28:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-19 11:28:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 11:28:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:28:02 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:28:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 11:28:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:28:05 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-19 11:28:06 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:42:13 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-19 11:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-19 11:42:13 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-19 11:42:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-19 11:42:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 11:42:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:42:14 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:56:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 11:56:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:56:11 --> 404 Page Not Found: /index
ERROR - 2022-10-19 11:56:13 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-19 11:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-19 11:56:13 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-19 11:56:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-19 11:56:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 11:56:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 11:56:14 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:02:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:02:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:02:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:02:01 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:13:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:13:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:13:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:13:42 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:13:43 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:13:45 --> 404 Page Not Found: ../modules/App/controllers/Presenters/log_template_for_presenters
ERROR - 2022-10-19 13:13:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:13:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:13:48 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:17:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:17:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:17:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:17:20 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:17:20 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:17:22 --> Severity: error --> Exception: Call to undefined method App_model::log_template() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2477
ERROR - 2022-10-19 13:17:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:17:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:17:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:17:25 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:21:58 --> Severity: error --> Exception: Call to undefined method App_model::log_template() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2477
ERROR - 2022-10-19 13:22:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:22:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:22:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:22:05 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:31:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:31:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:31:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:31:34 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:31:34 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:31:35 --> Query error: Table 'brienza.presenters_log' doesn't exist - Invalid query: SELECT *
FROM `presenters_log`
ERROR - 2022-10-19 13:46:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:46:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:46:54 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:46:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:46:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:46:56 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:47:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:47:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:47:01 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-19 13:47:01 --> 404 Page Not Found: /index
ERROR - 2022-10-19 13:47:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 13:47:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 13:47:15 --> 404 Page Not Found: /index
ERROR - 2022-10-19 14:14:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-19 14:14:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 14:14:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-19 14:14:57 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-19 14:14:57 --> 404 Page Not Found: /index
