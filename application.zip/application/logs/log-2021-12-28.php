<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-28 05:57:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:57:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:00:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:00:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:00:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:05:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:05:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:18:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:18:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:30:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:30:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:50:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:50:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 01:51:01 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 06:51:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:51:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 01:51:37 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 06:51:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 01:51:40 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 01:51:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 06:51:40 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:51:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:51:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:51:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:52:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 01:52:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 06:52:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:52:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:22:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:23:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:24:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:24:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:24:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:25:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:25:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:25:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:26:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:26:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:26:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:26:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:27:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:27:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:27:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:28:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:33:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:33:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:33:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:34:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:34:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:34:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:34:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:34:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:34:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:34:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:35:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:35:40 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:35:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:36:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:36:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:37:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:37:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:37:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:37:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:38:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:38:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:38:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:38:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:38:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:42:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:42:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:42:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:42:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:43:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:43:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:43:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:43:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:43:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:43:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:43:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 02:43:53 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 02:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 409
ERROR - 2021-12-28 07:44:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:44:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:44:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:44:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:44:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:44:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:44:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:45:04 --> 404 Page Not Found: /index
ERROR - 2021-12-28 02:45:15 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 02:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 409
ERROR - 2021-12-28 07:45:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:45:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:45:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:45:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:45:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:46:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:46:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:46:40 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:47:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:48:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 02:48:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 07:48:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:48:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:49:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:49:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 02:50:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 07:50:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:50:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:50:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:51:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:51:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:51:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:52:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:52:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:53:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:55:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:55:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:55:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:56:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:56:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:56:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 02:57:00 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 02:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 409
ERROR - 2021-12-28 07:57:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:57:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:57:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:57:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:57:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:58:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:01:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:02:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:03:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:03:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:05:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:06:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:06:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:06:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:10:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:10:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:10:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:11:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:11:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:12:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:13:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:13:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:16:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:16:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:35:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:36:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:36:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:36:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:37:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:37:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:37:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:37:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:38:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:38:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:38:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:38:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:38:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:38:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:40:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:40:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:40:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:41:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:41:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:41:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:41:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:41:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:41:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:42:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:42:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:42:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:46:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:47:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:47:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:47:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:47:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:48:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:48:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:48:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:48:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:48:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:48:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:49:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:49:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:49:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:49:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:49:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:50:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:50:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:50:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:50:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:51:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:51:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:52:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:52:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 03:53:12 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 08:53:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:53:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:53:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:56:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:58:11 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:58:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:58:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:58:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 03:58:45 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 08:58:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:58:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:59:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:59:11 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:59:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:59:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:01:02 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 09:02:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:02:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:03:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:03:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:03:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:03:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:03:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:03:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:04:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:05:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:05:33 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 04:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 409
ERROR - 2021-12-28 09:05:40 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:05:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:05:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:06:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:08:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:08:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:09:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:09:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:10:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:10:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:10:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:10:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:10:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:10:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:10:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:10:59 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 04:11:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 409
ERROR - 2021-12-28 09:11:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:11:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:11:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:11:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:11:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:11:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:12:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:12:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:13:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:13:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:13:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:13:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:13:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:13:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:13:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:14:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 09:14:11 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:14:23 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 09:14:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:40 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:14:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:15:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:15:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:15:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:15:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:15:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:18:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:18:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:19:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:04 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:20:45 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 09:20:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:20:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:21:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 09:21:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:21:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:22:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:23:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:23:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:23:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:23:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:23:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:25:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:25:20 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 09:25:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:25:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:25:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:25:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-28 04:25:44 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-28 09:26:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:27:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:27:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:27:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:28:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:28:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:28:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:29:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:29:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:29:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:29:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:30:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:30:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:30:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:30:40 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:31:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:33:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:33:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:34:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:34:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:34:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:34:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:34:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:34:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:35:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:35:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 16
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 16
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 24
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 24
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 27
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 27
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 27
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 27
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 30
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 30
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 33
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 33
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 33
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 33
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 33
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 33
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 36
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 36
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 36
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 36
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 36
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 36
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 39
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 39
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 48
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 48
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 52
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 52
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 53
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 53
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 54
ERROR - 2021-12-28 04:35:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log_billing.php 54
ERROR - 2021-12-28 09:35:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:35:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:36:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:36:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:36:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:36:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:36:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:37:04 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:37:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:37:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:37:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:38:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:38:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:38:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:38:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:39:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:39:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:39:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:39:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:40:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:40:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:40:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:40:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:40:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:41:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:41:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:42:11 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:42:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:42:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:42:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:43:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:44:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:46:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:47:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:49:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:53:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 04:53:22 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 09:53:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:53:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:54:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:59:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:59:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:59:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:59:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:59:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:59:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 09:59:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:00:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:00:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:00:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:00:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:00:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:00:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:00:23 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:00:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:02:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:04:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:04:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:04:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:04:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:04:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:04:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:05:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:06:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:06:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:06:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:06:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:06:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:06:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:06:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:07:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:07:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:07:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:07:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:08:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:08:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:08:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:08:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:09:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:09:15 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:09:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:09:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:09:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:09:50 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 05:09:54 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 05:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 409
ERROR - 2021-12-28 05:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 409
ERROR - 2021-12-28 10:10:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:10:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:10:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:10:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:11:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:11:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:11:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:11:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:11:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:12:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:12:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:12:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:12:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:13:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:13:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:13:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:13:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:13:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:13:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:13:53 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-28 10:13:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:14:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:14:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:14:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:14:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:14:44 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:14:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:14:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:14:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:15:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:15:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:16:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:17:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:17:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:17:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:17:29 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:17:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:20:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:21:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:04 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:40 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:22:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:23:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:24:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:25:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:26:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:26:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:27:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:27:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:27:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:27:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:27:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:27:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:28:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:28:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:28:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:28:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:28:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:28:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:28:59 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:29:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:29:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:29:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:29:26 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 05:29:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 10:29:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:29:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:30:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:30:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:30:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:30:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:32:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:32:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:33:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:34:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:34:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:34:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:34:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:34:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:34:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:35:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:37:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:37:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:37:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:37:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:37:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:38:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:39:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:40:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:41:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:41:48 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 10:41:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:45:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:45:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:45:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:45:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:45:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:45:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:04 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:46:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:52:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:52:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:53:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:53:07 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:55:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:55:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:55:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:55:54 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:57:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:57:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:57:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:57:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 05:57:50 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 05:57:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 10:57:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 10:57:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:00:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:00:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:00:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:00:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:00:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:00:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:00:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:01:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:01:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:01:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:01:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:01:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:01:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:01:58 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:03:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:03:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:03:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:03:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:03:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:04:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:04:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:04:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:05:04 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 11:05:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:05:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:06:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:06:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:06:25 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 06:06:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 11:06:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:06:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:06:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:07:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:07:02 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 06:07:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 11:07:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:07:04 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:07:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:07:10 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 06:07:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-28 11:07:11 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:07:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:09:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:11:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:15:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:15:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:17:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:17:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:17:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:17:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:21:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 06:22:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 11:22:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:24:56 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:25:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:25:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:25:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:25:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:26:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:26:18 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:26:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:26:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:26:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:26:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:27:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:29:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:29:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:29:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:29:59 --> 404 Page Not Found: /index
ERROR - 2021-12-28 11:30:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:16:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:16:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:17:01 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:17:14 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:17:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:17:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:17:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:18:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 12:18:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:18:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:18:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:18:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:18:50 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:18:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:19:11 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:19:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:19:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:16 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:20:45 --> Severity: Notice --> Undefined variable: set /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 964
ERROR - 2021-12-28 12:20:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:20:51 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:46:22 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:49:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:50:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:50:52 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:51:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:51:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 07:51:24 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-28 12:51:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:51:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:51:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:51:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:51:47 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:57:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:58:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:58:30 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:58:37 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:58:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 12:59:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:03:25 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:03:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:03:31 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:03:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-28 08:03:46 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-28 13:04:02 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:04:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:04:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:06:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:07:01 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 13:07:19 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:07:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:08:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:08:13 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:08:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:08:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:09:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:09:09 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:10:11 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:10:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:10:23 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:10:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-28 08:10:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-28 13:10:45 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:11:00 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:11:43 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:14:12 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:14:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:42:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:42:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:42:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 13:43:41 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:30:05 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:30:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:30:26 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:30:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:30:34 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:30:44 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:30:57 --> 404 Page Not Found: /index
ERROR - 2021-12-28 18:53:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:19:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 14:19:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 19:19:38 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:21:35 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:21:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:21:55 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:22:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:22:27 --> 404 Page Not Found: /index
ERROR - 2021-12-28 14:22:27 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 19:22:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:22:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:22:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:22:48 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:22:53 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:23:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:23:04 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:23:08 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:24:10 --> 404 Page Not Found: /index
ERROR - 2021-12-28 14:24:18 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 19:24:20 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:24:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:24:33 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:24:36 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:24:49 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:25:15 --> 404 Page Not Found: /index
ERROR - 2021-12-28 14:25:18 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 19:25:24 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:25:28 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:25:39 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:25:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:25:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:03 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:06 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:17 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:21 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:29 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:32 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:42 --> 404 Page Not Found: /index
ERROR - 2021-12-28 14:27:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-28 19:27:46 --> 404 Page Not Found: /index
ERROR - 2021-12-28 19:27:49 --> 404 Page Not Found: /index
