<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-21 06:10:02 --> 404 Page Not Found: /index
ERROR - 2022-03-21 06:12:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-21 06:12:27 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-21 06:12:29 --> 404 Page Not Found: /index
ERROR - 2022-03-21 06:13:08 --> 404 Page Not Found: /index
ERROR - 2022-03-21 06:14:46 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-21 06:14:50 --> 404 Page Not Found: /index
ERROR - 2022-03-21 06:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:14:44 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:14:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-21 10:14:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-21 10:14:55 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:14:57 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:14:59 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:22:11 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:23:52 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:24:16 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:24:43 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:25:29 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:28:50 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:29:30 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:29:41 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:30:16 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:32:34 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:37:49 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:42:32 --> 404 Page Not Found: /index
ERROR - 2022-03-21 10:45:43 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:00:54 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:03:48 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:04:18 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:05:42 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:06:24 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:14:53 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:50:05 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:50:12 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 231
ERROR - 2022-03-21 11:50:52 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:51:04 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:52:19 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:52:41 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:58:26 --> 404 Page Not Found: /index
ERROR - 2022-03-21 11:59:29 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:03:59 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:04:12 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:04:34 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:18:00 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:21:30 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:21:52 --> Severity: Notice --> Undefined variable: cur_month C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 247
ERROR - 2022-03-21 12:22:16 --> Severity: Notice --> Undefined variable: cur_month C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 247
ERROR - 2022-03-21 12:22:18 --> Severity: Notice --> Undefined variable: cur_month C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 247
ERROR - 2022-03-21 12:22:43 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:22:45 --> Severity: Notice --> Undefined variable: cur_month C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 250
ERROR - 2022-03-21 12:23:50 --> Severity: Notice --> Undefined variable: cur_month C:\xampp\htdocs\brienza\application\libraries\My_calendar.php 247
ERROR - 2022-03-21 12:24:10 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:24:47 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:30:05 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:43:37 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:45:12 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:45:45 --> 404 Page Not Found: /index
ERROR - 2022-03-21 12:45:52 --> 404 Page Not Found: /index
ERROR - 2022-03-21 13:04:33 --> 404 Page Not Found: /index
ERROR - 2022-03-21 13:30:10 --> 404 Page Not Found: /index
ERROR - 2022-03-21 13:40:13 --> 404 Page Not Found: /index
ERROR - 2022-03-21 13:40:35 --> 404 Page Not Found: /index
ERROR - 2022-03-21 13:45:22 --> 404 Page Not Found: /index
ERROR - 2022-03-21 13:47:23 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:09:43 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:11:01 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:11:04 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:12:18 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:12:25 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:12:47 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:13:37 --> 404 Page Not Found: /index
ERROR - 2022-03-21 14:14:25 --> 404 Page Not Found: /index
