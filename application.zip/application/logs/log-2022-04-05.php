<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-05 06:50:09 --> 404 Page Not Found: /index
ERROR - 2022-04-05 06:55:58 --> 404 Page Not Found: /index
ERROR - 2022-04-05 06:58:06 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-05 06:58:09 --> 404 Page Not Found: /index
ERROR - 2022-04-05 07:02:55 --> 404 Page Not Found: /index
ERROR - 2022-04-05 07:03:02 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-05 07:03:04 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-05 07:03:05 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:16:22 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:16:26 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:16:46 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:17:10 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:17:34 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:18:36 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:26:36 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:26:42 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:26:42 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:27:19 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:27:19 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:27:37 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:27:37 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:27:47 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:44:04 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:44:04 --> 404 Page Not Found: /index
ERROR - 2022-04-05 08:44:21 --> 404 Page Not Found: /index
