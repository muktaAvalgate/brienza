<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-09 11:19:15 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:20:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-09 11:20:17 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-09 11:20:18 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:24:59 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:26:00 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-09 11:26:04 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:27:39 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:27:44 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:51:47 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:52:14 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:52:26 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:52:29 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:52:40 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:52:52 --> Severity: Notice --> Undefined variable: purchase_orders C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-02-09 11:52:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-02-09 11:52:52 --> 404 Page Not Found: /index
ERROR - 2022-02-09 11:52:58 --> 404 Page Not Found: /index
ERROR - 2022-02-09 12:03:05 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:14:50 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:14:54 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:15:35 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:15:46 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:29:25 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:30:28 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:30:50 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:46:41 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:46:46 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:47:22 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:47:58 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:48:37 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:49:03 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:51:18 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:51:45 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:52:20 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:52:46 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:58:23 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:59:39 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:59:57 --> 404 Page Not Found: /index
ERROR - 2022-02-09 13:59:57 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:02:33 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:02:33 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:02:36 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:02:36 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:05:05 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:05:06 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:05:15 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:05:15 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:06:48 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:06:48 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:09:37 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:09:37 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:09:40 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:09:40 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:09:50 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:09:50 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:10:00 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:10:00 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:21:55 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:21:56 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:23:34 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:23:35 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:26:15 --> 404 Page Not Found: /index
ERROR - 2022-02-09 14:26:15 --> 404 Page Not Found: /index
