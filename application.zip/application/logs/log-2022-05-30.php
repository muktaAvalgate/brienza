<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-30 11:07:46 --> 404 Page Not Found: /index
ERROR - 2022-05-30 11:08:49 --> 404 Page Not Found: /index
ERROR - 2022-05-30 11:09:35 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-05-30 11:09:37 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-05-30 11:09:37 --> 404 Page Not Found: /index
ERROR - 2022-05-30 11:21:12 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-05-30 11:21:14 --> 404 Page Not Found: /index
ERROR - 2022-05-30 11:23:50 --> 404 Page Not Found: /index
ERROR - 2022-05-30 11:23:55 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:42:32 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:42:39 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:43:19 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:43:23 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:43:33 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:43:40 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:43:43 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:43:45 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:44:14 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:44:14 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:49:02 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:49:02 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:51:40 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:51:40 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:01 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:01 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:22 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:22 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:26 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:26 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:29 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:29 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:44 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:45 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:47 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:47 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:49 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:51 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:53 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:53 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:56 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:52:56 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:53:28 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:53:30 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:54:10 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:54:11 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:55:56 --> 404 Page Not Found: /index
ERROR - 2022-05-30 12:55:58 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:14:50 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:14:53 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:14:58 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:02 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:05 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:06 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:08 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:15 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:18 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:27 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:15:27 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:25 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:26 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:31 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:32 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:35 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:35 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:46 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:26:46 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:27:32 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:27:32 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:27:46 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:27:46 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:27:59 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:28:00 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:28:05 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:28:06 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-05-30 13:28:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-05-30 13:28:17 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:29:38 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-05-30 13:34:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-05-30 13:35:07 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:09 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:19 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:20 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:22 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:24 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:24 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:25 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:26 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:27 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:29 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:29 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:32 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:32 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:36 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:37 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:40 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:41 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:43 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:43 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:46 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:47 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:49 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:49 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:52 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:52 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:54 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:54 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:57 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:58 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:59 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:35:59 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:01 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:01 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:10 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:10 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:28 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:28 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:41 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:41 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:51 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:36:52 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:37:01 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:37:02 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:37:14 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:37:14 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:40:09 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:40:09 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:41:08 --> 404 Page Not Found: /index
ERROR - 2022-05-30 13:41:09 --> 404 Page Not Found: /index
