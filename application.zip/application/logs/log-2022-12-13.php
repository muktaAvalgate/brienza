<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-13 05:57:08 --> 404 Page Not Found: /index
ERROR - 2022-12-13 05:57:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-13 05:57:51 --> 404 Page Not Found: /index
ERROR - 2022-12-13 05:57:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-13 05:57:55 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-13 05:59:41 --> 404 Page Not Found: /index
ERROR - 2022-12-13 05:59:42 --> 404 Page Not Found: /index
ERROR - 2022-12-13 06:29:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-12-13 06:29:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-12-13 07:42:36 --> 404 Page Not Found: /index
ERROR - 2022-12-13 07:42:36 --> 404 Page Not Found: /index
ERROR - 2022-12-13 07:42:38 --> 404 Page Not Found: /index
ERROR - 2022-12-13 07:42:40 --> 404 Page Not Found: /index
ERROR - 2022-12-13 08:27:54 --> 404 Page Not Found: /index
ERROR - 2022-12-13 08:27:57 --> 404 Page Not Found: /index
ERROR - 2022-12-13 10:23:24 --> 404 Page Not Found: /index
ERROR - 2022-12-13 10:24:13 --> 404 Page Not Found: /index
ERROR - 2022-12-13 10:26:07 --> 404 Page Not Found: /index
ERROR - 2022-12-13 10:26:59 --> 404 Page Not Found: /index
ERROR - 2022-12-13 10:27:27 --> 404 Page Not Found: /index
ERROR - 2022-12-13 10:29:40 --> 404 Page Not Found: /index
ERROR - 2022-12-13 10:32:09 --> 404 Page Not Found: /index
ERROR - 2022-12-13 11:13:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-13 11:13:08 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-13 11:22:03 --> 404 Page Not Found: /index
ERROR - 2022-12-13 11:22:38 --> 404 Page Not Found: /index
ERROR - 2022-12-13 11:37:12 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:03:26 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:05:05 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:05:10 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:05:56 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:08:41 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:08:43 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-13 12:08:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-13 12:08:43 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-13 12:08:43 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-13 12:08:44 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:08:48 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:08:51 --> 404 Page Not Found: /index
ERROR - 2022-12-13 12:28:36 --> 404 Page Not Found: /index
ERROR - 2022-12-13 13:24:48 --> 404 Page Not Found: /index
ERROR - 2022-12-13 13:25:31 --> 404 Page Not Found: /index
