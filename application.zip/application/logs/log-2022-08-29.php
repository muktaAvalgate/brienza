<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-29 07:15:36 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:16:00 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-29 07:16:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-29 07:16:09 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:16:11 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-29 07:16:18 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:16:25 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-29 07:16:25 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-29 07:16:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:19:55 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:20:01 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:20:01 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:37:28 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:38:37 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:38:42 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:38:55 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:38:57 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:50:48 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:51:09 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:51:14 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:51:25 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:51:27 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:52:07 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:52:56 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:52:59 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:53:00 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:53:12 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:53:16 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:53:49 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:54:18 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:54:20 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:54:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:54:36 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:55:00 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:55:17 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:55:45 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:55:49 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:58:32 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:58:46 --> 404 Page Not Found: /index
ERROR - 2022-08-29 07:58:55 --> 404 Page Not Found: /index
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-08-29 08:02:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-08-29 08:02:44 --> 404 Page Not Found: /index
ERROR - 2022-08-29 08:03:11 --> 404 Page Not Found: /index
ERROR - 2022-08-29 08:03:15 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:16:38 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:17:20 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:17:23 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:17:27 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:17:33 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:17:35 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:17:39 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:17:56 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:18:01 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:18:14 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:18:17 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:18:25 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:18:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:18:32 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:18:41 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:19:18 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:19:29 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:19:41 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:21:08 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:21:41 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:22:10 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:22:14 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:22:37 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:22:47 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:23:27 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:23:38 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:23:42 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:23:48 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:23:56 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:24:31 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:24:34 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:27:12 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:27:37 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:29:01 --> Query error: Unknown column 're_upload_change' in 'field list' - Invalid query: INSERT INTO `billing` (`session_from`, `session_to`, `late_flag`, `billing_date`, `order_id`, `presenter_id`, `presenter_invoice`, `re_upload_change`, `total_amount`, `invoice_document`, `created_by`, `payment_date`) VALUES ('2021-09-01', '2021-09-15', '1', '2021-10-08', '720', '15', 175, '1', 44, 'assets/teachers/invoice_20220829092900.pdf', '15', NULL)
ERROR - 2022-08-29 09:29:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:29:33 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:29:38 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:30:21 --> Query error: Unknown column 're_upload_change' in 'field list' - Invalid query: INSERT INTO `billing` (`session_from`, `session_to`, `late_flag`, `billing_date`, `order_id`, `presenter_id`, `presenter_invoice`, `re_upload_change`, `total_amount`, `invoice_document`, `created_by`, `payment_date`) VALUES ('2021-09-01', '2021-09-15', '1', '2021-10-08', '720', '15', 175, '1', 44, 'assets/teachers/invoice_20220829093021.pdf', '15', NULL)
ERROR - 2022-08-29 09:30:43 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:30:54 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:31:28 --> Query error: Unknown column 're_upload_change' in 'field list' - Invalid query: INSERT INTO `billing` (`session_from`, `session_to`, `late_flag`, `billing_date`, `order_id`, `presenter_id`, `presenter_invoice`, `re_upload_change`, `total_amount`, `invoice_document`, `created_by`, `payment_date`) VALUES ('2021-09-01', '2021-09-15', '1', '2021-10-08', '719', '15', 175, '1', 44, 'assets/teachers/invoice_20220829093128.pdf', '15', NULL)
ERROR - 2022-08-29 09:31:42 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:31:53 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:32:03 --> Query error: Unknown column 're_upload_change' in 'field list' - Invalid query: INSERT INTO `billing` (`session_from`, `session_to`, `late_flag`, `billing_date`, `order_id`, `presenter_id`, `presenter_invoice`, `re_upload_change`, `total_amount`, `invoice_document`, `created_by`, `payment_date`) VALUES ('2021-09-01', '2021-09-15', '1', '2021-10-08', '719', '15', 175, '1', 44, 'assets/teachers/invoice_20220829093203.pdf', '15', NULL)
ERROR - 2022-08-29 09:47:13 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:58:38 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:58:40 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:58:44 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:58:49 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:59:00 --> 404 Page Not Found: /index
ERROR - 2022-08-29 09:59:08 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:08:04 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:08:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:08:32 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:08:45 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:08:48 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:08:54 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:09:02 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:09:05 --> 404 Page Not Found: /index
ERROR - 2022-08-29 10:09:18 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:38:42 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:38:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-29 11:38:53 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-29 11:38:53 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:38:58 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:56:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:56:29 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:56:34 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:56:50 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:56:53 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:56:55 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:56:58 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:59:17 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:59:20 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:59:25 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:59:35 --> 404 Page Not Found: /index
ERROR - 2022-08-29 11:59:42 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:00:25 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:00:27 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:00:34 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:00:43 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:00:47 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:01:06 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:01:08 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:02:00 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:02:07 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:02:11 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:02:16 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:02:19 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:02:22 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:02:33 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:02 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:07 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:10 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:23 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:29 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:31 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:03:41 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:05:05 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:05:08 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:05:15 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:05:28 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:05:53 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:05:57 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:06:08 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:09:11 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:09:39 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:09:44 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:09:55 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:10:04 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:10:33 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:11:03 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:11:14 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:11:18 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:11:23 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:11:28 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:11:46 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:11:51 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:12:06 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:12:10 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:12:12 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:12:45 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:12:47 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:12:59 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:13:03 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:13:04 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:14:05 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:14:12 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:14:20 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:15:21 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:15:31 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:16:10 --> 404 Page Not Found: /index
ERROR - 2022-08-29 12:26:43 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:43:58 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza_backup\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza_backup\system\core\Common.php 407
ERROR - 2022-08-29 14:43:58 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza_backup\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza_backup\system\core\Common.php 407
ERROR - 2022-08-29 14:43:58 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza_backup\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza_backup\system\core\Common.php 407
ERROR - 2022-08-29 14:44:05 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza_backup\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza_backup\system\core\Common.php 407
ERROR - 2022-08-29 14:44:21 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:44:33 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-29 14:44:36 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:44:40 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:44:44 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:44:45 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:44:49 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:45:10 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:45:12 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:45:15 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:45:26 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:45:29 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:45:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-29 14:45:52 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-29 14:46:58 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:47:02 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:47:04 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:47:06 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:47:08 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:47:17 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:47:24 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:54:08 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:54:14 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:54:17 --> 404 Page Not Found: /index
ERROR - 2022-08-29 14:54:25 --> 404 Page Not Found: /index
ERROR - 2022-08-29 15:01:26 --> 404 Page Not Found: /index
