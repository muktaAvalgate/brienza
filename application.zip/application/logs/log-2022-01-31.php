<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-31 10:32:05 --> 404 Page Not Found: /index
ERROR - 2022-01-31 10:32:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-31 10:33:04 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-31 10:33:06 --> 404 Page Not Found: /index
ERROR - 2022-01-31 11:35:42 --> 404 Page Not Found: /index
ERROR - 2022-01-31 11:37:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-31 11:37:52 --> 404 Page Not Found: /index
ERROR - 2022-01-31 11:38:01 --> 404 Page Not Found: /index
ERROR - 2022-01-31 11:38:02 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:35:37 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:35:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-31 13:35:49 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-31 13:35:49 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:35:56 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:36:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-31 13:36:11 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:36:20 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:37:04 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:45:16 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:55:49 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:56:55 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:57:11 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:57:11 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:58:14 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:58:14 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:58:29 --> 404 Page Not Found: /index
ERROR - 2022-01-31 13:58:29 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:22:36 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:22:36 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:28:29 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:28:30 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:29:25 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:29:25 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:29:48 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:29:48 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:29:57 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:29:57 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:47:44 --> 404 Page Not Found: /index
ERROR - 2022-01-31 14:47:44 --> 404 Page Not Found: /index
