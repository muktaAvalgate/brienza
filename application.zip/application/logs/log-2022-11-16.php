<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-16 06:26:08 --> 404 Page Not Found: /index
ERROR - 2022-11-16 06:26:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-16 06:26:35 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-16 06:26:38 --> 404 Page Not Found: /index
ERROR - 2022-11-16 06:26:38 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-16 06:29:55 --> Severity: Notice --> Undefined variable: popup C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 06:34:18 --> Severity: Notice --> Undefined variable: popup C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 06:34:30 --> Severity: Notice --> Undefined variable: popup C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 06:34:35 --> Severity: Notice --> Undefined variable: popup C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 06:35:01 --> Severity: Notice --> Undefined variable: popup C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 07:15:05 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:15:18 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-16 07:15:21 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-16 07:15:21 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:15:24 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:15:26 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:33:10 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:34:08 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:36:06 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:38:10 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:40:04 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:43:55 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:44:53 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:45:03 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:46:41 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:51:15 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:51:36 --> Severity: Notice --> Undefined variable: demo C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 07:51:37 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:56:01 --> Severity: Notice --> Undefined variable: txt2 C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 07:56:01 --> 404 Page Not Found: /index
ERROR - 2022-11-16 07:56:28 --> Severity: Notice --> Undefined variable: txt2 C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 07:56:28 --> 404 Page Not Found: /index
ERROR - 2022-11-16 08:10:04 --> Severity: Notice --> Undefined variable: txt2 C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 08:10:04 --> 404 Page Not Found: /index
ERROR - 2022-11-16 08:10:22 --> Severity: Notice --> Undefined variable: txt2 C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-16 08:10:22 --> 404 Page Not Found: /index
ERROR - 2022-11-16 11:27:16 --> 404 Page Not Found: /index
ERROR - 2022-11-16 11:27:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-16 11:27:42 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-16 11:27:42 --> 404 Page Not Found: /index
ERROR - 2022-11-16 11:27:45 --> 404 Page Not Found: /index
ERROR - 2022-11-16 11:27:47 --> Severity: error --> Exception: syntax error, unexpected '}', expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 289
ERROR - 2022-11-16 11:27:47 --> 404 Page Not Found: /index
ERROR - 2022-11-16 11:28:02 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:37:09 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:37:19 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:38:44 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:38:44 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:39:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-16 12:39:38 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-16 12:41:31 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:42:30 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:42:54 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:43:17 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:44:59 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:45:31 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:46:16 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:47:24 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:48:14 --> 404 Page Not Found: /index
ERROR - 2022-11-16 12:49:03 --> 404 Page Not Found: /index
ERROR - 2022-11-16 13:59:45 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:00:16 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:01:16 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:07:04 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:12:56 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:23:44 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:25:56 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:26:35 --> 404 Page Not Found: /index
ERROR - 2022-11-16 14:26:40 --> 404 Page Not Found: /index
