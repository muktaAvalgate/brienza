<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-25 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-01-25 11:11:37 --> 404 Page Not Found: /index
ERROR - 2022-01-25 11:13:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-25 11:13:09 --> 404 Page Not Found: /index
ERROR - 2022-01-25 11:13:38 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-25 11:13:41 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-25 11:13:44 --> 404 Page Not Found: /index
ERROR - 2022-01-25 11:35:51 --> 404 Page Not Found: /index
ERROR - 2022-01-25 11:56:54 --> 404 Page Not Found: /index
ERROR - 2022-01-25 11:57:49 --> 404 Page Not Found: /index
ERROR - 2022-01-25 11:57:57 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:04:21 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:04:52 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:04:56 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:05:05 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:05:07 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:10:46 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:10:53 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:13:24 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:14:01 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:14:19 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:47:00 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:47:10 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:47:14 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:47:23 --> 404 Page Not Found: /index
ERROR - 2022-01-25 12:47:46 --> 404 Page Not Found: /index
