<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-05 07:28:06 --> 404 Page Not Found: /index
ERROR - 2022-09-05 07:28:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-05 07:28:25 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-05 07:41:52 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-05 07:41:54 --> 404 Page Not Found: /index
ERROR - 2022-09-05 07:41:56 --> 404 Page Not Found: /index
ERROR - 2022-09-05 07:42:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-05 07:42:05 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-05 07:42:06 --> 404 Page Not Found: /index
ERROR - 2022-09-05 09:03:36 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-05 09:19:29 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-05 09:19:42 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-05 09:20:21 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-05 09:51:08 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-05 12:25:37 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:25:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-05 12:25:50 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:26:20 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:29:23 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:31:02 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:31:07 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:31:11 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 63
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 63
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 67
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 67
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 69
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 69
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 70
ERROR - 2022-09-05 12:32:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 70
ERROR - 2022-09-05 12:33:43 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:34:03 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:34:06 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:34:16 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:34:18 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:34:29 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:36:07 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:36:10 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:36:31 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:36:49 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-09-05 12:39:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-09-05 12:44:18 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:44:35 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:44:39 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:44:49 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:44:51 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:46:01 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:46:04 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:46:14 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:46:23 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:47:22 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:47:30 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:48:27 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:48:38 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:48:46 --> 404 Page Not Found: /index
ERROR - 2022-09-05 12:51:25 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:00:27 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:00:47 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:00:55 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:06:41 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:06:53 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:07:02 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:16:07 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:16:59 --> Query error: Unknown column 'new_status' in 'field list' - Invalid query: INSERT INTO `order_schedules` (`updated_by`, `new_status`, `old_status`, `updated_on`) VALUES ('15', 'Confirm hours', 'Approved', '2022-09-05 13:16:59')
ERROR - 2022-09-05 13:17:03 --> Query error: Unknown column 'new_status' in 'field list' - Invalid query: INSERT INTO `order_schedules` (`updated_by`, `new_status`, `old_status`, `updated_on`) VALUES ('15', 'Confirm hours', 'Approved', '2022-09-05 13:17:03')
ERROR - 2022-09-05 13:17:04 --> Query error: Unknown column 'new_status' in 'field list' - Invalid query: INSERT INTO `order_schedules` (`updated_by`, `new_status`, `old_status`, `updated_on`) VALUES ('15', 'Confirm hours', 'Approved', '2022-09-05 13:17:04')
ERROR - 2022-09-05 13:17:04 --> Query error: Unknown column 'new_status' in 'field list' - Invalid query: INSERT INTO `order_schedules` (`updated_by`, `new_status`, `old_status`, `updated_on`) VALUES ('15', 'Confirm hours', 'Approved', '2022-09-05 13:17:04')
ERROR - 2022-09-05 13:17:15 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:17:22 --> Query error: Unknown column 'new_status' in 'field list' - Invalid query: INSERT INTO `order_schedules` (`updated_by`, `new_status`, `old_status`, `updated_on`) VALUES ('15', 'Confirm hours', 'Approved', '2022-09-05 13:17:22')
ERROR - 2022-09-05 13:20:05 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:20:17 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:20:41 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:21:09 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:24:21 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:25:18 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:25:35 --> 404 Page Not Found: /index
ERROR - 2022-09-05 13:26:52 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:05:10 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:05:17 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:05:58 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:06:19 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:31:58 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:39:54 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:40:14 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:40:19 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:40:30 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:40:34 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:40:45 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:40:46 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:41:36 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:41:45 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:41:55 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:44:47 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:44:52 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:47:17 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:47:35 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:47:52 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:48:46 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:49:02 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-05 14:49:02 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-05 14:49:02 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:49:04 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:49:07 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:49:15 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:50:35 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:50:38 --> 404 Page Not Found: /index
ERROR - 2022-09-05 14:50:47 --> 404 Page Not Found: /index
