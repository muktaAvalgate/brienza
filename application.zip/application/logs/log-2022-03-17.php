<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-17 06:17:33 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:19:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-17 06:19:24 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-17 06:19:24 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:28:15 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:49:09 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:49:44 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:50:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-17 06:50:07 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:50:47 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:50:49 --> Severity: Notice --> Undefined variable: purchase_orders C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-03-17 06:50:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-03-17 06:50:49 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:50:55 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:51:24 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:51:26 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:51:46 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:51:48 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:52:10 --> 404 Page Not Found: /index
ERROR - 2022-03-17 06:52:31 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:07:52 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:08:19 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:08:20 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:08:26 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:08:27 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:08:32 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:08:36 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:13:18 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:13:20 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:13:45 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:14:01 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:14:27 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:14:50 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:15:18 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:15:25 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:15:38 --> 404 Page Not Found: /index
ERROR - 2022-03-17 07:15:39 --> 404 Page Not Found: /index
ERROR - 2022-03-17 09:11:27 --> 404 Page Not Found: /index
ERROR - 2022-03-17 09:15:31 --> 404 Page Not Found: /index
ERROR - 2022-03-17 09:15:38 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-17 09:15:40 --> 404 Page Not Found: /index
ERROR - 2022-03-17 09:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-17 11:22:04 --> 404 Page Not Found: /index
ERROR - 2022-03-17 11:22:13 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-17 11:22:14 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-17 11:22:15 --> 404 Page Not Found: /index
ERROR - 2022-03-17 11:23:16 --> 404 Page Not Found: /index
ERROR - 2022-03-17 11:23:20 --> 404 Page Not Found: /index
ERROR - 2022-03-17 11:23:23 --> 404 Page Not Found: /index
ERROR - 2022-03-17 11:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-17 11:23:42 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-17 11:23:42 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-17 11:24:11 --> 404 Page Not Found: /index
