<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-19 18:35:04 --> 404 Page Not Found: /index
ERROR - 2021-12-19 13:35:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-19 18:35:15 --> 404 Page Not Found: /index
ERROR - 2021-12-19 13:35:19 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-19 13:35:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-19 18:35:22 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:35:34 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:35:44 --> 404 Page Not Found: /index
ERROR - 2021-12-19 13:36:13 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-19 13:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-19 18:36:15 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:36:20 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:36:25 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:37:49 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:40:54 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:40:59 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:10 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:13 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:16 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:33 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:37 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:42 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:47 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:50 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:54 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:41:59 --> 404 Page Not Found: /index
ERROR - 2021-12-19 13:42:01 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-19 13:42:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-19 18:42:03 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:42:11 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:42:18 --> 404 Page Not Found: /index
ERROR - 2021-12-19 18:42:24 --> 404 Page Not Found: /index
