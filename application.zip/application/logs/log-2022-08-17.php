<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-17 07:24:04 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:24:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-17 07:24:22 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:24:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-17 07:24:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-17 07:24:56 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:25:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-17 07:25:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-17 07:25:10 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:39:40 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:40:21 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:40:26 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:40:37 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:40:40 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:40:45 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:40:52 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:40:55 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:41:43 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:42:07 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:42:27 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-17 07:44:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-17 07:44:42 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:44:46 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:45:01 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:45:08 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:45:48 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:47:33 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:47:37 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:47:40 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:47:45 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:47:55 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:48:16 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:48:38 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:48:42 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:48:52 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:48:55 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:49:00 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:49:42 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:49:44 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:50:01 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:50:18 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:51:50 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:51:52 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:52:02 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:52:40 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:52:44 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:52:47 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:52:58 --> 404 Page Not Found: /index
ERROR - 2022-08-17 07:59:45 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:03:10 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:19:02 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:19:26 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:19:31 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:19:47 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:19:50 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:19:56 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:22:37 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:22:44 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:23:15 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:23:53 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 16
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 24
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 27
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 30
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 33
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 36
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 39
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 48
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 48
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 52
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 52
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 53
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 53
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 54
ERROR - 2022-08-17 08:34:33 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log_billing.php 54
ERROR - 2022-08-17 08:35:52 --> Severity: Warning --> mysqli::query(): (21000/1242): Subquery returns more than 1 row C:\xampp\htdocs\brienza_backup\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2022-08-17 08:35:52 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-17 08:36:58 --> 404 Page Not Found: /index
ERROR - 2022-08-17 08:37:24 --> Severity: Warning --> mysqli::query(): (21000/1242): Subquery returns more than 1 row C:\xampp\htdocs\brienza_backup\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2022-08-17 08:37:24 --> Query error: Subquery returns more than 1 row - Invalid query: SELECT `order_schedules`.*, `orders`.`order_no`, `orders`.`school_id`, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `order_schedule_status_log`.`attachment`, `log`.`attachment` AS `log_attachment`, `order_schedule_status_log`.`content`, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND new_status="Log sent - awaiting principal signature" AND old_status="Create log") AS create_log_content, (SELECT content FROM order_schedule_status_log WHERE order_schedules.id = order_schedule_status_log.order_schedule_id AND old_status="Log sent - awaiting principal signature" AND new_status="Awaiting Review") AS log_signature, `users`.`first_name`, `users`.`last_name`
FROM `order_schedules`
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT JOIN `order_schedule_status_log` AS `log` ON `order_schedules`.`id` = `log`.`order_schedule_id` AND `log`.`old_status` = 'Log sent - awaiting principal signature'
LEFT OUTER JOIN `users` ON `users`.`id` = `order_schedules`.`created_by`
WHERE `order_schedules`.`id` = 1955
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-08-17 09:33:54 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:34:16 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:34:19 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:34:34 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:34:38 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:34:43 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:34:46 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:34:47 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:37:12 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:38:08 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:38:27 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:38:43 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:41:19 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:41:22 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:41:32 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:42:06 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:42:09 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:42:18 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:48:26 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:48:45 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:49:31 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:49:34 --> 404 Page Not Found: /index
ERROR - 2022-08-17 09:49:45 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:42:56 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:42:59 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:43:02 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:43:06 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:43:17 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:43:20 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:43:23 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:43:25 --> 404 Page Not Found: /index
ERROR - 2022-08-17 11:43:28 --> 404 Page Not Found: /index
