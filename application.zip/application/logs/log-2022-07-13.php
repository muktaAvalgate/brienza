<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-13 07:57:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'wyktsmhg_baalivepro_july' C:\xampp\htdocs\brienza_backup\brienza_backup\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2022-07-13 07:57:22 --> Unable to connect to the database
