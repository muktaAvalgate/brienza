<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-22 12:03:33 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:03:49 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:04:04 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-22 12:04:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-22 12:04:08 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:08:19 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:09:55 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:19:25 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-22 12:19:28 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:39:18 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:39:22 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:39:27 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:39:29 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:39:32 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:55:19 --> Severity: Notice --> Undefined index: profile_pic C:\xampp\htdocs\brienza\application\modules\App\controllers\Schools.php 333
ERROR - 2022-02-22 12:55:23 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:55:37 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:56:32 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:56:34 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:57:44 --> 404 Page Not Found: /index
ERROR - 2022-02-22 12:58:11 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:31:12 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:31:15 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:33:18 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:33:18 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:51:50 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:51:50 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:52:44 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:52:45 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:53:41 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:53:41 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:54:03 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:54:04 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:56:35 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:56:36 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:59:50 --> 404 Page Not Found: /index
ERROR - 2022-02-22 13:59:51 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:01:28 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:01:28 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:01:36 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:01:37 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:01:41 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:01:41 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:02:11 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:02:11 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:02:17 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:02:17 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:02:29 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:02:29 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:04:36 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:04:37 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:06:52 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:06:53 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:08:48 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:08:49 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:10:26 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:10:27 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:17:21 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:17:22 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:17:39 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:17:39 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:19:49 --> 404 Page Not Found: /index
ERROR - 2022-02-22 14:19:49 --> 404 Page Not Found: /index
