<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-15 06:13:17 --> 404 Page Not Found: /index
ERROR - 2022-11-15 06:13:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-15 06:13:36 --> 404 Page Not Found: /index
ERROR - 2022-11-15 06:23:27 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-15 06:23:30 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-15 07:08:11 --> 404 Page Not Found: /index
ERROR - 2022-11-15 07:22:04 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-15 07:22:13 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-15 07:22:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-15 07:22:17 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-15 07:22:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-15 08:56:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-15 08:56:35 --> 404 Page Not Found: ../modules/App/controllers/Presenters/%3Cdiv%20style=
ERROR - 2022-11-15 08:56:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-15 08:56:58 --> 404 Page Not Found: /index
ERROR - 2022-11-15 09:02:56 --> 404 Page Not Found: /index
ERROR - 2022-11-15 10:34:27 --> 404 Page Not Found: /index
ERROR - 2022-11-15 10:37:47 --> 404 Page Not Found: /index
ERROR - 2022-11-15 10:40:39 --> 404 Page Not Found: /index
ERROR - 2022-11-15 10:42:22 --> 404 Page Not Found: /index
ERROR - 2022-11-15 10:42:35 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:05:25 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:05:34 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:05:37 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:22:19 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:22:34 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:22:40 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:22:54 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:23:05 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:39:58 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:43:24 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:43:42 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:43:46 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:44:02 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:45:09 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:46:05 --> 404 Page Not Found: /index
ERROR - 2022-11-15 11:49:49 --> 404 Page Not Found: ../modules/App/controllers/Presenters/favorite_template_edit
ERROR - 2022-11-15 12:06:59 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2776
ERROR - 2022-11-15 12:07:01 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2776
ERROR - 2022-11-15 12:08:56 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2775
ERROR - 2022-11-15 12:58:18 --> 404 Page Not Found: /index
ERROR - 2022-11-15 12:58:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-15 12:58:33 --> 404 Page Not Found: /index
ERROR - 2022-11-15 12:58:42 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:52:09 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:52:51 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:53:00 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:53:10 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:53:18 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:53:22 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:53:27 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:53:29 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:53:34 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:20 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:25 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:29 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:32 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:35 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:38 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:41 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:44 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:49 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:51 --> 404 Page Not Found: /index
ERROR - 2022-11-15 13:55:56 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:01:15 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:01:18 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:02:24 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:02:30 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:02:37 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:02:41 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:04:28 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:08:42 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:08:45 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:08:49 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:08:51 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:09:58 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:11:03 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:11:47 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:11:50 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:11:56 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:12:52 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:12:56 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:12:59 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:13:03 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:13:06 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:13:13 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:19:07 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:36:33 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:36:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-15 14:36:49 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-15 14:36:50 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:36:53 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:36:56 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:38:02 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:41:21 --> Severity: Notice --> Undefined variable: popup C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-15 14:41:22 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:44:01 --> Severity: Notice --> Undefined variable: popup C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-15 14:44:01 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:44:06 --> 404 Page Not Found: /index
ERROR - 2022-11-15 14:44:06 --> 404 Page Not Found: /index
