<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-01 11:42:33 --> 404 Page Not Found: /index
ERROR - 2022-03-01 12:24:02 --> 404 Page Not Found: /index
ERROR - 2022-03-01 12:39:12 --> 404 Page Not Found: /index
ERROR - 2022-03-01 12:39:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-01 12:39:23 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-01 12:39:24 --> 404 Page Not Found: /index
ERROR - 2022-03-01 12:39:34 --> 404 Page Not Found: /index
