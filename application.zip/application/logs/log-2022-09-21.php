<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-21 07:27:54 --> 404 Page Not Found: /index
ERROR - 2022-09-21 07:28:01 --> 404 Page Not Found: /index
ERROR - 2022-09-21 07:30:18 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-21 07:30:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:30:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:30:24 --> 404 Page Not Found: /index
ERROR - 2022-09-21 07:30:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-21 07:30:35 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-21 07:30:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:30:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:30:52 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-21 07:30:52 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-21 07:30:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:30:53 --> 404 Page Not Found: /index
ERROR - 2022-09-21 07:36:21 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-21 07:36:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-21 07:36:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:36:24 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-21 07:36:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:36:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:36:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:36:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:36:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 07:36:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 08:15:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 08:15:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-21 08:30:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-21 08:31:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 08:34:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 11:39:12 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:39:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-21 11:39:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 11:39:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:39:25 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:39:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 11:39:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:39:29 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:39:29 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:45:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 11:45:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:45:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:45:51 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:46:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 11:46:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:46:10 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:46:10 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:46:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 11:46:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:46:15 --> 404 Page Not Found: /index
ERROR - 2022-09-21 11:47:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 11:47:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:47:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 11:47:28 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:26:14 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-21 12:26:15 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-21 12:26:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:26:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:26:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:26:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:26:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:26:51 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-09-21 12:26:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-09-21 12:26:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:26:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:26:52 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-21 12:26:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:27:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:27:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:27:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:27:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:27:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:28:02 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-09-21 12:28:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-09-21 12:28:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:28:02 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-21 12:28:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:28:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:28:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:28:33 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-21 12:31:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-21 12:31:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:31:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:31:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:32:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:32:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:32:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:32:56 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:33:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:33:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:33:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:33:54 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:34:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2397
ERROR - 2022-09-21 12:34:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:34:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:34:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:34:37 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:34:59 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2397
ERROR - 2022-09-21 12:36:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:36:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:36:14 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:36:14 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:36:17 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2441
ERROR - 2022-09-21 12:36:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2442
ERROR - 2022-09-21 12:36:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:36:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:36:17 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 8
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 11
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 24
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 38
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:37:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:37:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:37:35 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-21 12:37:36 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 8
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 11
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 24
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 38
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:37:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:37:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:37:58 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-21 12:37:58 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:38:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:38:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:01 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 8
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 11
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 24
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 38
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:38:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:02 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-21 12:38:02 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 8
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 11
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 24
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 38
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:38:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:42 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-21 12:38:42 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 8
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 11
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 24
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 38
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:38:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:43 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-21 12:38:43 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:38:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:38:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:45 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 8
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 11
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 24
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: folder C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 38
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:38:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:38:48 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-09-21 12:38:48 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:44:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:44:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:44:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:44:53 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:45:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:45:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:45:13 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:45:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:45:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:45:16 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:45:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:45:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:45:18 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:47:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:47:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:47:01 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:47:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:47:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:47:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:47:45 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:48:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:48:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:48:11 --> 404 Page Not Found: /index
ERROR - 2022-09-21 12:48:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 12:48:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:48:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 12:48:16 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:02:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:02:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:02:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:02:38 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:02:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:02:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:02:45 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-21 14:03:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-21 14:03:41 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-21 14:03:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:03:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:03:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:04:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:04:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:04:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:04:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:04:30 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:19:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:19:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:19:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:20 --> Severity: Notice --> Undefined variable: purchase_orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 98
ERROR - 2022-09-21 14:19:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 98
ERROR - 2022-09-21 14:19:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:19:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:19:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:36 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-21 14:19:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:19:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:19:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:19:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:19:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:20:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:20:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:20:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:20:13 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:21:54 --> Severity: Notice --> Undefined variable: s_array C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 12
ERROR - 2022-09-21 14:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 12
ERROR - 2022-09-21 14:21:54 --> Severity: Notice --> Undefined variable: totHoursAssgnd C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 25
ERROR - 2022-09-21 14:21:54 --> Severity: Notice --> Undefined variable: totHoursSchedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 28
ERROR - 2022-09-21 14:21:54 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 65
ERROR - 2022-09-21 14:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 65
ERROR - 2022-09-21 14:21:54 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 93
ERROR - 2022-09-21 14:21:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 93
ERROR - 2022-09-21 14:21:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:21:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:21:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:21:54 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:23:05 --> Severity: Notice --> Undefined variable: s_array C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 12
ERROR - 2022-09-21 14:23:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 12
ERROR - 2022-09-21 14:23:05 --> Severity: Notice --> Undefined variable: totHoursAssgnd C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 25
ERROR - 2022-09-21 14:23:05 --> Severity: Notice --> Undefined variable: totHoursSchedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 28
ERROR - 2022-09-21 14:23:05 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 65
ERROR - 2022-09-21 14:23:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 65
ERROR - 2022-09-21 14:23:05 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 93
ERROR - 2022-09-21 14:23:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 93
ERROR - 2022-09-21 14:23:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:23:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:23:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:23:06 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:23:33 --> Severity: Notice --> Undefined variable: s_array C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 12
ERROR - 2022-09-21 14:23:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 12
ERROR - 2022-09-21 14:23:33 --> Severity: Notice --> Undefined variable: totHoursAssgnd C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 25
ERROR - 2022-09-21 14:23:33 --> Severity: Notice --> Undefined variable: totHoursSchedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 28
ERROR - 2022-09-21 14:23:33 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 65
ERROR - 2022-09-21 14:23:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 65
ERROR - 2022-09-21 14:23:33 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 93
ERROR - 2022-09-21 14:23:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 93
ERROR - 2022-09-21 14:23:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:23:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:23:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:23:33 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:24:12 --> Severity: Notice --> Undefined variable: totHoursAssgnd C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 12
ERROR - 2022-09-21 14:24:12 --> Severity: Notice --> Undefined variable: totHoursSchedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 15
ERROR - 2022-09-21 14:24:12 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 52
ERROR - 2022-09-21 14:24:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 52
ERROR - 2022-09-21 14:24:12 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 80
ERROR - 2022-09-21 14:24:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 80
ERROR - 2022-09-21 14:24:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:24:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:24:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:24:12 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:24:45 --> Severity: Notice --> Undefined variable: totHoursAssgnd C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 18
ERROR - 2022-09-21 14:24:45 --> Severity: Notice --> Undefined variable: totHoursSchedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 21
ERROR - 2022-09-21 14:24:45 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 58
ERROR - 2022-09-21 14:24:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 58
ERROR - 2022-09-21 14:24:45 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 86
ERROR - 2022-09-21 14:24:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 86
ERROR - 2022-09-21 14:24:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:24:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:24:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:24:45 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:25:01 --> Severity: Notice --> Undefined variable: totHoursAssgnd C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 20
ERROR - 2022-09-21 14:25:01 --> Severity: Notice --> Undefined variable: totHoursSchedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 23
ERROR - 2022-09-21 14:25:01 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 60
ERROR - 2022-09-21 14:25:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 60
ERROR - 2022-09-21 14:25:01 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 88
ERROR - 2022-09-21 14:25:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 88
ERROR - 2022-09-21 14:25:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:25:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:25:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:25:02 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:26:01 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 53
ERROR - 2022-09-21 14:26:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 53
ERROR - 2022-09-21 14:26:01 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 81
ERROR - 2022-09-21 14:26:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 81
ERROR - 2022-09-21 14:26:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:26:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:26:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:26:02 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:26:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:26:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:26:18 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-21 14:26:18 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:26:22 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 53
ERROR - 2022-09-21 14:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 53
ERROR - 2022-09-21 14:26:22 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 81
ERROR - 2022-09-21 14:26:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 81
ERROR - 2022-09-21 14:26:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:26:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:26:23 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:27:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:27:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:27:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:27:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:27:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:27:16 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:27:17 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:27:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:27:18 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:27:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:27:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:27:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:27:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:27:18 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:27:37 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:27:37 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:27:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:27:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:27:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:27:38 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:28:06 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:28:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:28:06 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:28:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:28:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:28:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:28:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:28:07 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:28:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:28:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:28:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:28:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:28:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:28:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:28:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:28:17 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:28:44 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:28:44 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:28:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:28:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:28:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:28:44 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:35:56 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:35:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 34
ERROR - 2022-09-21 14:35:56 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:35:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 62
ERROR - 2022-09-21 14:35:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:35:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:35:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:35:56 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:37:45 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 36
ERROR - 2022-09-21 14:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 36
ERROR - 2022-09-21 14:37:45 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 64
ERROR - 2022-09-21 14:37:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 64
ERROR - 2022-09-21 14:37:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:37:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:37:46 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:38:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:38:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:38:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:38:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:19 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-21 14:38:19 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-21 14:38:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:38:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:38:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:38:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:35 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:38:38 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 36
ERROR - 2022-09-21 14:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 36
ERROR - 2022-09-21 14:38:38 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 64
ERROR - 2022-09-21 14:38:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 64
ERROR - 2022-09-21 14:38:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:38:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:38:39 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:40:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:40:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:40:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:40:05 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:40:06 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 36
ERROR - 2022-09-21 14:40:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 36
ERROR - 2022-09-21 14:40:06 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 64
ERROR - 2022-09-21 14:40:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 64
ERROR - 2022-09-21 14:40:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:40:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:40:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:40:07 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:42:35 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:35 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:42:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:35 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:42:38 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:38 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:42:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:38 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:42:39 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:39 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:42:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:40 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:42:40 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:40 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:42:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:41 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:42:43 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:43 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:42:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:43 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:42:44 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:44 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:42:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:45 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:42:46 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:42:46 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:42:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:42:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:42:47 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:43:20 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:43:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:43:20 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:43:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:43:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:43:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:43:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:43:20 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:43:39 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:43:39 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:43:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:43:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:43:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:43:39 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:43:52 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:43:52 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:43:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:43:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:43:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:43:52 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:44:00 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:44:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:44:00 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:44:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:44:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:44:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:44:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:44:00 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:44:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:44:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:44:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:44:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:44:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:44:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:44:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:44:16 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:44:17 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:44:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:44:17 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:44:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:44:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:44:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:44:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:44:18 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:49:53 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:49:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:49:53 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:49:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:49:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:49:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:49:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:49:53 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:49:54 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:49:54 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:49:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:49:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:49:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:49:57 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:49:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:49:57 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:49:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:49:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:49:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:49:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:11 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:11 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:50:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:12 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:50:14 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:14 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:50:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:15 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:50:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:50:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:15 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:50:17 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:17 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:50:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:17 --> 404 Page Not Found: /index
ERROR - 2022-09-21 14:50:20 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-09-21 14:50:20 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-09-21 14:50:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 177
ERROR - 2022-09-21 14:50:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 181
ERROR - 2022-09-21 14:50:20 --> 404 Page Not Found: /index
