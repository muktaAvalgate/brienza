<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-22 06:11:47 --> 404 Page Not Found: /index
ERROR - 2022-03-22 06:17:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-22 06:17:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-22 06:17:12 --> 404 Page Not Found: /index
ERROR - 2022-03-22 06:17:55 --> 404 Page Not Found: /index
ERROR - 2022-03-22 06:18:18 --> 404 Page Not Found: /index
ERROR - 2022-03-22 06:49:27 --> 404 Page Not Found: /index
ERROR - 2022-03-22 06:49:27 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:07:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:10 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:11 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:12 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:12 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:21 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:21 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:25 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:25 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:27 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:27 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:29 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:29 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:30 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:31 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:34 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:35 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:36 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:21:36 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:25:26 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-22 07:25:28 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:27:34 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:28:12 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:28:18 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:28:57 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:29:00 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:29:31 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:29:45 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:29:46 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:29:47 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:29:48 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:31:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:31:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:46:34 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:46:34 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:46:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 07:46:48 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 07:47:00 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:47:00 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:47:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:47:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:47:48 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:47:48 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:47:59 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:48:00 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:48:34 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:48:34 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:49:28 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:49:28 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:49:30 --> 404 Page Not Found: /index
ERROR - 2022-03-22 07:49:31 --> 404 Page Not Found: /index
ERROR - 2022-03-22 08:04:22 --> 404 Page Not Found: /index
ERROR - 2022-03-22 08:04:23 --> 404 Page Not Found: /index
ERROR - 2022-03-22 09:34:47 --> 404 Page Not Found: /index
ERROR - 2022-03-22 09:34:47 --> 404 Page Not Found: /index
ERROR - 2022-03-22 10:29:23 --> 404 Page Not Found: /index
ERROR - 2022-03-22 10:29:23 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:09:35 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:09:36 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:40:38 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:40:46 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-22 11:40:48 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:41:30 --> 404 Page Not Found: /index
ERROR - 2022-03-22 11:41:32 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:27:52 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:27:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-22 13:28:00 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-22 13:28:00 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:11 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:13 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:15 --> Severity: Notice --> Undefined variable: purchase_orders C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-03-22 13:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-03-22 13:28:15 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:16 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:18 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:19 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:21 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 13:28:25 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 13:28:30 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:28:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 13:28:38 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 13:33:53 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:33:57 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:34:08 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:34:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 13:34:17 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-22 13:34:23 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:34:26 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:34:28 --> 404 Page Not Found: /index
ERROR - 2022-03-22 13:34:31 --> 404 Page Not Found: /index
