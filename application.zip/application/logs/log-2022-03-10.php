<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-10 06:07:28 --> 404 Page Not Found: /index
ERROR - 2022-03-10 06:08:47 --> 404 Page Not Found: /index
ERROR - 2022-03-10 06:09:02 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-10 06:09:06 --> 404 Page Not Found: /index
ERROR - 2022-03-10 06:09:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-10 06:09:11 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-10 06:09:12 --> 404 Page Not Found: /index
ERROR - 2022-03-10 06:12:06 --> 404 Page Not Found: /index
ERROR - 2022-03-10 06:20:32 --> 404 Page Not Found: /index
ERROR - 2022-03-10 08:22:44 --> 404 Page Not Found: /index
ERROR - 2022-03-10 08:22:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-10 08:22:57 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-10 08:22:58 --> 404 Page Not Found: /index
ERROR - 2022-03-10 08:23:06 --> 404 Page Not Found: /index
ERROR - 2022-03-10 08:23:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-10 08:23:17 --> 404 Page Not Found: /index
ERROR - 2022-03-10 08:23:27 --> 404 Page Not Found: /index
ERROR - 2022-03-10 08:30:23 --> 404 Page Not Found: /index
ERROR - 2022-03-10 08:35:44 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:12:38 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:23:20 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:23:28 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-10 10:23:30 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:23:42 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:26:00 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:27:11 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:28:17 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:28:33 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:28:38 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:28:43 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:29:05 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:39:05 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:48:03 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:48:15 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:48:52 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:50:02 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:50:10 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:50:15 --> 404 Page Not Found: /index
ERROR - 2022-03-10 10:50:18 --> Severity: Notice --> Undefined property: stdClass::$grade_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-03-10 10:50:18 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-03-10 10:50:18 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 217
ERROR - 2022-03-10 10:50:18 --> 404 Page Not Found: /index
ERROR - 2022-03-10 11:26:12 --> 404 Page Not Found: /index
ERROR - 2022-03-10 11:56:35 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:46:59 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:47:27 --> Severity: Notice --> Undefined index: assign_titles C:\xampp\htdocs\brienza\application\modules\Admin\models\Admin_model.php 19
ERROR - 2022-03-10 12:47:31 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:49:26 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:50:06 --> Severity: Notice --> Undefined index: assign_titles C:\xampp\htdocs\brienza\application\modules\Admin\models\Admin_model.php 19
ERROR - 2022-03-10 12:50:28 --> Severity: Notice --> Undefined index: assign_titles C:\xampp\htdocs\brienza\application\modules\Admin\models\Admin_model.php 19
ERROR - 2022-03-10 12:50:32 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:50:35 --> Severity: Notice --> Undefined index: assign_titles C:\xampp\htdocs\brienza\application\modules\Admin\models\Admin_model.php 19
ERROR - 2022-03-10 12:50:46 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:50:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-10 12:50:54 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:51:10 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:51:17 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:53:27 --> 404 Page Not Found: /index
ERROR - 2022-03-10 12:54:49 --> 404 Page Not Found: /index
