<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-23 10:40:15 --> 404 Page Not Found: /index
ERROR - 2021-12-23 10:40:21 --> 404 Page Not Found: /index
ERROR - 2021-12-23 05:40:26 --> Severity: Notice --> Undefined property: CI::$App_model /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/third_party/MX/Controller.php 59
ERROR - 2021-12-23 05:40:26 --> Severity: Error --> Call to a member function get_sessions() on null /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 294
ERROR - 2021-12-23 05:41:56 --> Severity: Notice --> Undefined property: CI::$App_model /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/third_party/MX/Controller.php 59
ERROR - 2021-12-23 05:41:56 --> Severity: Error --> Call to a member function get_sessions() on null /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 294
ERROR - 2021-12-23 05:42:56 --> Query error: Table 'wyktsmhg_baalivepro.sessions' doesn't exist - Invalid query: SELECT *
FROM `sessions`
ERROR - 2021-12-23 05:51:19 --> Query error: Unknown column 'session_id' in 'where clause' - Invalid query: SELECT `id`
FROM `orders`
WHERE `session_id` = '3'
AND `is_deleted` =0
ERROR - 2021-12-23 10:51:20 --> 404 Page Not Found: /index
ERROR - 2021-12-23 11:30:11 --> 404 Page Not Found: /index
ERROR - 2021-12-23 06:30:22 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 06:30:22 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 06:30:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 06:30:36 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 11:31:13 --> 404 Page Not Found: /index
ERROR - 2021-12-23 06:31:18 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 06:31:18 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 06:31:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 06:31:26 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 11:31:44 --> 404 Page Not Found: /index
ERROR - 2021-12-23 11:31:45 --> 404 Page Not Found: /index
ERROR - 2021-12-23 06:31:58 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 06:31:58 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 621
ERROR - 2021-12-23 12:29:44 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:29:52 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:30:01 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:30:04 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:30:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 55
ERROR - 2021-12-23 07:30:06 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 58
ERROR - 2021-12-23 12:30:07 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:32:33 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:32:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 625
ERROR - 2021-12-23 07:32:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 625
ERROR - 2021-12-23 07:32:43 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 55
ERROR - 2021-12-23 07:32:43 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 58
ERROR - 2021-12-23 12:32:44 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:36:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 55
ERROR - 2021-12-23 07:36:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 58
ERROR - 2021-12-23 12:36:31 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:36:39 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:36:45 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 55
ERROR - 2021-12-23 07:36:45 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 58
ERROR - 2021-12-23 12:36:45 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:45:14 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:46:00 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 55
ERROR - 2021-12-23 07:46:00 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/billings.php 58
ERROR - 2021-12-23 12:46:00 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:52:55 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:52:58 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:53:00 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:53:02 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:53:04 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:53:12 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:53:14 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/list.php 62
ERROR - 2021-12-23 07:53:14 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/list.php 65
ERROR - 2021-12-23 12:53:14 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:53:56 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:53:59 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:54:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-23 12:54:10 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:54:18 --> 404 Page Not Found: /index
ERROR - 2021-12-23 12:58:35 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:59:02 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 641
ERROR - 2021-12-23 07:59:02 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 641
ERROR - 2021-12-23 12:59:04 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:59:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-23 12:59:10 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:59:12 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 641
ERROR - 2021-12-23 07:59:12 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/controllers/Auth.php 641
ERROR - 2021-12-23 12:59:20 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:59:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/orders.php 12
ERROR - 2021-12-23 07:59:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/orders.php 15
ERROR - 2021-12-23 12:59:23 --> 404 Page Not Found: /index
ERROR - 2021-12-23 07:59:29 --> Severity: Error --> Call to undefined method App_model::getSessionIdByOdrId() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 903
ERROR - 2021-12-23 08:00:55 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 4218
ERROR - 2021-12-23 08:00:55 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 905
ERROR - 2021-12-23 08:00:55 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 906
ERROR - 2021-12-23 08:00:55 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:00:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:01:14 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/orders.php 12
ERROR - 2021-12-23 08:01:14 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/orders.php 15
ERROR - 2021-12-23 13:01:15 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:01:16 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:01:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 4218
ERROR - 2021-12-23 08:01:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 905
ERROR - 2021-12-23 08:01:17 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 906
ERROR - 2021-12-23 08:01:17 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:01:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 13:02:47 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:02:50 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:02:55 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:02:59 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 4218
ERROR - 2021-12-23 08:02:59 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 905
ERROR - 2021-12-23 08:02:59 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 906
ERROR - 2021-12-23 08:02:59 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:02:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:11:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 4218
ERROR - 2021-12-23 08:11:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 905
ERROR - 2021-12-23 08:11:51 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 906
ERROR - 2021-12-23 08:11:51 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 13:11:51 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:11:54 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:11:58 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:12:02 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:12:11 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 4218
ERROR - 2021-12-23 08:12:11 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 905
ERROR - 2021-12-23 08:12:11 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 906
ERROR - 2021-12-23 08:12:11 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:31:34 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 13:31:34 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:31:36 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:31:39 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:31:40 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 08:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-23 13:31:40 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:31:42 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:31:43 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:31:47 --> Severity: Error --> Call to undefined method App_model::get_orders_by_presenters_sessionwise() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 1303
ERROR - 2021-12-23 13:31:47 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:35:03 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:35:07 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/presenter_billing.php 51
ERROR - 2021-12-23 08:35:07 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/presenter_billing.php 54
ERROR - 2021-12-23 13:35:07 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:35:21 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:35:27 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:35:30 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/calendar.php 13
ERROR - 2021-12-23 08:35:30 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/calendar.php 16
ERROR - 2021-12-23 13:35:31 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:36:06 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:36:48 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:36:58 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:37:07 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:37:14 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:37:26 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:37:34 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:37:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/list.php 62
ERROR - 2021-12-23 08:37:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/list.php 65
ERROR - 2021-12-23 13:37:38 --> 404 Page Not Found: /index
ERROR - 2021-12-23 08:43:56 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/list.php 62
ERROR - 2021-12-23 08:43:56 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/orders/list.php 65
ERROR - 2021-12-23 13:43:57 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:44:53 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:44:58 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:45:03 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:45:05 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:45:08 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:45:10 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:45:18 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:45:28 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:51:59 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:52:35 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:53:07 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:53:13 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:56:00 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:56:04 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:56:23 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:56:23 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:59:33 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:59:34 --> 404 Page Not Found: /index
ERROR - 2021-12-23 13:59:38 --> 404 Page Not Found: /index
ERROR - 2021-12-23 09:08:42 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/calendar.php 13
ERROR - 2021-12-23 09:08:42 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/calendar.php 16
ERROR - 2021-12-23 14:08:45 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:08:53 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:08:57 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:09:03 --> 404 Page Not Found: /index
ERROR - 2021-12-23 09:09:04 --> Severity: Error --> Call to undefined method App_model::getSessionIdByOdrId() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Presenters.php 785
ERROR - 2021-12-23 14:09:04 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:14:19 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:14:55 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:14:59 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:15:07 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:15:07 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:18:40 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:18:41 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:18:44 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:18:58 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:19:02 --> 404 Page Not Found: /index
ERROR - 2021-12-23 14:19:02 --> 404 Page Not Found: /index
