<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-11 06:08:59 --> 404 Page Not Found: /index
ERROR - 2022-01-11 01:09:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2022-01-11 06:09:28 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:09:35 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:09:41 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:09:51 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:09:56 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:10:21 --> 404 Page Not Found: /index
ERROR - 2022-01-11 01:10:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2022-01-11 06:10:33 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:11:11 --> 404 Page Not Found: /index
ERROR - 2022-01-11 01:11:46 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2022-01-11 06:11:47 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:11:58 --> 404 Page Not Found: /index
ERROR - 2022-01-11 06:12:02 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:47:50 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:47:54 --> 404 Page Not Found: /index
ERROR - 2022-01-11 07:48:03 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2022-01-11 12:48:04 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:07 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:13 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:14 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:16 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:17 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:20 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:48 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:51 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:54 --> 404 Page Not Found: /index
ERROR - 2022-01-11 12:48:58 --> 404 Page Not Found: /index
