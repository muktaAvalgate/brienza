<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-31 07:26:26 --> 404 Page Not Found: /index
