<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-06 14:36:19 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:38:35 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-05-06 14:38:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-05-06 14:38:40 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:38:51 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:39:08 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:39:08 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:41:19 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:41:22 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:42:39 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:42:43 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:43:46 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:44:22 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:44:34 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:44:54 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:44:56 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:46:27 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:46:29 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:50:46 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:50:48 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:54:41 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:54:42 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:55:14 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:55:16 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:57:09 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:57:10 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:57:51 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:57:52 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:59:35 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:59:36 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:59:51 --> 404 Page Not Found: /index
ERROR - 2022-05-06 14:59:53 --> 404 Page Not Found: /index
ERROR - 2022-05-06 15:00:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND DATE_FORMAT(order_schedules.start_date, "%Y-%m-%d") < `IS` `NULL`
...' at line 10 - Invalid query: SELECT `order_schedules`.*, DATE_FORMAT(order_schedules.start_date, "%Y-%m-%d") AS start_date_ymd, `grades`.`name` AS `grade_name`, `worktypes`.`name` AS `worktype_name`, `title_topics`.`topic` AS `topic_name`, `title_topics`.`description` AS `topic_description`, `order_schedule_status_log`.`attachment`, `order_schedule_status_log`.`content`, `order_schedule_status_log`.`id` AS `order_schedule_status_id`, `order_schedule_status_log`.`order_schedule_id`, `orders`.`school_id`, `user_meta`.`meta_value` AS `school_color`, `p_rate`.`meta_value` as `hourly_rate`
FROM `order_schedules`
LEFT JOIN `user_meta` AS `p_rate` ON `order_schedules`.`created_by` = `p_rate`.`user_id` AND `p_rate`.`meta_key` = 'rate'
LEFT JOIN `title_topics` ON `order_schedules`.`topic_id` = `title_topics`.`id`
LEFT JOIN `grades` ON `order_schedules`.`grade_id` = `grades`.`id`
LEFT JOIN `worktypes` ON `order_schedules`.`type_id` = `worktypes`.`id`
LEFT JOIN `orders` ON `order_schedules`.`order_id` = `orders`.`id`
LEFT JOIN `order_schedule_status_log` ON `order_schedules`.`id` = `order_schedule_status_log`.`order_schedule_id` AND `order_schedule_status_log`.`new_status` = `order_schedules`.`status`
LEFT OUTER JOIN `user_meta` ON `user_meta`.`user_id` = `orders`.`school_id` AND `user_meta`.`meta_key` = 'school_color'
WHERE DATE_FORMAT(order_schedules.start_date, "%Y-%m-%d") > `IS` `NULL`
AND DATE_FORMAT(order_schedules.start_date, "%Y-%m-%d") < `IS` `NULL`
AND `order_schedules`.`created_by` = '15'
GROUP BY `order_schedules`.`id`
ORDER BY `order_schedules`.`start_date` ASC
ERROR - 2022-05-06 15:01:11 --> 404 Page Not Found: /index
ERROR - 2022-05-06 15:05:25 --> 404 Page Not Found: /index
ERROR - 2022-05-06 15:06:43 --> 404 Page Not Found: /index
