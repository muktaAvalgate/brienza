<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-26 07:22:40 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:29:01 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:34:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-26 07:34:58 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-04-26 07:35:00 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:35:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-26 07:35:15 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:48:57 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:49:05 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:52:28 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:52:42 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:52:45 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:53:49 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:54:07 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:54:14 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:54:18 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:54:37 --> Severity: Notice --> Undefined index: profile_pic C:\xampp\htdocs\brienza\application\modules\App\controllers\Schools.php 333
ERROR - 2022-04-26 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:54:49 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:54:52 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:57:39 --> 404 Page Not Found: /index
ERROR - 2022-04-26 07:59:14 --> 404 Page Not Found: /index
ERROR - 2022-04-26 08:55:15 --> 404 Page Not Found: /index
ERROR - 2022-04-26 08:55:23 --> 404 Page Not Found: /index
ERROR - 2022-04-26 08:55:33 --> 404 Page Not Found: /index
ERROR - 2022-04-26 08:55:36 --> 404 Page Not Found: /index
ERROR - 2022-04-26 08:55:40 --> 404 Page Not Found: /index
ERROR - 2022-04-26 08:55:41 --> 404 Page Not Found: /index
ERROR - 2022-04-26 09:48:30 --> 404 Page Not Found: /index
ERROR - 2022-04-26 09:48:30 --> 404 Page Not Found: /index
ERROR - 2022-04-26 09:49:05 --> 404 Page Not Found: /index
ERROR - 2022-04-26 13:14:37 --> 404 Page Not Found: /index
ERROR - 2022-04-26 13:14:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-26 13:14:50 --> 404 Page Not Found: /index
ERROR - 2022-04-26 13:14:56 --> 404 Page Not Found: /index
ERROR - 2022-04-26 13:14:58 --> 404 Page Not Found: /index
ERROR - 2022-04-26 13:43:01 --> 404 Page Not Found: /index
ERROR - 2022-04-26 13:43:20 --> 404 Page Not Found: /index
