<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-20 07:36:51 --> 404 Page Not Found: /index
ERROR - 2022-10-20 07:37:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-20 07:37:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 07:37:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 07:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 07:37:29 --> 404 Page Not Found: /index
ERROR - 2022-10-20 07:44:13 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-20 07:44:15 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-10-20 07:44:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 07:44:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 07:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 07:46:11 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 07:46:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 07:46:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 07:46:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 07:46:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:12:16 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:12:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:12:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:12:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:12:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:12:34 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:12:34 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:12:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:12:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:12:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:15:07 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:15:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:15:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:15:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:32:36 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:32:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 08:32:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:32:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:36:54 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:37:27 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:37:33 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:37:46 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:37:49 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:38:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:38:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:38:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:38:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:38:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:38:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:39:09 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:39:32 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:39:38 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:39:49 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:43:22 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:43:53 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:44:00 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:44:15 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:44:21 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:45:09 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:45:17 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:45:26 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:45:47 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:45:51 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:46:06 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:46:09 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:48:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:48:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:48:53 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:49:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:49:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 08:49:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-20 08:49:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:49:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-20 08:49:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 08:49:47 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:49:58 --> 404 Page Not Found: /index
ERROR - 2022-10-20 08:54:05 --> 404 Page Not Found: /index
ERROR - 2022-10-20 09:00:25 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:00:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:00:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:00:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:00:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:08:59 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:08:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:08:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:08:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:09:01 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5101
ERROR - 2022-10-20 09:09:01 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:01 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:01 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:01 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-10-20 09:09:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-10-20 09:09:03 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:09:03 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:09:03 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:09:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:09:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:09:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5101
ERROR - 2022-10-20 09:09:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:06 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-10-20 09:09:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-10-20 09:09:15 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:09:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:09:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:09:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:09:48 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:09:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:09:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:09:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:09:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:09:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5101
ERROR - 2022-10-20 09:09:50 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:50 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:50 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:50 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:09:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-10-20 09:09:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-10-20 09:10:24 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:10:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:10:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:10:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:10:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:10:26 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:10:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:10:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:10:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:10:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:11:16 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:11:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:11:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:11:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:11:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:11:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5101
ERROR - 2022-10-20 09:11:18 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:11:18 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:11:18 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:11:18 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5102
ERROR - 2022-10-20 09:11:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-10-20 09:11:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-10-20 09:20:18 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:20:18 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:20:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:20:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:20:20 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5232
ERROR - 2022-10-20 09:20:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5233
ERROR - 2022-10-20 09:20:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5233
ERROR - 2022-10-20 09:20:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5233
ERROR - 2022-10-20 09:20:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5233
ERROR - 2022-10-20 09:20:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-10-20 09:20:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-10-20 09:20:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 09:20:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:20:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:20:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:20:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 09:20:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 09:20:46 --> 404 Page Not Found: /index
ERROR - 2022-10-20 09:33:03 --> 404 Page Not Found: /index
ERROR - 2022-10-20 11:16:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 11:16:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:16:02 --> 404 Page Not Found: /index
ERROR - 2022-10-20 11:16:22 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:16:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:16:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 11:16:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:16:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:16:24 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5354
ERROR - 2022-10-20 11:16:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5355
ERROR - 2022-10-20 11:16:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5355
ERROR - 2022-10-20 11:16:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5355
ERROR - 2022-10-20 11:16:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5355
ERROR - 2022-10-20 11:16:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-10-20 11:16:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-10-20 11:16:28 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:16:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:16:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 11:16:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:43:36 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:43:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:43:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 11:43:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:54:20 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:54:20 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:54:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 11:54:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:54:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:54:45 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:54:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 11:54:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 11:54:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:54:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:55:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 11:55:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 11:55:19 --> 404 Page Not Found: /index
ERROR - 2022-10-20 11:55:19 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:01:09 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 12:01:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-10-20 12:01:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:01:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:22:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:40 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:40 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:22:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:41 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:22:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:48 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:48 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:22:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:50 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:22:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:54 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:54 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:22:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:22:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:22:57 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:25:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:25:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:25:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:25:11 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:25:11 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:31:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:31:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:31:22 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:31:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:31:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:31:25 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:25 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:38 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:38 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 12:31:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 12:31:50 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:50 --> 404 Page Not Found: /index
ERROR - 2022-10-20 12:31:51 --> 404 Page Not Found: /index
ERROR - 2022-10-20 13:51:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 13:51:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 13:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 13:51:30 --> 404 Page Not Found: /index
ERROR - 2022-10-20 13:51:36 --> 404 Page Not Found: /index
ERROR - 2022-10-20 13:51:36 --> 404 Page Not Found: /index
ERROR - 2022-10-20 14:55:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 14:55:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 14:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 14:55:15 --> 404 Page Not Found: /index
ERROR - 2022-10-20 14:55:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 14:55:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 14:55:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 14:55:28 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-20 14:55:28 --> 404 Page Not Found: /index
ERROR - 2022-10-20 14:55:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-20 14:55:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 14:55:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-20 14:55:56 --> 404 Page Not Found: /index
