<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-11 07:32:01 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:32:54 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:33:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-11 07:33:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:33:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:33:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:33:31 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:33:43 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-11 07:33:46 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-10-11 07:33:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:33:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:33:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:34:01 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:34:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-11 07:34:08 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-10-11 07:34:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:34:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:34:09 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:37:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:37:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:37:49 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:37:50 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:37:52 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:37:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:37:52 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:37:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:37:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:37:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:37:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:37:52 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:37:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:37:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:37:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:00 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-11 07:38:00 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:38:05 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:38:05 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:38:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:38:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:38:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:05 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:38:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:38:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:11 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:38:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:38:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:38:16 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:38:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:38:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:38:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:16 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:38:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:38:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:38:21 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-11 07:38:21 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:40:39 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:40:39 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:40:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:40:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:40:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:40:39 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:41:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:41:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:41:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:41:39 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:48:52 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:48:53 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:48:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:48:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:48:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:48:53 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:49:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:49:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:49:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:49:01 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-11 07:49:01 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:50:37 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:50:37 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:50:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:50:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:50:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:50:37 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:51:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:51:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:51:30 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-11 07:51:30 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:52:19 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:52:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 45
ERROR - 2022-10-11 07:52:19 --> Severity: Notice --> Undefined variable: orders C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:52:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_templates.php 73
ERROR - 2022-10-11 07:52:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:52:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:52:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:52:19 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:53:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:53:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:53:32 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-11 07:53:32 --> 404 Page Not Found: /index
ERROR - 2022-10-11 07:55:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-11 07:55:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:55:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-11 07:55:56 --> 404 Page Not Found: ../modules/App/controllers/Presenters/css
ERROR - 2022-10-11 07:55:56 --> 404 Page Not Found: /index
