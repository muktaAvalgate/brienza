<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-25 06:21:52 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:22:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-25 06:22:27 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:22:33 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-25 06:22:36 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-25 06:25:19 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:25:25 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:25:32 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:25:38 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:25:41 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:26:27 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:26:48 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:27:03 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-11-25 06:28:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-11-25 06:32:48 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:32:55 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:33:16 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:33:31 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:33:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-25 06:33:53 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-25 06:33:54 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:34:05 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:47:01 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:47:28 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:47:35 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:51:09 --> 404 Page Not Found: /index
ERROR - 2022-11-25 06:51:15 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:15:35 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2844
ERROR - 2022-11-25 07:15:54 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:16:44 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:16:50 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:16:56 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:17:01 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:17:09 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:17:13 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:17:36 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:17:39 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:17:45 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2829
ERROR - 2022-11-25 07:20:37 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2829
ERROR - 2022-11-25 07:20:38 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:20:41 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:20:46 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:20:53 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:20:56 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:27:22 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:27:26 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:27:30 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:27:34 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:28:32 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:28:37 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:28:51 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:30:36 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:30:40 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:36:28 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:36:32 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:39:15 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:39:24 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:44:33 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:44:37 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:44:40 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:44:46 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:44:52 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:44:57 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:45:31 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:45:35 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:47:53 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:48:56 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:49:16 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:49:26 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:49:28 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:49:41 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:49:44 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:49:46 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:50:01 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:50:45 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:51:00 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:51:13 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:51:21 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:51:27 --> 404 Page Not Found: /index
ERROR - 2022-11-25 07:57:30 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:06:39 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:07:08 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:07:18 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:07:20 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:07:49 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:08:35 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:08:40 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:10:28 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:11:20 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:11:23 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:11:57 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:12:18 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:12:22 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:12:39 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:13:38 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:14:07 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:14:45 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:14:47 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:21:30 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:26:10 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:26:28 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:27:05 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:27:42 --> 404 Page Not Found: /index
ERROR - 2022-11-25 08:28:59 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:13:46 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:13:50 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:14:43 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-25 10:14:44 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-25 10:21:27 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:22:37 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:22:52 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:23:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-25 10:23:07 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:23:13 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:23:13 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:23:46 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:45:49 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:46:12 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:46:17 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:46:33 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:46:44 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:48:04 --> 404 Page Not Found: /index
ERROR - 2022-11-25 10:49:19 --> 404 Page Not Found: /index
ERROR - 2022-11-25 11:51:51 --> 404 Page Not Found: /index
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 104
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 104
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 112
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 115
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 115
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 115
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 115
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 155
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 155
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-25 12:09:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-25 13:45:09 --> 404 Page Not Found: /index
ERROR - 2022-11-25 13:45:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-25 13:45:35 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-25 13:45:36 --> 404 Page Not Found: /index
ERROR - 2022-11-25 13:45:42 --> 404 Page Not Found: /index
ERROR - 2022-11-25 13:49:26 --> 404 Page Not Found: /index
