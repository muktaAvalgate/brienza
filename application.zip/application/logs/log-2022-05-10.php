<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-10 15:26:17 --> 404 Page Not Found: /index
ERROR - 2022-05-10 15:26:49 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-05-10 15:26:55 --> 404 Page Not Found: /index
ERROR - 2022-05-10 15:27:15 --> 404 Page Not Found: /index
ERROR - 2022-05-10 15:27:19 --> 404 Page Not Found: /index
ERROR - 2022-05-10 15:34:10 --> 404 Page Not Found: /index
ERROR - 2022-05-10 15:37:39 --> 404 Page Not Found: /index
