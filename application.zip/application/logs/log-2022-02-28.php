<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-28 10:27:22 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:28:04 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:30:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-28 10:30:54 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:31:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-28 10:31:05 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-28 10:31:06 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:31:18 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:31:58 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:07 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:12 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:17 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:20 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:28 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:34 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:37 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:46 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:49 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:54 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:32:58 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:33:01 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:33:04 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:33:11 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:33:56 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:33:59 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:34:02 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:34:05 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:34:08 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:34:15 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:56:22 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:58:15 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:58:21 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:58:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-28 10:58:27 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:59:25 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:59:33 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:59:50 --> 404 Page Not Found: /index
ERROR - 2022-02-28 10:59:54 --> 404 Page Not Found: /index
ERROR - 2022-02-28 11:00:58 --> 404 Page Not Found: /index
ERROR - 2022-02-28 11:01:03 --> 404 Page Not Found: /index
ERROR - 2022-02-28 11:10:49 --> 404 Page Not Found: /index
ERROR - 2022-02-28 11:11:46 --> 404 Page Not Found: /index
ERROR - 2022-02-28 11:12:11 --> 404 Page Not Found: /index
ERROR - 2022-02-28 12:32:55 --> 404 Page Not Found: /index
ERROR - 2022-02-28 12:42:59 --> Severity: error --> Exception: Call to undefined method App_model::getApprovedStatus() C:\xampp\htdocs\brienza\application\modules\App\controllers\Orders.php 2021
ERROR - 2022-02-28 13:41:58 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:42:29 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:42:46 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:42:52 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:42:57 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:43:48 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:49:58 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:50:55 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:53:02 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:53:19 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:57:58 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:58:28 --> 404 Page Not Found: /index
ERROR - 2022-02-28 13:59:53 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:05:14 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:06:41 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:06:49 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-28 14:06:52 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:07:05 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:08:43 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:08:47 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:08:50 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:09:32 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:11:27 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:11:47 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:16:28 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:19:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-28 14:19:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-28 14:21:24 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:21:25 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:21:38 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:21:52 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:22:44 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:22:48 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:23:25 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:24:08 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:24:17 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:24:20 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:24:25 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:29:17 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:29:27 --> 404 Page Not Found: /index
ERROR - 2022-02-28 14:31:18 --> 404 Page Not Found: /index
