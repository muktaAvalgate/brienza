<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-24 06:19:13 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:19:35 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-24 06:19:49 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-24 06:19:53 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:22:05 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:31:58 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:32:28 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:33:51 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:37:34 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:38:11 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:38:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:39:03 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:39:34 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:43:41 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:45:00 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:45:52 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:50:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:50:58 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:51:39 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:53:09 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:54:35 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:56:03 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:57:00 --> 404 Page Not Found: /index
ERROR - 2022-11-24 06:57:48 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:03:56 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:04:25 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:05:08 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 07:05:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 07:05:08 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:11:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-24 07:11:29 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:23:45 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:23:51 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:14 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:17 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:25 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:28 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:34 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:37 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:24:40 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:25:12 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:25:13 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 07:25:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 07:25:13 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:25:15 --> 404 Page Not Found: /index
ERROR - 2022-11-24 07:31:14 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-24 07:31:15 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:40:54 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:41:53 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:42:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:43:01 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 08:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 08:43:01 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:43:57 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 08:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 08:43:58 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:44:20 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:44:23 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:44:49 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:44:58 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 08:44:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 08:44:58 --> 404 Page Not Found: /index
ERROR - 2022-11-24 08:45:21 --> 404 Page Not Found: /index
ERROR - 2022-11-24 09:00:10 --> 404 Page Not Found: /index
ERROR - 2022-11-24 09:00:41 --> 404 Page Not Found: /index
ERROR - 2022-11-24 09:01:18 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 09:01:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-24 09:01:18 --> 404 Page Not Found: /index
ERROR - 2022-11-24 09:01:46 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:06:08 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:28:39 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:29:38 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:30:31 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:30:55 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:33:46 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:33:54 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:34:17 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:34:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:35:27 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:35:34 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:35:36 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:35:38 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:37:21 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:37:27 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:37:29 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:50:48 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:51:00 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:51:02 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:52:20 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:52:25 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:52:30 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:56:25 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:56:28 --> 404 Page Not Found: /index
ERROR - 2022-11-24 10:56:59 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:16:34 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:16:46 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:18:00 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:18:03 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:20:03 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:21:50 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:03 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:09 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:16 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:20 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:24 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:26 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:28 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:31 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:43 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:22:47 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:23:53 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:24:08 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:24:09 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:34:11 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:34:16 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:34:19 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:34:25 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 11:34:28 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:35:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:35:23 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:35:36 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:36:16 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:36:37 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:36:40 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:36:47 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:40:48 --> 404 Page Not Found: /index
ERROR - 2022-11-24 11:40:51 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:02:46 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:02:57 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:04:26 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:04:28 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:04:34 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:04:39 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:04:41 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:04:42 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:08:40 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:08:45 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:08:49 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:08:50 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:08:51 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:08:51 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:08:51 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:08:51 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:09:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:09:24 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:09:31 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:10:41 --> Severity: error --> Exception: Too few arguments to function Presenters::favorite_template_edit(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2786
ERROR - 2022-11-24 12:10:43 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:10:46 --> 404 Page Not Found: ../modules/App/controllers/Presenters/favorite_template_edit80
ERROR - 2022-11-24 12:10:52 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:11:11 --> 404 Page Not Found: ../modules/App/controllers/Presenters/favorite_template_edit80
ERROR - 2022-11-24 12:11:13 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:11:17 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:14:57 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:15:01 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:15:07 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:59:09 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:59:23 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-24 12:59:25 --> 404 Page Not Found: /index
ERROR - 2022-11-24 12:59:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-24 12:59:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-24 12:59:55 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:00:38 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:00:41 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:00:54 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:01:00 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:01:11 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:01:14 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:01:16 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:01:18 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:02:15 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:02:41 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:02:43 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:03:31 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:03:38 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:03:43 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:05:01 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:05:05 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:06:08 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:06:19 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 63
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 69
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-11-24 13:08:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 70
ERROR - 2022-11-24 13:09:22 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:09:27 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:10:28 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:10:31 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:10:46 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-24 13:10:48 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-24 13:10:48 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:11:11 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:17:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-24 13:17:43 --> 404 Page Not Found: /index
ERROR - 2022-11-24 13:38:45 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-24 13:38:50 --> Severity: error --> Exception: Unsupported operand types C:\xampp\htdocs\brienza_backup\system\libraries\Pagination.php 409
