<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-07 07:25:03 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:26:40 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:27:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-07 07:27:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:27:33 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:27:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-07 07:27:38 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-07 07:27:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:27:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:27:57 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-07 07:27:59 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-07 07:27:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:28:03 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:28:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:28:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:28:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:28:44 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 07:31:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:31:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:31:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:25 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:32:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:30 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:32:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:32 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:32:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:33 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:32:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:32:36 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:33:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:33:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:33:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:33:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:33:08 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:35:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:04 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:35:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:07 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 07:35:07 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:35:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:13 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:35:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:15 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:35:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:16 --> 404 Page Not Found: /index
ERROR - 2022-09-07 07:35:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 07:35:49 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 08:39:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:51:24 --> 404 Page Not Found: ../modules/App/controllers/Notifications/add_blink
ERROR - 2022-09-07 08:54:23 --> 404 Page Not Found: ../modules/App/controllers/Notifications/add_blink
ERROR - 2022-09-07 08:55:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:55:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:55:27 --> 404 Page Not Found: ../modules/App/controllers/Notifications/add_blink
ERROR - 2022-09-07 08:55:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:55:40 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 08:55:51 --> 404 Page Not Found: ../modules/App/controllers/Notifications/add_blink
ERROR - 2022-09-07 08:55:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:55:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 08:56:00 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 08:56:56 --> 404 Page Not Found: ../modules/App/controllers/Notifications/add_blink
ERROR - 2022-09-07 08:58:16 --> 404 Page Not Found: ../modules/App/controllers/Notifications/add_blink
ERROR - 2022-09-07 09:01:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:01:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:01:12 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:01:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:01:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:01:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:01:34 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:04:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:00 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:05:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:45 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:05:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-07 09:05:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:06:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:06:20 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:06:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:06:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:06:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:06:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:24 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:07:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:07:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:08:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:08:10 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:08:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:08:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:15:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:15:07 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:16:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 09:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 09:16:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:18:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:18:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:18:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:18:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:18:52 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:30:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:33:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 09:33:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 09:33:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:33:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:43:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:43:37 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:44:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:44:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:44:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:44:15 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:44:23 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:44:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:44:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:44:39 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:48:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 09:48:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 09:48:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:48:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:51:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:51:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:51:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:51:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:51:25 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:52:42 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:53:36 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 176
ERROR - 2022-09-07 09:57:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:57:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:57:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:57:33 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 09:57:52 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:58:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-07 09:58:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:58:33 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:59:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:37 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:59:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:41 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:59:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:43 --> 404 Page Not Found: /index
ERROR - 2022-09-07 09:59:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 09:59:44 --> 404 Page Not Found: /index
ERROR - 2022-09-07 11:38:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 11:38:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 11:38:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 11:38:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 11:38:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 11:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 11:38:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 11:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:01:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:01:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:01:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:01:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:01:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:01:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:01:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:05:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:05:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:05:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:05:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:05:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:05:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:06:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:06:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:06:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:06:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:07:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:07:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:08:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-07 12:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-07 12:08:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:09:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:09:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 92
ERROR - 2022-09-07 12:09:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:09:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:09:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-07 12:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-09-07 12:09:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:10:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 89
ERROR - 2022-09-07 12:10:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 89
ERROR - 2022-09-07 12:10:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:10:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:15:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 89
ERROR - 2022-09-07 12:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 89
ERROR - 2022-09-07 12:15:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:16:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 96
ERROR - 2022-09-07 12:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 96
ERROR - 2022-09-07 12:16:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 12:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-07 13:43:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 13:43:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 13:43:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 13:43:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 13:44:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 13:44:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 13:44:18 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-07 13:45:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 13:45:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 13:45:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 13:45:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:17:20 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza_backup\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza_backup\system\core\Common.php 407
ERROR - 2022-09-07 14:17:20 --> Severity: error --> Exception: Too few arguments to function show_error(), 0 passed in C:\xampp\htdocs\brienza_backup\application\core\Application_Controller.php on line 28 and at least 1 expected C:\xampp\htdocs\brienza_backup\system\core\Common.php 407
ERROR - 2022-09-07 14:21:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:21:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:21:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:21:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:23:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:23:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:23:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:23:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:24:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:24:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 14:24:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:31:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:31:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:31:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 14:31:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 15:11:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 15:11:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 95
ERROR - 2022-09-07 15:11:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 15:11:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 15:11:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 15:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 15:11:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-07 15:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
