<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-09 06:23:36 --> 404 Page Not Found: /index
ERROR - 2022-11-09 06:24:04 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-09 06:24:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-09 06:24:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:24:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:24:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:24:27 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-09 06:24:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:24:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:24:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:24:31 --> 404 Page Not Found: /index
ERROR - 2022-11-09 06:34:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:34:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:34:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 73
ERROR - 2022-11-09 06:34:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 79
ERROR - 2022-11-09 06:34:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:34:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:34:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:35:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:35:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:35:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 73
ERROR - 2022-11-09 06:35:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 79
ERROR - 2022-11-09 06:35:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:35:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:35:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 73
ERROR - 2022-11-09 06:57:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 79
ERROR - 2022-11-09 06:57:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:57:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 73
ERROR - 2022-11-09 06:57:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 79
ERROR - 2022-11-09 06:57:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:57:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:57:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:57:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:57:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:58:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:58:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:58:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 06:58:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 06:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:05:13 --> Severity: error --> Exception: Call to undefined method App_model::topic_name() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2587
ERROR - 2022-11-09 07:05:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:05:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:05:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:05:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-09 07:05:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:05:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:05:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:06:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:06:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:06:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:08:15 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5479
ERROR - 2022-11-09 07:10:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5479
ERROR - 2022-11-09 07:10:16 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5479
ERROR - 2022-11-09 07:10:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5479
ERROR - 2022-11-09 07:10:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-09 07:10:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:10:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:10:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:11:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:11:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:12:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:12:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:15:32 --> Severity: error --> Exception: Too few arguments to function App_model::topic_name(), 0 passed in C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php on line 2587 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5489
ERROR - 2022-11-09 07:16:30 --> Query error: Column 'topic' in field list is ambiguous - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `custom_templates` ON `custom_templates`.`topic` = `title_topics`.`id`
ERROR - 2022-11-09 07:16:32 --> Query error: Column 'topic' in field list is ambiguous - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `custom_templates` ON `custom_templates`.`topic` = `title_topics`.`id`
ERROR - 2022-11-09 07:19:31 --> Query error: Column 'topic' in field list is ambiguous - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `custom_templates` ON `title_topics`.`id` = `custom_templates`.`topic`
ERROR - 2022-11-09 07:19:52 --> Query error: Column 'topic' in field list is ambiguous - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `custom_templates` ON `title_topics`.`id` = `custom_templates`.`topic`
ERROR - 2022-11-09 07:19:52 --> Query error: Column 'topic' in field list is ambiguous - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `custom_templates` ON `title_topics`.`id` = `custom_templates`.`topic`
ERROR - 2022-11-09 07:21:56 --> Query error: Column 'topic' in field list is ambiguous - Invalid query: SELECT `topic` as `tc`
FROM `title_topics`
JOIN `custom_templates` ON `title_topics`.`id` = `custom_templates`.`topic`
ERROR - 2022-11-09 07:40:58 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 83
ERROR - 2022-11-09 07:40:58 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 83
ERROR - 2022-11-09 07:40:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:40:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:41:40 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 83
ERROR - 2022-11-09 07:41:40 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 83
ERROR - 2022-11-09 07:41:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:41:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:41:42 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 83
ERROR - 2022-11-09 07:41:42 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_writting_room.php 83
ERROR - 2022-11-09 07:41:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:41:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:50:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:50:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:50:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:50:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:50:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:50:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:51:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 07:51:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:01:32 --> 404 Page Not Found: /index
ERROR - 2022-11-09 08:13:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:13:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:13:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:13:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:13:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:13:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:13:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:13:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:14:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:14:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:14:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:14:57 --> 404 Page Not Found: /index
ERROR - 2022-11-09 08:14:57 --> 404 Page Not Found: /index
ERROR - 2022-11-09 08:14:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:14:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:14:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:14:59 --> 404 Page Not Found: /index
ERROR - 2022-11-09 08:16:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:16:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:16:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:20 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:19:20 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:19:20 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:19:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:19:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:19:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-09 08:19:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:19:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:19:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:19:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:23:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:23:17 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:23:17 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:23:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:23:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:23:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:23:26 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:23:26 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:23:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:23:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:23:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:23:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:26:17 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:26:17 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:26:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:26:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:26:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:26:21 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:26:21 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:26:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:26:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:26:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:26:28 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:26:28 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:26:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:26:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:26:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:26:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:38:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:38:09 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:38:09 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:38:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:38:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:38:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:38:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 08:38:11 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 32
ERROR - 2022-11-09 08:38:11 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 40
ERROR - 2022-11-09 08:38:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:38:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:38:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:38:20 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-09 08:38:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:38:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:38:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:39:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:39:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:39:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:39:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:39:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:39:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:39:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:42:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 08:42:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 08:42:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:03:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:03:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:03:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:03:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:03:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:03:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:03:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:03:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:05:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:05:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:42 --> 404 Page Not Found: /index
ERROR - 2022-11-09 09:05:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:05:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:44 --> 404 Page Not Found: /index
ERROR - 2022-11-09 09:05:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:05:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:05:46 --> 404 Page Not Found: /index
ERROR - 2022-11-09 09:08:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:08:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:08:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:08:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:08:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:08:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:08:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:08:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:08:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:09:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:09:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:10:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:10:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:10:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:10:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:10:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:11:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:11:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:11:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:11:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:11:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:12:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:12:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:12:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:13:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:13:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:13:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:13:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:13:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:15:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:15:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:15:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:15:13 --> 404 Page Not Found: /index
ERROR - 2022-11-09 09:15:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:15:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:15:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:15:16 --> 404 Page Not Found: /index
ERROR - 2022-11-09 09:15:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:15:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:15:32 --> 404 Page Not Found: /index
ERROR - 2022-11-09 09:17:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:17:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:17:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:18:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:18:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:18:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:18:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:18:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:21:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:21:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:21:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:21:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:21:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:21:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:21:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:21:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:22:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:22:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:22:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:22:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:22:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:22:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:22:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 09:22:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 09:22:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:09:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 10:09:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:09:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:10:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 10:10:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:20:59 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 10:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 10:20:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 10:20:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:22:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 10:22:17 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 10:22:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 10:22:17 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 47
ERROR - 2022-11-09 10:22:17 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 55
ERROR - 2022-11-09 10:22:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 10:22:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:22:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:23:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 10:23:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:23:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:23:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 10:23:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:23:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:27:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 10:27:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 10:27:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:23:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:23:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:23:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:24:28 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:24:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-09 11:24:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:24:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:24:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:24:44 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:25:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 20
ERROR - 2022-11-09 11:25:08 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:25:08 --> Severity: Notice --> Trying to get property 'tmp_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 47
ERROR - 2022-11-09 11:25:08 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 55
ERROR - 2022-11-09 11:25:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:25:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:25:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:25:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:25:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:25:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:25:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:38:58 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:38:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:38:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:38:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:38:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:39:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:39:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:39:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:39:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:30 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:40:30 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:40:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:31 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:40:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:33 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:40:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:51 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:40:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:40:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:40:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:41:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:29 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:41:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:41:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:41:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:38 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:41:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:41:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:41:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:41:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:53 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:41:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:41:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:41:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:41:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:42:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:08 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:42:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:40 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:42:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:52 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:42:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:55 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:42:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:42:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:05 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:43:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:43:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:43:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:43:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:11 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:43:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:43:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:43:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:43:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:43:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:44:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:44:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:44:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:44:20 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:44:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:44:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:44:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:44:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:44:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:44:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:44:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:45:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:08 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:45:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:45:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:18 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:45:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:45:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:45:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:45:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:45:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:46:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:46:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:46:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:46:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:46:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:46:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:46:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:50:38 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 11:50:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:50:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:50:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:50:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:50:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:50:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-09 11:50:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:50:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:51:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:51:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:51:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:51:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-09 11:51:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:51:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:51:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:54:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:54:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:54:46 --> 404 Page Not Found: /index
ERROR - 2022-11-09 11:55:03 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-09 11:55:03 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 11:55:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:55:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 11:57:35 --> 404 Page Not Found: ../modules/App/controllers/Presenters/%3Cdiv%20style=
ERROR - 2022-11-09 11:57:37 --> 404 Page Not Found: ../modules/App/controllers/Presenters/%3Cdiv%20style=
ERROR - 2022-11-09 12:00:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-09 12:00:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:00:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:00:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:00:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:00:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:00:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:01:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-09 12:01:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:01:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:01:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:01:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:01:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:01:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:10:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:10:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:10:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:10:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:10:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:29:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:29:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:29:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:29:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:29:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:47:36 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 12:47:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 12:47:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:47:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:47:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:47:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 12:47:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 12:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:01:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:03:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:03:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:04:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:04:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:04:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:04:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:04:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:04:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:04:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:04:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:05:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:03 --> 404 Page Not Found: /index
ERROR - 2022-11-09 13:05:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:05:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:26 --> 404 Page Not Found: /index
ERROR - 2022-11-09 13:05:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:05:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:30 --> 404 Page Not Found: /index
ERROR - 2022-11-09 13:05:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:05:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:05:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:05:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:05:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:06:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:06:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:12 --> Severity: Notice --> Undefined variable: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 13:06:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 34
ERROR - 2022-11-09 13:06:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:06:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:06:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:06:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:06:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-09 13:06:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-09 13:06:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
