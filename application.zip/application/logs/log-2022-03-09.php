<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-09 09:42:49 --> 404 Page Not Found: /index
ERROR - 2022-03-09 09:44:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-09 09:44:05 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-09 09:44:06 --> 404 Page Not Found: /index
ERROR - 2022-03-09 09:44:09 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:30:57 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:30:59 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:31:02 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:31:05 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:34:16 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:48:10 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:48:22 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:52:41 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:52:44 --> 404 Page Not Found: /index
ERROR - 2022-03-09 11:56:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-09 11:56:06 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-09 11:59:48 --> 404 Page Not Found: /index
ERROR - 2022-03-09 12:00:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-09 12:00:11 --> 404 Page Not Found: /index
ERROR - 2022-03-09 12:53:49 --> 404 Page Not Found: /index
ERROR - 2022-03-09 12:54:06 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-09 12:54:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-09 12:54:08 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:29:54 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:29:57 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:35:31 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:36:42 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:36:48 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:37:31 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:37:46 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:37:59 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:44:03 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:44:06 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:44:33 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:44:50 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:52:39 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:52:42 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:53:59 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:54:54 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:59:09 --> 404 Page Not Found: /index
ERROR - 2022-03-09 13:59:13 --> 404 Page Not Found: /index
ERROR - 2022-03-09 14:06:14 --> 404 Page Not Found: /index
ERROR - 2022-03-09 14:06:23 --> 404 Page Not Found: /index
