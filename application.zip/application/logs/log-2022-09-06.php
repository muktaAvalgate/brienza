<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-06 07:15:44 --> 404 Page Not Found: /index
ERROR - 2022-09-06 07:16:22 --> 404 Page Not Found: /index
ERROR - 2022-09-06 07:17:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-06 07:17:26 --> 404 Page Not Found: /index
ERROR - 2022-09-06 07:17:29 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-06 07:17:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-06 07:17:45 --> 404 Page Not Found: /index
ERROR - 2022-09-06 07:17:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-06 07:17:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-06 07:17:55 --> 404 Page Not Found: /index
ERROR - 2022-09-06 07:25:34 --> 404 Page Not Found: /index
ERROR - 2022-09-06 11:22:30 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-06 11:50:00 --> 404 Page Not Found: /index
ERROR - 2022-09-06 11:50:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-06 11:50:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-06 11:50:12 --> 404 Page Not Found: /index
ERROR - 2022-09-06 11:50:16 --> 404 Page Not Found: /index
ERROR - 2022-09-06 14:56:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-06 14:56:45 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-06 14:56:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 14:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 14:56:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 14:56:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 14:57:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 14:57:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 14:57:23 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-06 15:03:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 15:03:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 15:03:49 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-06 15:04:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 15:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 176
ERROR - 2022-09-06 15:05:00 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
