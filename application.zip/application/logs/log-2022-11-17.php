<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-17 06:21:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-17 06:21:47 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-17 06:25:16 --> 404 Page Not Found: /index
ERROR - 2022-11-17 06:25:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-17 06:25:41 --> 404 Page Not Found: /index
ERROR - 2022-11-17 07:03:30 --> Severity: Notice --> Undefined variable: school_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 276
ERROR - 2022-11-17 07:03:30 --> Severity: Notice --> Undefined variable: title_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-17 07:03:36 --> Severity: Notice --> Undefined variable: school_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 276
ERROR - 2022-11-17 07:03:36 --> Severity: Notice --> Undefined variable: title_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-17 07:07:08 --> Severity: Notice --> Undefined variable: school_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 276
ERROR - 2022-11-17 07:07:08 --> Severity: Notice --> Undefined variable: title_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-17 07:08:36 --> Severity: Notice --> Undefined variable: school_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 276
ERROR - 2022-11-17 07:08:36 --> Severity: Notice --> Undefined variable: title_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-17 07:08:40 --> Severity: Notice --> Undefined variable: school_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 276
ERROR - 2022-11-17 07:08:40 --> Severity: Notice --> Undefined variable: title_id C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 277
ERROR - 2022-11-17 09:56:09 --> 404 Page Not Found: /index
ERROR - 2022-11-17 09:56:24 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-17 09:56:27 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:00:07 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:00:07 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:00:08 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:00:10 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:00:14 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:19:41 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:19:44 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:20:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-17 10:20:17 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:20:35 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:20:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-17 10:20:49 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-17 10:20:49 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:20:52 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:20:55 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:20:58 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:21:01 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:21:05 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:21:07 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:21:17 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:21:52 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:23:28 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:24:38 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:30:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-17 10:33:08 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:48:00 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:52:31 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:54:23 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:54:34 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:54:38 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:55:00 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:55:07 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:55:10 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:56:36 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:57:03 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:57:06 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:57:13 --> 404 Page Not Found: /index
ERROR - 2022-11-17 10:57:46 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:10:46 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:12:19 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:12:27 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:12:37 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:12:46 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:13:23 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:14:01 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:14:32 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:14:35 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:15:09 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:15:19 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:16:00 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:16:14 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:16:15 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:16:23 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:19:59 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:20:58 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:29:30 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:29:32 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:30:49 --> 404 Page Not Found: /index
ERROR - 2022-11-17 11:54:41 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:02:05 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:05:04 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:05:26 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:05:37 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:06:11 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:09:43 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:10:05 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:10:09 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:13:10 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:13:32 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:13:37 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:14:50 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:21:11 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:22:18 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:22:27 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:22:37 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:22:46 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:22:56 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:23:36 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:25:07 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:25:25 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:26:42 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:26:50 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:27:02 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:27:15 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:27:32 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:27:42 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:27:50 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:29:12 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:29:36 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:31:11 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:33:51 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:34:30 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:41:16 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:42:13 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:42:35 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:48:39 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:48:55 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:50:59 --> 404 Page Not Found: /index
ERROR - 2022-11-17 12:52:00 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:21:24 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:22:21 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:22:53 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:23:01 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:23:09 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:23:16 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:32:43 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:34:11 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:34:26 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:35:20 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:37:17 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:38:11 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:39:34 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:39:42 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:39:50 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:39:57 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:40:05 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:40:16 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:40:26 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:44:12 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:48:38 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:51:17 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:51:22 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:51:29 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:51:35 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:53:40 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:53:45 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:53:49 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:57:11 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:57:26 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:57:59 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:58:05 --> 404 Page Not Found: /index
ERROR - 2022-11-17 13:58:08 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:08:37 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:08:53 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:08:57 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:09:00 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:09:01 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:09:03 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:09:13 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:09:17 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:09:19 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:09:21 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:10:54 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:25:32 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:25:41 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:25:48 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:25:50 --> 404 Page Not Found: /index
ERROR - 2022-11-17 14:25:52 --> 404 Page Not Found: /index
