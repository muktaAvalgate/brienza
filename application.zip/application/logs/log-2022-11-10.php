<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-10 06:09:55 --> 404 Page Not Found: /index
ERROR - 2022-11-10 06:10:49 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-10 06:11:04 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-10 06:11:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:11:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:11:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:11:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-10 06:11:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:11:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:11:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:11:19 --> 404 Page Not Found: /index
ERROR - 2022-11-10 06:17:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:17:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:17:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:17:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:17:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:17:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:18:56 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 62
ERROR - 2022-11-10 06:18:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:18:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:18:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:18:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:18:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:19:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:19:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:19:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:19:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:56:55 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-10 06:56:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:56:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:56:57 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-10 06:56:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:56:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:56:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:57:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:57:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:57:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:58:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:58:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:59:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 06:59:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 06:59:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:00:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:00:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:07 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:07 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:09 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:14 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:20 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:22 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:24 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:26 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:06:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:06:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:06:29 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:08:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:08:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:08:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:11:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:11:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:11:54 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:04 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:07 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:14 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:24 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:29 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:32 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:37 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:41 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:12:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:12:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:12:55 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:38:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:38:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:38:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:38:01 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:40:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:40:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:40:16 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:41:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:41:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:41:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:41:49 --> 404 Page Not Found: /index
ERROR - 2022-11-10 07:41:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 07:41:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:41:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 07:41:50 --> 404 Page Not Found: /index
ERROR - 2022-11-10 09:05:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 09:05:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:05:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:05:08 --> 404 Page Not Found: /index
ERROR - 2022-11-10 09:09:14 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-10 09:09:17 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-10 09:09:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 09:09:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:09:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:09:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 09:09:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:09:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-11-10 09:09:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 09:23:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 09:23:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:23:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 09:23:05 --> 404 Page Not Found: /index
ERROR - 2022-11-10 09:23:06 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:37:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:37:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:37:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:37:36 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:37:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:37:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:37:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:37:40 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:39:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:39:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:10 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:39:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:39:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:13 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:39:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:39:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:15 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:39:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:39:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:20 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:39:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:39:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:22 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:39:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:39:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:39:30 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:40:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:40:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:40:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:40:16 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:40:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:40:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:40:18 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:41:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:41:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:41:25 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:42:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:42:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:00 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:42:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:42:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:13 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:42:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:42:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:39 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:42:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:42:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:42:44 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:42:55 --> 404 Page Not Found: /index
ERROR - 2022-11-10 10:58:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:58:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:58:30 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 10:58:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-11-10 10:58:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:58:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:58:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:58:57 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 10:59:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-11-10 10:59:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:59:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 10:59:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:59:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 10:59:05 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:09:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-11-10 11:09:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:09:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-11-10 11:09:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:11:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:11:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:11:26 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:11:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:11:49 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:12:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:12:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:12:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:12:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-11-10 11:12:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:12:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:36 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:12:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:12:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:12:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-11-10 11:12:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:35:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:39:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:40:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:43:36 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-11-10 11:43:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-11-10 11:43:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:43:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:43:37 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:46:42 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-11-10 11:46:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-11-10 11:46:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:46:42 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:46:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:46:58 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 422
ERROR - 2022-11-10 11:46:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 423
ERROR - 2022-11-10 11:46:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:46:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:46:59 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:48:45 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-10 11:48:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-10 11:48:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 11:48:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:48:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 11:48:46 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-10 11:49:03 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:05:38 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:05:51 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-10 13:05:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:05:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:05:53 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:05:57 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:05:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:05:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:05:57 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:05:58 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:06:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:06:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:06:04 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:06:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:06:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:06:06 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:06:07 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:10:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:10:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:10:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:10:54 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:11:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:11:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:16 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:11:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:11:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:24 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:11:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:11:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:27 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:11:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:11:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:11:51 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:12:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:12:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:12:02 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:12:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:12:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:12:05 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:12:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:12:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:12:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:12:41 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:13:36 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:13:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:13:37 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:14:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:14:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:14:09 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:14:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:14:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:14:10 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:15:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:15:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:15:59 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:16:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:16:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:11 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:16:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:16:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:22 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:16:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:16:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:29 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:16:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:16:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:46 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:16:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:16:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:55 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:16:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:16:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:16:58 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:17:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:17:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:17:02 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:17:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:17:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:17:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:17:30 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:17:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:17:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:17:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:17:33 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:20:31 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:20:31 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:28:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:28:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:28:24 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:28:25 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:29:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:29:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:29:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:29:11 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:29:11 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:32:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:32:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:32:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:32:28 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:33:21 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:33:21 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:33:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:33:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:33:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:33:55 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:33:56 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:35:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:35:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:35:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:35:19 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:35:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:35:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:35:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:35:23 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:39:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:39:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:39:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:39:59 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:40:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:40:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:09 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:40:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:40:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:14 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:40:21 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:40:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:21 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:40:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:40:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:23 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:40:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:40:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:31 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:40:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:40:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:41 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:40:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 13:40:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-10 13:40:46 --> 404 Page Not Found: /index
ERROR - 2022-11-10 13:46:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-10 14:11:00 --> 404 Page Not Found: /index
