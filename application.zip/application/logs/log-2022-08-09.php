<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-09 07:29:38 --> 404 Page Not Found: /index
ERROR - 2022-08-09 07:30:44 --> 404 Page Not Found: /index
ERROR - 2022-08-09 07:31:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-09 07:31:23 --> 404 Page Not Found: /index
ERROR - 2022-08-09 07:31:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-09 07:31:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-09 07:31:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-09 07:31:48 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-09 07:31:49 --> 404 Page Not Found: /index
ERROR - 2022-08-09 07:32:28 --> 404 Page Not Found: /index
ERROR - 2022-08-09 07:32:33 --> 404 Page Not Found: /index
ERROR - 2022-08-09 07:32:37 --> 404 Page Not Found: /index
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 67
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: principal_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'meta_value' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 76
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 77
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-08-09 08:05:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 78
ERROR - 2022-08-09 08:34:39 --> 404 Page Not Found: /index
ERROR - 2022-08-09 08:39:28 --> 404 Page Not Found: /index
ERROR - 2022-08-09 08:41:47 --> 404 Page Not Found: /index
ERROR - 2022-08-09 08:41:52 --> 404 Page Not Found: /index
ERROR - 2022-08-09 08:42:10 --> 404 Page Not Found: /index
ERROR - 2022-08-09 08:42:24 --> 404 Page Not Found: /index
ERROR - 2022-08-09 09:12:06 --> 404 Page Not Found: /index
ERROR - 2022-08-09 09:12:08 --> 404 Page Not Found: /index
ERROR - 2022-08-09 09:12:19 --> 404 Page Not Found: /index
ERROR - 2022-08-09 09:13:22 --> 404 Page Not Found: /index
ERROR - 2022-08-09 09:13:34 --> 404 Page Not Found: /index
ERROR - 2022-08-09 09:13:44 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:09:04 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-09 12:09:07 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-09 12:19:18 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:19:34 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:19:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-09 12:19:56 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:20:12 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:30:51 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:30:59 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:31:33 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:32:51 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:35:03 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:35:52 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:36:11 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:36:25 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:37:04 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:37:44 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:40:15 --> 404 Page Not Found: /index
ERROR - 2022-08-09 12:49:22 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:20:11 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:22:18 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:22:30 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:22:51 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-09 13:22:51 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-09 13:22:52 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:22:56 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:23:00 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:23:12 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:23:22 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:23:26 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:24:26 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:24:30 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:24:33 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:24:33 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:24:38 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:24:43 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:25:00 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:28:09 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:28:34 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:28:48 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:29:10 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:29:16 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:29:52 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:29:56 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:29:58 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:30:01 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:30:16 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:38:13 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:38:34 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:38:42 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:38:50 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:39:30 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:39:40 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:39:42 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:39:46 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:40:06 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:42:30 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:44:09 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:44:17 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:44:27 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:45:13 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:45:22 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:45:24 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:45:25 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:45:37 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:47:01 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:51:46 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:51:50 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:52:01 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:52:24 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:52:28 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:55:05 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:55:14 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:56:48 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:58:50 --> 404 Page Not Found: /index
ERROR - 2022-08-09 13:59:15 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:01:24 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:01:50 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:08 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:28 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:32 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:34 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:36 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:43 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:49 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:02:55 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:46:55 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:46:58 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:47:00 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:47:01 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:47:04 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:47:06 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:48:33 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:48:39 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:48:42 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:48:51 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:49:00 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:49:23 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:49:26 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:49:31 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:50:03 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:50:05 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:50:43 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:55:10 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:55:13 --> 404 Page Not Found: /index
ERROR - 2022-08-09 14:55:23 --> 404 Page Not Found: /index
ERROR - 2022-08-09 15:15:25 --> 404 Page Not Found: /index
ERROR - 2022-08-09 15:15:32 --> 404 Page Not Found: /index
ERROR - 2022-08-09 15:15:39 --> 404 Page Not Found: /index
ERROR - 2022-08-09 15:15:42 --> 404 Page Not Found: /index
ERROR - 2022-08-09 15:17:40 --> 404 Page Not Found: /index
