<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-19 07:32:47 --> 404 Page Not Found: /index
ERROR - 2022-08-19 07:33:04 --> 404 Page Not Found: /index
ERROR - 2022-08-19 07:40:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-19 07:40:54 --> 404 Page Not Found: /index
ERROR - 2022-08-19 07:40:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-19 07:41:00 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-19 07:41:12 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-19 07:41:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-19 07:41:13 --> 404 Page Not Found: /index
ERROR - 2022-08-19 07:41:31 --> 404 Page Not Found: /index
ERROR - 2022-08-19 07:43:19 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:26:19 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:26:28 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:32:52 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:33:34 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:35:55 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:36:50 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:36:54 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:37:01 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:37:17 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:37:20 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:37:26 --> Severity: error --> Exception: Call to undefined method App_model::get_order_details_by_orderId() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 479
ERROR - 2022-08-19 08:37:31 --> Severity: error --> Exception: Call to undefined method App_model::get_order_details_by_orderId() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 479
ERROR - 2022-08-19 08:38:54 --> Severity: error --> Exception: Call to undefined method App_model::get_order_details_by_orderId() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 479
ERROR - 2022-08-19 08:38:59 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:39:02 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:39:05 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:39:06 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:40:02 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:40:10 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:40:14 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:40:17 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:40:52 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:40:55 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:41:13 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:41:17 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:41:39 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:41:43 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:41:46 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:41:52 --> Severity: error --> Exception: Call to undefined method App_model::get_order_details_by_orderId() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 479
ERROR - 2022-08-19 08:43:06 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:43:08 --> Severity: error --> Exception: Call to undefined method App_model::get_presenter_name() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Orders.php 484
ERROR - 2022-08-19 08:44:08 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:44:11 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:45:36 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:45:40 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:45:57 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:46:09 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-19 08:48:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-19 08:48:21 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:48:26 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:48:43 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:48:45 --> 404 Page Not Found: /index
ERROR - 2022-08-19 08:48:51 --> 404 Page Not Found: /index
ERROR - 2022-08-19 09:07:43 --> 404 Page Not Found: /index
ERROR - 2022-08-19 09:07:47 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:03:35 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:04:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-19 11:04:03 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-19 11:04:04 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:07:39 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:07:53 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:08:06 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:12:55 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:18:09 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:18:26 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:19:24 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:19:31 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:19:40 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:33:05 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:33:10 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:33:19 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:33:40 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:33:45 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:33:57 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:33:59 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:05 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:09 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:10 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\billing.php 1091
ERROR - 2022-08-19 11:34:11 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:15 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\billing.php 1091
ERROR - 2022-08-19 11:34:15 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:17 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:41 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:43 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:47 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:34:51 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:37:25 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:37:44 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:38:01 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:39:43 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:40:31 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:55:28 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:55:36 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:55:39 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:55:41 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:55:46 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:56:09 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:56:18 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:56:40 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:56:46 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:56:53 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:57:10 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:57:13 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:57:40 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:57:55 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:58:05 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:59:04 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:59:30 --> 404 Page Not Found: /index
ERROR - 2022-08-19 11:59:50 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:01:39 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:01:43 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:11:42 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:11:49 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:11:51 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:11:53 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:11:54 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:11:57 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:15:54 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:15:56 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:16:05 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:16:14 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:19:17 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:30:47 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:30:51 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:30:54 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:32:03 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:32:12 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:32:36 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:32:39 --> 404 Page Not Found: /index
ERROR - 2022-08-19 12:32:43 --> 404 Page Not Found: /index
