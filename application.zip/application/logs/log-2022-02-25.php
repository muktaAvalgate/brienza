<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-25 11:33:13 --> 404 Page Not Found: /index
ERROR - 2022-02-25 11:35:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-25 11:35:58 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-25 11:35:59 --> 404 Page Not Found: /index
ERROR - 2022-02-25 11:36:09 --> 404 Page Not Found: /index
ERROR - 2022-02-25 11:36:17 --> 404 Page Not Found: /index
ERROR - 2022-02-25 11:54:03 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:01:57 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:07:24 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:10:15 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:24:02 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:24:56 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:25:33 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:25:47 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:55:11 --> 404 Page Not Found: /index
ERROR - 2022-02-25 12:59:57 --> 404 Page Not Found: /index
ERROR - 2022-02-25 13:19:21 --> 404 Page Not Found: /index
ERROR - 2022-02-25 13:20:29 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-25 13:20:31 --> 404 Page Not Found: /index
ERROR - 2022-02-25 13:22:25 --> 404 Page Not Found: /index
ERROR - 2022-02-25 14:00:07 --> 404 Page Not Found: /index
