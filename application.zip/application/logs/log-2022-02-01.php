<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-01 10:41:57 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:42:28 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-01 10:42:31 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:42:43 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:42:59 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:43:14 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:43:33 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-01 10:43:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-01 10:43:34 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:43:37 --> 404 Page Not Found: /index
ERROR - 2022-02-01 10:44:14 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:27:47 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:28:10 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:28:48 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:33:26 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:33:32 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:46:29 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:46:42 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:47:02 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:47:23 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:47:32 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:49:08 --> 404 Page Not Found: /index
ERROR - 2022-02-01 11:49:15 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:13:48 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:14:43 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:17:21 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:23:04 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:23:06 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:23:35 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:24:08 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:28:46 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:29:00 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:35:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-01 12:35:30 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-01 12:36:20 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:36:23 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:36:41 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:37:16 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:37:18 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:37:22 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:37:24 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:38:12 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:41:16 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:41:35 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:41:42 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:41:56 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:46:09 --> 404 Page Not Found: /index
ERROR - 2022-02-01 12:46:34 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:11:52 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:15:32 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:15:56 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:15:57 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:16:00 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:16:30 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:28:43 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:28:47 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:29:16 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:29:21 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:29:25 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:29:47 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:29:49 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:30:02 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:30:46 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:30:57 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:31:01 --> 404 Page Not Found: /index
ERROR - 2022-02-01 13:31:07 --> 404 Page Not Found: /index
ERROR - 2022-02-01 14:20:15 --> 404 Page Not Found: /index
ERROR - 2022-02-01 14:20:25 --> 404 Page Not Found: /index
ERROR - 2022-02-01 14:20:28 --> 404 Page Not Found: /index
ERROR - 2022-02-01 14:20:30 --> 404 Page Not Found: /index
ERROR - 2022-02-01 14:20:34 --> 404 Page Not Found: /index
ERROR - 2022-02-01 14:20:39 --> 404 Page Not Found: /index
ERROR - 2022-02-01 14:20:42 --> 404 Page Not Found: /index
