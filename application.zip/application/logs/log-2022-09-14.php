<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-14 07:31:14 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:32:28 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:32:51 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-14 07:32:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:32:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:32:58 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:33:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-14 07:33:19 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-14 07:33:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:33:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-14 07:33:36 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-14 07:33:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:33:37 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:33:46 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 07:33:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 07:33:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:33:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:33:49 --> 404 Page Not Found: ../modules/App/controllers/Presenters/export_teacher_report
ERROR - 2022-09-14 07:36:45 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 07:36:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 07:36:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:36:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:39:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:39:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:39:24 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 07:39:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 915
ERROR - 2022-09-14 07:39:26 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 916
ERROR - 2022-09-14 07:39:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 916
ERROR - 2022-09-14 07:39:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:39:28 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:43:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:43:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:43:48 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:43:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:43:54 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:45:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:45:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:45:45 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:45:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:45:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:45:48 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:47:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:47:46 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:47:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:47:48 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:49:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:49:18 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 07:49:21 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 07:49:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:49:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 07:49:23 --> 404 Page Not Found: /index
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:49:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 07:49:25 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 07:54:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:00:39 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:00:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:03:22 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:04:24 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4817
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:05:43 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:08:43 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:08:43 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:18:00 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:18:00 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:18:32 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:22:40 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:22:40 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:25:04 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:25:04 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:33:56 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:33:56 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:35:53 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:35:53 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:36:08 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:36:08 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:36:08 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 913
ERROR - 2022-09-14 08:36:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:36:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:36:28 --> 404 Page Not Found: /index
ERROR - 2022-09-14 08:36:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:36:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:36:30 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 913
ERROR - 2022-09-14 08:37:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:37:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:37:34 --> 404 Page Not Found: /index
ERROR - 2022-09-14 08:37:36 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:37:36 --> Severity: Notice --> Trying to get property 'name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4816
ERROR - 2022-09-14 08:44:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:44:31 --> 404 Page Not Found: /index
ERROR - 2022-09-14 08:44:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:44:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:44:33 --> 404 Page Not Found: /index
ERROR - 2022-09-14 08:44:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:44:43 --> 404 Page Not Found: /index
ERROR - 2022-09-14 08:44:45 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 913
ERROR - 2022-09-14 08:46:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:46:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:46:52 --> 404 Page Not Found: /index
ERROR - 2022-09-14 08:46:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:46:54 --> 404 Page Not Found: /index
ERROR - 2022-09-14 08:46:56 --> Severity: Notice --> Undefined variable: feilename C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 913
ERROR - 2022-09-14 08:50:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 08:50:27 --> 404 Page Not Found: /index
ERROR - 2022-09-14 11:16:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-14 11:16:56 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-14 11:16:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:16:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:18:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:18:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:18:08 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 11:18:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 11:18:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:18:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:18:11 --> 404 Page Not Found: ../modules/App/controllers/Presenters/export_teacher_report
ERROR - 2022-09-14 11:18:12 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 11:18:12 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 11:18:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:18:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:25:34 --> 404 Page Not Found: /index
ERROR - 2022-09-14 11:25:54 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-14 11:25:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:25:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:25:56 --> 404 Page Not Found: /index
ERROR - 2022-09-14 11:25:59 --> 404 Page Not Found: /index
ERROR - 2022-09-14 11:26:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-14 11:26:21 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-14 11:26:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 11:26:21 --> 404 Page Not Found: /index
ERROR - 2022-09-14 12:34:51 --> Severity: error --> Exception: syntax error, unexpected 'export_teacher_report' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4865
ERROR - 2022-09-14 12:35:28 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:35:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:35:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:35:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:35:31 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2360
ERROR - 2022-09-14 12:35:31 --> Severity: Notice --> Undefined property: CI::$export_teacher_report C:\xampp\htdocs\brienza_backup\system\core\Model.php 77
ERROR - 2022-09-14 12:35:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-14 12:35:31 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2391
ERROR - 2022-09-14 12:36:36 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:36:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:36:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:36:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:36:38 --> Severity: Notice --> Undefined offset: 7 C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2360
ERROR - 2022-09-14 12:36:38 --> Severity: Notice --> Undefined property: CI::$export_teacher_report C:\xampp\htdocs\brienza_backup\system\core\Model.php 77
ERROR - 2022-09-14 12:36:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2381
ERROR - 2022-09-14 12:36:38 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2391
ERROR - 2022-09-14 12:39:56 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:39:56 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:39:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:39:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:39:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2360
ERROR - 2022-09-14 12:43:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:43:28 --> 404 Page Not Found: /index
ERROR - 2022-09-14 12:43:40 --> 404 Page Not Found: /index
ERROR - 2022-09-14 12:43:40 --> 404 Page Not Found: /index
ERROR - 2022-09-14 12:48:57 --> Severity: Notice --> Undefined property: CI::$export_teacher_report C:\xampp\htdocs\brienza_backup\system\core\Model.php 77
ERROR - 2022-09-14 12:48:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2382
ERROR - 2022-09-14 12:48:57 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2392
ERROR - 2022-09-14 12:49:02 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:49:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:49:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:49:04 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:49:04 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:49:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:49:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:49:07 --> Severity: Notice --> Undefined property: CI::$export_teacher_report C:\xampp\htdocs\brienza_backup\system\core\Model.php 77
ERROR - 2022-09-14 12:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2382
ERROR - 2022-09-14 12:49:07 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2392
ERROR - 2022-09-14 12:57:39 --> 404 Page Not Found: ../modules/App/controllers/Presenters/export_teacher_report
ERROR - 2022-09-14 12:57:41 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:57:41 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 12:57:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:57:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 12:57:43 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4868
ERROR - 2022-09-14 12:57:43 --> Severity: Notice --> Undefined variable: order_ids C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4881
ERROR - 2022-09-14 12:57:43 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4882
ERROR - 2022-09-14 12:57:43 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-14 13:03:41 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4868
ERROR - 2022-09-14 13:03:42 --> Severity: Notice --> Undefined variable: order_ids C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4881
ERROR - 2022-09-14 13:03:42 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4882
ERROR - 2022-09-14 13:03:42 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2389
ERROR - 2022-09-14 13:19:06 --> Severity: error --> Exception: syntax error, unexpected 'die' (T_EXIT), expecting ';' or ',' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2360
ERROR - 2022-09-14 13:19:25 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:19:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:19:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:19:47 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:19:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:19:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:19:58 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:19:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:19:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:19:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:28:46 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:28:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 13:28:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:28:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 13:28:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4882
ERROR - 2022-09-14 13:28:48 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-14 14:16:57 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:16:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:16:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:19:05 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:19:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:19:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:19:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:19:08 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4883
ERROR - 2022-09-14 14:19:08 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-14 14:25:49 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:25:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:25:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:25:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4884
ERROR - 2022-09-14 14:28:55 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *, `Order`.`session_id` AS `session_id`
FROM `order_schedules`
JOIN `orders` AS `Order` ON `Order`.`id` = `order_schedules`.`order_id`
WHERE `order_schedules`.`order_id` IN(Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
AND `Order`.`school_id` IS NULL
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-14 14:28:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\system\core\Common.php 573
ERROR - 2022-09-14 14:28:56 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:28:56 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:28:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:28:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:28:57 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:28:57 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:28:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\system\database\DB_query_builder.php 822
ERROR - 2022-09-14 14:28:59 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4884
ERROR - 2022-09-14 14:28:59 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *, `Order`.`session_id` AS `session_id`
FROM `order_schedules`
JOIN `orders` AS `Order` ON `Order`.`id` = `order_schedules`.`order_id`
WHERE `order_schedules`.`order_id` IN(Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
AND `Order`.`school_id` IS NULL
ORDER BY `Order`.`session_id`, `order_schedules`.`teacher`, `order_schedules`.`grade_id`, `order_schedules`.`created_by`, `order_schedules`.`topic_id`
ERROR - 2022-09-14 14:28:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\brienza_backup\system\core\Exceptions.php:272) C:\xampp\htdocs\brienza_backup\system\core\Common.php 573
ERROR - 2022-09-14 14:29:02 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:29:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:29:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:29:36 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:29:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:29:36 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:29:38 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4884
ERROR - 2022-09-14 14:29:38 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-14 14:32:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:32:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:32:56 --> 404 Page Not Found: /index
ERROR - 2022-09-14 14:36:05 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:06 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:07 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:08 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:08 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:08 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:09 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:09 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:09 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:15 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:36:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:36:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:36:39 --> 404 Page Not Found: /index
ERROR - 2022-09-14 14:37:08 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:37:19 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:38:08 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:38:13 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:38:15 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4757
ERROR - 2022-09-14 14:38:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:38:49 --> 404 Page Not Found: /index
ERROR - 2022-09-14 14:40:35 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:40:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:40:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:40:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:40:37 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4885
ERROR - 2022-09-14 14:40:37 --> Severity: Notice --> Undefined variable: feilenam C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2390
ERROR - 2022-09-14 14:44:15 --> Severity: Notice --> Undefined variable: school C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:44:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\documents_list.php 32
ERROR - 2022-09-14 14:44:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 14:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-14 15:15:46 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-14 15:15:47 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-14 15:16:06 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-14 15:16:07 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-14 15:16:08 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-14 15:16:08 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-14 15:16:08 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
ERROR - 2022-09-14 15:16:08 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 4948
