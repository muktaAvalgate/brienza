<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-13 05:00:43 --> 404 Page Not Found: /index
ERROR - 2021-12-13 05:00:46 --> 404 Page Not Found: /index
ERROR - 2021-12-13 05:01:06 --> 404 Page Not Found: /index
ERROR - 2021-12-13 05:01:36 --> 404 Page Not Found: /index
ERROR - 2021-12-13 05:01:42 --> 404 Page Not Found: /index
ERROR - 2021-12-13 05:01:56 --> 404 Page Not Found: /index
ERROR - 2021-12-13 05:02:28 --> 404 Page Not Found: /index
ERROR - 2021-12-13 05:33:36 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:04:55 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:05:00 --> 404 Page Not Found: /index
ERROR - 2021-12-13 02:05:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-13 07:05:13 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:05:16 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:19:53 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:19:54 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:25:35 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:25:45 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:17:14 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:17:19 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:17:29 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-13 12:17:30 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:18:27 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:18:46 --> 404 Page Not Found: /index
ERROR - 2021-12-13 07:43:31 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-13 12:43:33 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:43:35 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:51:56 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:52:03 --> 404 Page Not Found: /index
ERROR - 2021-12-13 12:52:05 --> 404 Page Not Found: /index
ERROR - 2021-12-13 18:47:19 --> 404 Page Not Found: /index
ERROR - 2021-12-13 13:47:28 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-13 18:47:29 --> 404 Page Not Found: /index
ERROR - 2021-12-13 18:47:45 --> 404 Page Not Found: /index
ERROR - 2021-12-13 13:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 2872
ERROR - 2021-12-13 13:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 3302
ERROR - 2021-12-13 18:49:04 --> 404 Page Not Found: /index
