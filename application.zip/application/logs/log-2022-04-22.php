<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-22 08:54:19 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:56:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-22 08:56:36 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:56:44 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:56:51 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:57:04 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:58:31 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:58:33 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:58:35 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:58:45 --> 404 Page Not Found: /index
ERROR - 2022-04-22 08:58:54 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:54:52 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:55:02 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-04-22 12:55:03 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:55:12 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:56:06 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:56:12 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:56:14 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:56:17 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:56:46 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:57:00 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:57:14 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:57:16 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:57:17 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:57:22 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:57:26 --> 404 Page Not Found: /index
ERROR - 2022-04-22 12:57:35 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:57:56 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:57:58 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:58:02 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:01 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:08 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:10 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:15 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:29 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:55 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:57 --> 404 Page Not Found: /index
ERROR - 2022-04-22 13:59:59 --> 404 Page Not Found: /index
ERROR - 2022-04-22 14:00:04 --> 404 Page Not Found: /index
ERROR - 2022-04-22 14:00:07 --> 404 Page Not Found: /index
ERROR - 2022-04-22 14:00:12 --> 404 Page Not Found: /index
ERROR - 2022-04-22 14:00:28 --> 404 Page Not Found: /index
ERROR - 2022-04-22 14:00:31 --> 404 Page Not Found: /index
