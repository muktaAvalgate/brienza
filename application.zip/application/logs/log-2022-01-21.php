<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-21 06:24:49 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\brienza\application\third_party\MX\Router.php 239
ERROR - 2022-01-21 06:24:50 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 06:24:50 --> Query error: Unknown column 'last_login_ip' in 'field list' - Invalid query: UPDATE `users` SET `last_login` = '2022-01-21 06:24:50', `last_login_ip` = '::1'
WHERE `id` = '5'
ERROR - 2022-01-21 06:25:52 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\brienza\application\third_party\MX\Router.php 239
ERROR - 2022-01-21 06:25:52 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 06:25:52 --> Query error: Unknown column 'last_login_ip' in 'field list' - Invalid query: UPDATE `users` SET `last_login` = '2022-01-21 06:25:52', `last_login_ip` = '::1'
WHERE `id` = '5'
ERROR - 2022-01-21 06:28:48 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 06:28:48 --> Query error: Unknown column 'last_login_ip' in 'field list' - Invalid query: UPDATE `users` SET `last_login` = '2022-01-21 06:28:48', `last_login_ip` = '::1'
WHERE `id` = '5'
ERROR - 2022-01-21 06:29:07 --> Query error: Table 'wyktsmhg_baalivepro.sessions' doesn't exist - Invalid query: SELECT *
FROM `sessions`
ERROR - 2022-01-21 06:29:14 --> Query error: Table 'wyktsmhg_baalivepro.sessions' doesn't exist - Invalid query: SELECT *
FROM `sessions`
ERROR - 2022-01-21 06:29:15 --> Query error: Table 'wyktsmhg_baalivepro.sessions' doesn't exist - Invalid query: SELECT *
FROM `sessions`
ERROR - 2022-01-21 06:30:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 06:53:00 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\brienza\application\libraries\tcpdf\tcpdf.php 16900
ERROR - 2022-01-21 06:53:00 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\brienza\application\libraries\tcpdf\tcpdf.php 16900
ERROR - 2022-01-21 06:53:00 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\brienza\application\libraries\tcpdf\tcpdf.php 16903
ERROR - 2022-01-21 06:53:00 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\brienza\application\libraries\tcpdf\include\tcpdf_images.php 314
ERROR - 2022-01-21 07:04:19 --> 404 Page Not Found: /index
ERROR - 2022-01-21 07:04:26 --> 404 Page Not Found: /index
ERROR - 2022-01-21 07:18:36 --> 404 Page Not Found: /index
ERROR - 2022-01-21 07:18:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 07:18:45 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-21 07:18:46 --> 404 Page Not Found: /index
ERROR - 2022-01-21 07:58:54 --> 404 Page Not Found: /index
ERROR - 2022-01-21 07:59:24 --> 404 Page Not Found: /index
ERROR - 2022-01-21 07:59:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 07:59:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:01:21 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:01:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:01:30 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:01:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 08:01:38 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 08:01:39 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:01:46 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:01:49 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:02:07 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:02:07 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:02:51 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:02:51 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:03:30 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:03:30 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:04:27 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:04:27 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:05:27 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:08:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 08:08:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:09:45 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:09:59 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 11:10:01 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:10:12 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:10:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-01-21 11:10:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-01-21 11:10:33 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:11:09 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:11:20 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:11:23 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:11:28 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:12:40 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:12:46 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:13:15 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:16:27 --> 404 Page Not Found: /index
ERROR - 2022-01-21 11:16:38 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:26:33 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:26:51 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:28:11 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:28:18 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:28:28 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:29:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:29:11 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:30:46 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:31:02 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:31:26 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:32:24 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:32:38 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:47:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:48:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:49:51 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:49:54 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:49:55 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:55:54 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:55:54 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:56:35 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:56:36 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:03:16 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:03:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:04:18 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:04:18 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:18:52 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:18:58 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:19:14 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:19:16 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:19:29 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:19:31 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:20:57 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:20:59 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:21:15 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:21:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:22:12 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:22:15 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:23:39 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:23:40 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:24:01 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:24:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:24:08 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:24:13 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:24:43 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:24:45 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:25:20 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:25:21 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:25:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:25:43 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:25:43 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:37:12 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:37:13 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:37:30 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:37:30 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:38:09 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:38:09 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:38:15 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:38:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:41:06 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:41:07 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:41:26 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:41:27 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:01 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:01 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:10 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:11 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:48 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:48 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:54 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:43:54 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:08 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:09 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:11 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:11 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:13 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:13 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:15 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:15 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:19 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:19 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:23 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:26 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:27 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:30 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:30 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:34 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:35 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:36 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:37 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:39 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:40 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:42 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:42 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:45 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:45 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:48 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:48 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:51 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:44:52 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:46:31 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:46:32 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 48
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 52
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 53
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-01-21 13:46:45 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza\application\modules\App\views\presenters\create_log.php 54
ERROR - 2022-01-21 13:46:45 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:46:46 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:46:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:47:14 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:47:14 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:47:35 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:47:35 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:47:46 --> 404 Page Not Found: /index
ERROR - 2022-01-21 13:47:47 --> 404 Page Not Found: /index
