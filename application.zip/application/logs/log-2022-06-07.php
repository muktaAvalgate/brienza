<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-07 09:56:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
