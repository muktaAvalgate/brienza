<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-31 06:27:46 --> 404 Page Not Found: /index
ERROR - 2022-10-31 06:29:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-31 06:29:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:29:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:29:36 --> 404 Page Not Found: /index
ERROR - 2022-10-31 06:29:45 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-10-31 06:29:48 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-10-31 06:29:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:29:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:29:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:31:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:31:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:31:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:31:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:31:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:31:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:32:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:32:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:32:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:41:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:41:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:41:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:41:42 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 06:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 06:41:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:41:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:52:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:52:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:52:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:52:52 --> 404 Page Not Found: /index
ERROR - 2022-10-31 06:52:53 --> 404 Page Not Found: /index
ERROR - 2022-10-31 06:52:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:52:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:52:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:52:55 --> 404 Page Not Found: /index
ERROR - 2022-10-31 06:53:03 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:53:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:53:03 --> 404 Page Not Found: /index
ERROR - 2022-10-31 06:53:24 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 06:53:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:53:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 06:53:24 --> 404 Page Not Found: /index
ERROR - 2022-10-31 07:00:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:00:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:00:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:00:46 --> 404 Page Not Found: /index
ERROR - 2022-10-31 07:05:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:05:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:05:09 --> 404 Page Not Found: /index
ERROR - 2022-10-31 07:05:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:05:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:05:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:05:12 --> 404 Page Not Found: /index
ERROR - 2022-10-31 07:09:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:09:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:09:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:14:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:14:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:14:19 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:14:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:14:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:14:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:15:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:15:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:15:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:15:43 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:15:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:15:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:23:44 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:23:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:23:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:23:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:23:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:08 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:29:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:29:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:09 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:29:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:29:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:29:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:14 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:29:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:29:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:29:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:29:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:29:29 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:37:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:37:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:37:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:37:17 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:42:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:42:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:42:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:42:28 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:52:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:52:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:52:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:52:06 --> 404 Page Not Found: /index
ERROR - 2022-10-31 07:52:12 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:54:58 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:54:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:54:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:54:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:55:00 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:55:13 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:55:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:55:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:55:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:55:15 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:55:28 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:55:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:55:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:55:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:55:31 --> Severity: error --> Exception: Too few arguments to function Presenters::custom_template_for_admin(), 0 passed in C:\xampp\htdocs\brienza_backup\system\core\CodeIgniter.php on line 514 and exactly 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2594
ERROR - 2022-10-31 07:56:11 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:56:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:56:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:56:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:56:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:56:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:56:28 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 07:56:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 07:56:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 07:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:01:04 --> Severity: error --> Exception: Call to undefined method App_model::get_topic() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2602
ERROR - 2022-10-31 08:02:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:02:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:02:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:02:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:02:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:02:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:41:30 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:41:31 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:41:33 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:41:33 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:41:33 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:41:37 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:41:40 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:42:21 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:42:24 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:42:25 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:42:25 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:42:25 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:42:54 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:42:57 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:44:06 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-10-31 08:44:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:44:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:44:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:44:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:44:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:44:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:44:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:44:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:44:49 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ';' C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5425
ERROR - 2022-10-31 08:45:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:45:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:12 --> Severity: Notice --> Undefined variable: topics C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 08:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 08:45:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:45:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:28 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:45:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:28 --> 404 Page Not Found: /index
ERROR - 2022-10-31 08:45:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:45:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:30 --> 404 Page Not Found: /index
ERROR - 2022-10-31 08:45:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:45:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:31 --> 404 Page Not Found: /index
ERROR - 2022-10-31 08:45:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:45:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:45:36 --> Query error: Unknown column 'topic.id' in 'where clause' - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `order_schedules` ON `order_schedules`.`topic_id` = `topic`.`id`
WHERE `topic`.`id` = '15'
ERROR - 2022-10-31 08:46:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:46:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:46:50 --> Query error: Unknown column 'topic.id' in 'on clause' - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `order_schedules` ON `order_schedules`.`topic_id` = `topic`.`id`
WHERE `created_by` = '15'
ERROR - 2022-10-31 08:48:30 --> Query error: Unknown column 'topic.id' in 'on clause' - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `order_schedules` ON `order_schedules`.`topic_id` = `topic`.`id`
ERROR - 2022-10-31 08:48:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 08:48:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 08:48:35 --> Query error: Unknown column 'topic.id' in 'on clause' - Invalid query: SELECT `topic`
FROM `title_topics`
JOIN `order_schedules` ON `order_schedules`.`topic_id` = `topic`.`id`
ERROR - 2022-10-31 10:28:53 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:29:16 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:29:22 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:29:34 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:29:37 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:29:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:29:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:29:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:29:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:29:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:29:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 10:29:53 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:30:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 10:30:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:30:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:30:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:30:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:30:25 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:30:27 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:30:47 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:31:17 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:31:31 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:32:14 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:33:20 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:40:32 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:43:14 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:45:57 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:48:35 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:49:07 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:49:12 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:55:25 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:55:29 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:55:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:55:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:55:41 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:55:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 10:55:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:56:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 10:56:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:56:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 10:56:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:56:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 10:56:21 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:56:23 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:56:26 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:56:28 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:56:44 --> 404 Page Not Found: /index
ERROR - 2022-10-31 10:56:56 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:00:16 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:02:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:02:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:02:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:03:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:03:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:06:01 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:06:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:06:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:06:14 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:06:22 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:06:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:06:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:06:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:06:58 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:07:00 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:07:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:07:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:07:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:07:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 11:07:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:07:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 11:07:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:07:38 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:07:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:07:47 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:07:50 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:08:03 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:08:11 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:09:50 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:09:50 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:09:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:10:09 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:10:29 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:10:56 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:11:02 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:11:20 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:11:23 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:11:34 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:11:36 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:11:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:11:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:11:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:11:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 11:11:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:12:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 11:12:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:12:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:12:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:12:11 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:12:20 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:12:29 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:13:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:13:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:13:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:14:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:14:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:14:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:15:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:15:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:15:23 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:15:26 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:15:30 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:15:38 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:15:40 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:16:14 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:16:14 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:30:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:30:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:30:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:31:59 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:32:00 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:32:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:32:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:32:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:32:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:32:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 11:32:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:32:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 11:32:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:32:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:32:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:32:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:33:05 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:33:18 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:33:27 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:34:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:34:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:34:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:34:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:34:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:35:39 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:35:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:35:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:36:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 11:36:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:36:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 11:36:08 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:36:11 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:36:35 --> 404 Page Not Found: /index
ERROR - 2022-10-31 11:59:23 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:00:06 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:00:13 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:00:38 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:00:42 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:00:58 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:01:01 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:01:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:01:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:01:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:01:14 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:01:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:01:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:01:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:01:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:01:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:01:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:02:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:02:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:02:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:02:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:02:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:02:13 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:03:22 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:03:50 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:08:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:08:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:08:09 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:08:15 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:08:17 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:08:52 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:10:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:10:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:12:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:12:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:12:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:12:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:12:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:12:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:12:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:13:00 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:13:08 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:13:12 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:13:40 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:13:54 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:14:03 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:14:11 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:17:42 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:18:17 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:18:22 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:18:31 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:18:34 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:19:10 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-10-31 12:19:10 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:19:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:19:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:19:13 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:19:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:19:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:19:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:19:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:19:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:20:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:20:20 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:20:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:20:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:21:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 12:21:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:21:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:21:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:21:42 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:21:45 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:22:55 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:25:32 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:26:34 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:27:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:27:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:27:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:28:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:28:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:28:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:28:17 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:28:20 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:28:29 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:34:05 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:36:34 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:36:54 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:37:08 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:40:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:40:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:40:33 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:40:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 12:40:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:40:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 12:40:36 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:40:44 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:41:10 --> 404 Page Not Found: /index
ERROR - 2022-10-31 12:42:03 --> 404 Page Not Found: /index
ERROR - 2022-10-31 13:51:04 --> 404 Page Not Found: /index
ERROR - 2022-10-31 13:57:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 13:57:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 13:57:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 13:58:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 13:58:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 13:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 13:59:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 13:59:16 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 13:59:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 14:05:21 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 35
ERROR - 2022-10-31 14:05:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 14:05:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 14:05:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 14:05:29 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 35
ERROR - 2022-10-31 14:05:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 14:05:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 14:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 14:05:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\scheduling.php 375
ERROR - 2022-10-31 14:05:51 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 14:12:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-10-31 14:12:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 14:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-10-31 14:12:34 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
ERROR - 2022-10-31 14:23:36 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 34
