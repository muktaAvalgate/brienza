<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-15 05:05:00 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:05:05 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:05:18 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:05:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:05:31 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:06:07 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:06:16 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:42:18 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:42:21 --> 404 Page Not Found: /index
ERROR - 2021-12-15 01:42:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 06:42:34 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:42:39 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:42:41 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:43:25 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:16:46 --> 404 Page Not Found: /index
ERROR - 2021-12-15 04:17:49 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 09:18:21 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:18:27 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:19:39 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:21:10 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:31:44 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:31:57 --> 404 Page Not Found: /index
ERROR - 2021-12-15 04:32:10 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-15 09:32:18 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:33:29 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:48:02 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:48:15 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:48:32 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:48:37 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:49:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:49:06 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:49:15 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:49:31 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:49:35 --> 404 Page Not Found: /index
ERROR - 2021-12-15 04:49:43 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 09:50:23 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:50:40 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:50:56 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:50:58 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:55:02 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:55:21 --> 404 Page Not Found: /index
ERROR - 2021-12-15 09:55:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 04:56:18 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-15 04:56:28 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-15 09:56:37 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:02:43 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:02:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 10:02:56 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:03:02 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:03:09 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:03:22 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-15 05:03:28 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-15 10:03:43 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:06 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:13 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:16 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:21 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:30 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:33 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:50 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:04:55 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:05:00 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:05:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:05:32 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:05:44 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:05:56 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:06:01 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:07:48 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:08:11 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:08:16 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:08:58 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:09:05 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 10:09:07 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:09:09 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:09:13 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:09:22 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:10:16 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:11:53 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:27:57 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:28:31 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:33:58 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:34:04 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:34:07 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:34:11 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:35:55 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:36:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:37:29 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:37:35 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 10:37:37 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:37:45 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:38:20 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:38:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:38:44 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:38:48 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 10:38:50 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:38:52 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:40:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:40:10 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:40:12 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:40:42 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:41:12 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:41:20 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:41:25 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:41:36 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:41:43 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:42:06 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:42:17 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:42:29 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:43:19 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:43:32 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:43:54 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:44:12 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:44:58 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:45:04 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:45:23 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:45:37 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:51:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:51:22 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:52:33 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:52:42 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:52:53 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:53:19 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:53:40 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:54:42 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:02 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:07 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:15 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:29 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:32 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:34 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:57 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:55:59 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:59:12 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:59:17 --> 404 Page Not Found: /index
ERROR - 2021-12-15 05:59:25 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 05:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 10:59:27 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:59:31 --> 404 Page Not Found: /index
ERROR - 2021-12-15 10:59:35 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:00:28 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 06:00:28 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 11:00:30 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:00:42 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:00:46 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:00:51 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 11:00:51 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:00:52 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:00:56 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:04 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:18 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:19 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:24 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:01:26 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 11:01:27 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:28 --> 404 Page Not Found: /index
ERROR - 2021-12-15 06:01:29 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 06:01:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 11:01:30 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:31 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:32 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:38 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:01:43 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:02:01 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:02:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:02:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:02:27 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:03:21 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:03:21 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:03:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:03:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:04:50 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:04:54 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:05:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:05:05 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:05:05 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:06:00 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:06:08 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:08:25 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:09:18 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:09:31 --> 404 Page Not Found: /index
ERROR - 2021-12-15 11:33:25 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:16:29 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:17:04 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:18:42 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:18:51 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:18:56 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:19:00 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:19:07 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:19:14 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:21:01 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:21:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:22:20 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:22:23 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:22:27 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:22:29 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:22:47 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:22:49 --> 404 Page Not Found: /index
ERROR - 2021-12-15 12:24:05 --> 404 Page Not Found: /index
ERROR - 2021-12-15 13:02:59 --> 404 Page Not Found: /index
ERROR - 2021-12-15 08:03:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 08:40:04 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 08:48:36 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 08:48:36 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 08:49:11 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 08:49:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 20:16:23 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:16:38 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:16:43 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:17:18 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:17:35 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:22:40 --> 404 Page Not Found: /index
ERROR - 2021-12-15 15:22:51 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3458
ERROR - 2021-12-15 15:22:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Orders.php 387
ERROR - 2021-12-15 20:22:58 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:23:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 15:23:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 709
ERROR - 2021-12-15 20:23:14 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:23:17 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:23:22 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:23:33 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:23:37 --> 404 Page Not Found: /index
ERROR - 2021-12-15 15:23:41 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 15:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-15 20:23:43 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:23:46 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:24:07 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:24:19 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:24:39 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:25:01 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:25:08 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:25:33 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:25:43 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:25:46 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:25:48 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:26:03 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:26:05 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:26:26 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:26:29 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:26:48 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:26:52 --> 404 Page Not Found: /index
ERROR - 2021-12-15 20:27:10 --> 404 Page Not Found: /index
