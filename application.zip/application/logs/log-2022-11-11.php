<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-11 06:14:12 --> 404 Page Not Found: /index
ERROR - 2022-11-11 06:14:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-11 06:14:46 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-11 06:14:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-11 06:14:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-11 06:14:49 --> 404 Page Not Found: /index
ERROR - 2022-11-11 06:15:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-11 06:15:23 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-11 06:15:23 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-11 06:15:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-11 06:15:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-11 06:15:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-11 06:15:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-11 06:15:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 184
ERROR - 2022-11-11 06:15:45 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 180
ERROR - 2022-11-11 06:29:52 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 06:29:52 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 06:29:52 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 06:55:25 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 06:55:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 06:55:25 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 06:55:35 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 06:55:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 06:55:35 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 06:56:00 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 06:56:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 06:56:00 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 06:56:11 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 06:56:11 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 06:56:12 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 06:56:34 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 06:56:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 06:56:34 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 06:56:55 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 06:56:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 06:56:56 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 07:01:37 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 07:01:37 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 07:01:38 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 07:03:39 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:03:40 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:20:17 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:20:21 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:20:26 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:20:28 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:20:32 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:20:33 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:20:46 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:23:08 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:23:46 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:24:10 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:24:10 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:25:15 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:30:44 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:30:53 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:31:14 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:31:22 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:31:23 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:32:09 --> 404 Page Not Found: /index
ERROR - 2022-11-11 07:37:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-11 07:42:58 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 07:42:58 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 07:42:59 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 07:43:34 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 07:43:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 07:43:34 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 07:59:55 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 07:59:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 07:59:56 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 08:39:02 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 08:39:02 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 08:39:02 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 08:39:54 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 08:39:54 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 08:39:55 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 10:21:47 --> Severity: Notice --> Undefined variable: teacher_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 91
ERROR - 2022-11-11 10:21:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\add_blink.php 99
ERROR - 2022-11-11 10:21:47 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 10:22:04 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 10:29:05 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 10:42:38 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 10:45:29 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-11-11 10:49:12 --> Severity: Notice --> Undefined property: CI::$App_model C:\xampp\htdocs\brienza_backup\application\third_party\MX\Controller.php 59
ERROR - 2022-11-11 10:49:12 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 266
ERROR - 2022-11-11 10:50:35 --> Severity: Notice --> Undefined property: CI::$App_model C:\xampp\htdocs\brienza_backup\application\third_party\MX\Controller.php 59
ERROR - 2022-11-11 10:50:35 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Notifications.php 266
ERROR - 2022-11-11 11:14:21 --> 404 Page Not Found: /index
