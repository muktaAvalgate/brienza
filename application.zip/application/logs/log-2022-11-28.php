<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-28 06:06:31 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:07:12 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-28 06:07:18 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:07:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-28 06:07:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-28 06:09:51 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:12:37 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:12:39 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:39:07 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:39:23 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:39:36 --> 404 Page Not Found: /index
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:44:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:58:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:58:44 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:58:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:59:35 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 06:59:36 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 07:04:56 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:04:57 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:33:29 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:34:56 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:35:36 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:37:33 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:37:36 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:39:10 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:39:30 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:39:53 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:42:41 --> 404 Page Not Found: /index
ERROR - 2022-11-28 07:43:07 --> 404 Page Not Found: /index
ERROR - 2022-11-28 08:38:19 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:28:03 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:28:23 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-28 10:28:28 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:28:59 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:29:09 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:29:16 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:29:19 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:29:33 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:29:37 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:29:41 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:29:49 --> Severity: Notice --> Undefined index: profile_pic C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Schools.php 335
ERROR - 2022-11-28 10:29:59 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:30:17 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:30:18 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:30:28 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:30:30 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:30:34 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:30:47 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:31:53 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:32:03 --> 404 Page Not Found: /index
ERROR - 2022-11-28 10:33:16 --> 404 Page Not Found: /index
ERROR - 2022-11-28 11:23:11 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-28 12:21:00 --> 404 Page Not Found: /index
ERROR - 2022-11-28 12:30:40 --> 404 Page Not Found: /index
ERROR - 2022-11-28 12:32:39 --> 404 Page Not Found: /index
ERROR - 2022-11-28 12:33:45 --> 404 Page Not Found: /index
ERROR - 2022-11-28 13:05:21 --> 404 Page Not Found: /index
ERROR - 2022-11-28 13:05:29 --> 404 Page Not Found: /index
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:15:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:07 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:25:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:25:27 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:26:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:34:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:35:25 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:35:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 134
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 134
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 148
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 148
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 181
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 181
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 185
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 185
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 188
ERROR - 2022-11-28 13:41:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 188
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 134
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 134
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 148
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 148
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 181
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 181
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 185
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 185
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 188
ERROR - 2022-11-28 13:41:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 188
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 134
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 134
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 145
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 148
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 148
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 151
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 154
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 181
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 181
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 185
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 185
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 188
ERROR - 2022-11-28 13:43:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 188
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:45:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:46:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:46:50 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:47:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:48:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 105
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 113
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 152
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 156
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 158
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:49:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 108
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 116
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 122
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 125
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 128
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 131
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 131
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 155
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 155
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 159
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 162
ERROR - 2022-11-28 13:50:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 162
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 13:59:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:58 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:02:59 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:04:53 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:04:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 110
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 121
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 157
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 161
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 163
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:11:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 164
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 118
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 126
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 126
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 132
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 132
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 135
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 135
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 135
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 135
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 135
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 135
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 138
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 138
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 138
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 138
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 138
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 138
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 141
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 141
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 165
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 165
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 169
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 169
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 171
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 171
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 172
ERROR - 2022-11-28 14:16:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 172
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 166
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 166
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 170
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 170
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 172
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 172
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 173
ERROR - 2022-11-28 14:18:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 173
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 119
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 127
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 133
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 136
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 139
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 142
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 166
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 166
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 170
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 170
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 172
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 172
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 173
ERROR - 2022-11-28 14:18:02 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 173
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:22:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:22:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:24:21 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 179
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 187
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 190
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 193
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 196
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 199
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 202
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 226
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 230
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 232
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
ERROR - 2022-11-28 14:24:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 233
