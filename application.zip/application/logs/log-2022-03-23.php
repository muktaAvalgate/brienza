<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-23 06:30:28 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:33:26 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 06:33:29 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-23 06:33:30 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:34:00 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:34:03 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:34:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 06:34:43 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:35:23 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:35:27 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:35:58 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:36:00 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:40:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:45:59 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:46:23 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-23 06:58:09 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:10 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:13 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:15 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:18 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:20 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:21 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:23 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:25 --> 404 Page Not Found: /index
ERROR - 2022-03-23 06:58:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 06:58:33 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 07:03:01 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:03:01 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:04:53 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:04:54 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:06:38 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:06:41 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:12:02 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:12:20 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:12:21 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:16:22 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:22:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:23:02 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:23:04 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:26:32 --> 404 Page Not Found: /index
ERROR - 2022-03-23 07:26:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 07:26:56 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:08:36 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:08:37 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:17:51 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:17:52 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:17:54 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:17:54 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:18:37 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:18:38 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:19:11 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:19:12 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:39:05 --> 404 Page Not Found: /index
ERROR - 2022-03-23 08:39:05 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:50:50 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:50:50 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:51:21 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:51:21 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:08 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:08 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:22 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-23 09:52:22 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:23 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:24 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:24 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:26 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:26 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:33 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:52:33 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:00 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:01 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:01 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:02 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:02 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:03 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:03 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:55:03 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:31 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:32 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:34 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:34 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:35 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:35 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:40 --> 404 Page Not Found: /index
ERROR - 2022-03-23 09:59:40 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:02:38 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:02:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:03:43 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:03:44 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:05:11 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:05:12 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:07:19 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:07:19 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:08:54 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:08:56 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:08:59 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:01 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:01 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:05 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:06 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:09:10 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:09:29 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:29 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:32 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:32 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:37 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:38 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:40 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:41 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:48 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:56 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:09:56 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:10:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:10:03 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:13:00 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:13:00 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:13:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:13:06 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:15:26 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:35 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 10:15:44 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-23 10:15:45 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:45 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:50 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:51 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:15:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:15:56 --> Severity: Notice --> Trying to get property 'teacher_name' of non-object C:\xampp\htdocs\brienza\application\modules\App\controllers\Presenters.php 1019
ERROR - 2022-03-23 10:16:50 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:16:51 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:17:01 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 10:17:02 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-23 10:17:02 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:17:02 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:17:08 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:17:09 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:17:11 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:17:11 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:06 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:10 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:13 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 10:22:23 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-23 10:22:23 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:24 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:25 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:25 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:27 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:27 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:44 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:44 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:50 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:22:50 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:49:50 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:49:51 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:09 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:10 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:12 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:12 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:38 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-03-23 10:51:38 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:39 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:42 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:42 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:44 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:45 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:49 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:51:49 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:52:02 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:52:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 10:52:09 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:54:56 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:54:58 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:55:16 --> Severity: Notice --> Undefined index: profile_pic C:\xampp\htdocs\brienza\application\modules\App\controllers\Schools.php 333
ERROR - 2022-03-23 10:55:21 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:55:23 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:55:30 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:55:51 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:55:53 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:55:55 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:56:23 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:56:30 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:56:37 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:56:42 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:56:42 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:57:03 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:57:03 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:57:32 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:57:32 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:57:47 --> 404 Page Not Found: /index
ERROR - 2022-03-23 10:57:47 --> 404 Page Not Found: /index
ERROR - 2022-03-23 11:07:51 --> 404 Page Not Found: /index
ERROR - 2022-03-23 11:07:51 --> 404 Page Not Found: /index
ERROR - 2022-03-23 12:23:00 --> 404 Page Not Found: /index
ERROR - 2022-03-23 12:23:01 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:27:47 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:27:47 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:27:49 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:27:56 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-03-23 13:27:59 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:32:34 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:32:35 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:37:19 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:37:19 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:38:20 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:38:20 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:44:04 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:44:05 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:44:43 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:44:43 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:46:06 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:46:06 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:52:07 --> 404 Page Not Found: /index
ERROR - 2022-03-23 13:52:07 --> 404 Page Not Found: /index
ERROR - 2022-03-23 14:04:15 --> 404 Page Not Found: /index
ERROR - 2022-03-23 14:04:16 --> 404 Page Not Found: /index
ERROR - 2022-03-23 14:04:35 --> 404 Page Not Found: /index
ERROR - 2022-03-23 14:04:35 --> 404 Page Not Found: /index
ERROR - 2022-03-23 14:05:18 --> 404 Page Not Found: /index
ERROR - 2022-03-23 14:05:18 --> 404 Page Not Found: /index
