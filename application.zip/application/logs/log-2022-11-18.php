<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-18 06:02:55 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:03:26 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-18 06:03:30 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-18 06:03:34 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-18 06:03:34 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:38:05 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:38:05 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:38:07 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:45:01 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:45:32 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:46:29 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:46:58 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:47:02 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:47:03 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:48:21 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:48:21 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:48:48 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:48:48 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:48:53 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:48:53 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:49:17 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:49:18 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:52:11 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:52:12 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:54:26 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:54:27 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:54:31 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:54:32 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:56:27 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:56:51 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:57:01 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:57:23 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:57:23 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:58:06 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:58:08 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:58:37 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:58:39 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:58:48 --> 404 Page Not Found: /index
ERROR - 2022-11-18 06:58:48 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:01:42 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:01:43 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:01:48 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:01:49 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:02:04 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:02:04 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:03:44 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:04:06 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-18 07:04:14 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:07:03 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:07:19 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:07:33 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:20:22 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:20:26 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:20:31 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:20:37 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:22:47 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:28:33 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:33:16 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:33:20 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:38:08 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:38:26 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:38:29 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:39:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_template_for_presenters.php 86
ERROR - 2022-11-18 07:39:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_template_for_presenters.php 92
ERROR - 2022-11-18 07:39:33 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:41:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_template_for_presenters.php 86
ERROR - 2022-11-18 07:41:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\log_template_for_presenters.php 90
ERROR - 2022-11-18 07:41:04 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:42:15 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:42:22 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:42:26 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:42:30 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:45:42 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:45:49 --> 404 Page Not Found: /index
ERROR - 2022-11-18 07:50:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-18 07:50:56 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-11-18 11:02:32 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:15:23 --> Severity: Notice --> Undefined variable: favorite_template C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 42
ERROR - 2022-11-18 11:15:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 42
ERROR - 2022-11-18 11:16:29 --> Severity: Notice --> Undefined variable: favorite_template C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 42
ERROR - 2022-11-18 11:16:29 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 42
ERROR - 2022-11-18 11:19:03 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\favorite_template.php 42
ERROR - 2022-11-18 11:43:45 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:43:57 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-11-18 11:44:00 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:44:30 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:44:30 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:44:31 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:44:33 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:44:37 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:44:39 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:44:43 --> 404 Page Not Found: /index
ERROR - 2022-11-18 11:49:46 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2773
ERROR - 2022-11-18 11:50:07 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2777
ERROR - 2022-11-18 11:52:08 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2774
ERROR - 2022-11-18 11:53:13 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2775
ERROR - 2022-11-18 12:07:23 --> 404 Page Not Found: /index
ERROR - 2022-11-18 12:07:54 --> 404 Page Not Found: /index
ERROR - 2022-11-18 12:53:42 --> 404 Page Not Found: /index
ERROR - 2022-11-18 12:53:56 --> 404 Page Not Found: /index
ERROR - 2022-11-18 12:55:18 --> 404 Page Not Found: /index
ERROR - 2022-11-18 13:19:00 --> 404 Page Not Found: /index
