<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-27 05:23:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:23:49 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:23:56 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:24:45 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:25:16 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:30:37 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:30:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 00:31:18 --> Severity: Notice --> Undefined variable: res /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/models/App_model.php 3502
ERROR - 2021-12-27 05:31:29 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:31:33 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:31:34 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:31:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:32:04 --> 404 Page Not Found: /index
ERROR - 2021-12-27 00:32:13 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 05:32:15 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:32:18 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:32:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:34:05 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:34:22 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:34:26 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:34:47 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:34:52 --> 404 Page Not Found: /index
ERROR - 2021-12-27 00:34:57 --> Severity: Notice --> Undefined variable: purchase_orders /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-27 00:34:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/scheduling.php 44
ERROR - 2021-12-27 05:34:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:35:02 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:35:07 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:35:32 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:35:37 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:35:41 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:35:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:39:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:39:24 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:39:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:40:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:40:07 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:40:14 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:40:23 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:40:26 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:40:56 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:42:02 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:42:23 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:42:50 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:43:23 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:43:27 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:44:33 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:44:37 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:44:44 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:48:41 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:49:01 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:49:08 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:49:50 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:50:06 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:50:11 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:50:19 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:54:37 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:54:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:54:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:54:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:54:59 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:55:24 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:55:30 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:55:37 --> 404 Page Not Found: /index
ERROR - 2021-12-27 05:56:16 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:01:40 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:01:48 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:03:04 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:03:09 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:03:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:04:11 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:04:25 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:04:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:04:54 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:14 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:16 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:25 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:28 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:31 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:35 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:05:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:07:01 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:15:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 01:17:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 06:17:10 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:17:29 --> 404 Page Not Found: /index
ERROR - 2021-12-27 01:17:34 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 06:17:35 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:17:45 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:17:51 --> 404 Page Not Found: /index
ERROR - 2021-12-27 01:17:53 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 06:17:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:18:24 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:18:29 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:19:28 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:19:36 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:19:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:22:53 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:25:02 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:02 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:07 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:13 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:18 --> 404 Page Not Found: /index
ERROR - 2021-12-27 01:27:19 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 06:27:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:38 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:44 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:47 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:27:50 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:28:00 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:28:04 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:28:11 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:28:17 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:28:24 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:28:36 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:28:41 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:41:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:42:57 --> 404 Page Not Found: /index
ERROR - 2021-12-27 06:43:34 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:05:25 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:05:48 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:05:50 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:06:00 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:06:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:06:08 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:06:17 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:06:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:06:23 --> 404 Page Not Found: /index
ERROR - 2021-12-27 07:07:47 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:21:22 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:21:27 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:21:35 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:21:46 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:22:13 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:22:30 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:22:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:22:53 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:22:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:22:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:23:38 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:24:14 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:24:25 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:24:28 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:25:17 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:25:22 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:25:31 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:25:57 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:26:05 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:26:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:27:21 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:27:35 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:27:56 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:27:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:00 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:07 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:24 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:27 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:32 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:28:50 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:29:08 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:29:13 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:29:36 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:29:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:37:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:37:17 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:37:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:37:29 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:38:38 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:38:53 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:38:57 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:39:13 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:39:18 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:39:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:39:52 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:39:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:40:02 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:40:06 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:40:15 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:40:18 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:40:22 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:40:27 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:40:34 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:40:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:40:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:41:17 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:41:23 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:17 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:23 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:29 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:34 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:39 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:44 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:49 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:42:53 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:44:53 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:45:12 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:45:49 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:47:28 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:47:46 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:47:48 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:47:51 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:47:57 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:48:12 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:48:28 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:49:04 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:49:32 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:49:45 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:49:48 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:50:05 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:50:09 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:50:16 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:50:27 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:50:46 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:51:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:51:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:51:15 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:51:17 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:51:24 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-27 03:51:33 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-27 08:51:34 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:51:43 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:52:41 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:52:54 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:53:03 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:53:05 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:53:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:53:28 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:53:33 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:53:44 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:53:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 03:57:35 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 08:57:37 --> 404 Page Not Found: /index
ERROR - 2021-12-27 08:57:41 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:35:12 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:35:16 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:35:26 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:36:35 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:37:25 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:37:31 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:37:34 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:40:07 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:40:40 --> 404 Page Not Found: /index
ERROR - 2021-12-27 04:40:50 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-27 09:40:51 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:40:53 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:40:58 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:01 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:10 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:30 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:39 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:45 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:50 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:52 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:41:54 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:11 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:15 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:19 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:29 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:33 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:45 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:53 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:42:55 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:43:12 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:43:33 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:43:57 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:44:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:44:23 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:44:31 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:44:42 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:44:47 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:46:57 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:47:29 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:47:41 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:47:51 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:47:52 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:47:56 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:50:11 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:50:26 --> 404 Page Not Found: /index
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-27 04:50:37 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-27 09:50:44 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:51:20 --> 404 Page Not Found: /index
ERROR - 2021-12-27 09:57:12 --> 404 Page Not Found: /index
ERROR - 2021-12-27 10:11:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 10:23:03 --> 404 Page Not Found: /index
ERROR - 2021-12-27 10:23:06 --> 404 Page Not Found: /index
ERROR - 2021-12-27 10:23:36 --> 404 Page Not Found: /index
ERROR - 2021-12-27 10:23:39 --> 404 Page Not Found: /index
ERROR - 2021-12-27 10:53:20 --> 404 Page Not Found: /index
