<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-12 08:12:27 --> 404 Page Not Found: /index
ERROR - 2022-01-12 08:12:34 --> 404 Page Not Found: /index
ERROR - 2022-01-12 08:12:37 --> 404 Page Not Found: /index
ERROR - 2022-01-12 08:12:45 --> 404 Page Not Found: /index
ERROR - 2022-01-12 06:12:02 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2022-01-12 11:12:25 --> 404 Page Not Found: /index
ERROR - 2022-01-12 07:40:30 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2022-01-12 12:50:07 --> 404 Page Not Found: /index
ERROR - 2022-01-12 12:50:10 --> 404 Page Not Found: /index
