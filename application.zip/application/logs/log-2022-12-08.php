<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-08 06:15:30 --> 404 Page Not Found: /index
ERROR - 2022-12-08 06:18:18 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-08 06:18:24 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-12-08 06:18:42 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-12-08 06:18:47 --> 404 Page Not Found: /index
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:19:17 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:22:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:22:42 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:22:43 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:24:06 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:24:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:25:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:25:14 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:25:38 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:51:18 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2915
ERROR - 2022-12-08 06:51:43 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2915
ERROR - 2022-12-08 06:52:21 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2915
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:52:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 06:53:39 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:09 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:11 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:11 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:11 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:12 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:12 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:12 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:12 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:12 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:12 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:12 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:13 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:13 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:13 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:13 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:13 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:13 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:13 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:14 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:14 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:14 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:14 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:14 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 06:56:14 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:02:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:02:32 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 07:02:36 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 07:03:04 --> Severity: Notice --> Trying to get property 'message' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2913
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:10:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:11:30 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 81
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 84
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 87
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 90
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 93
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 96
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 120
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 124
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 129
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:11:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 130
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> array_column() expects parameter 1 to be array, bool given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 43
ERROR - 2022-12-08 07:27:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_for_admin.php 44
ERROR - 2022-12-08 07:46:24 --> Severity: Notice --> Undefined variable: filterLogWritingRm C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2736
ERROR - 2022-12-08 07:46:36 --> Severity: error --> Exception: Too few arguments to function App_model::custom_tmp(), 0 passed in C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php on line 2736 and at least 1 expected C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5431
ERROR - 2022-12-08 07:50:02 --> Severity: Compile Error --> Cannot redeclare App_model::topic_name() C:\xampp\htdocs\brienza_backup\application\modules\App\models\App_model.php 5534
ERROR - 2022-12-08 07:50:41 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT `title_topics`.`topic`
FROM `title_topics`
JOIN `custom_templates` ON `title_topics`.`id` = `custom_templates`.`topic`
WHERE `id` = '9'
ERROR - 2022-12-08 08:14:52 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:14:59 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:15:05 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:15:06 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:15:28 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:42:23 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 109
ERROR - 2022-12-08 08:43:20 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 109
ERROR - 2022-12-08 08:43:22 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 109
ERROR - 2022-12-08 08:45:31 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:52:35 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:52:41 --> 404 Page Not Found: /index
ERROR - 2022-12-08 08:53:18 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-08 08:53:40 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 62
ERROR - 2022-12-08 08:59:59 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:01:24 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:01:28 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:01:35 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:01:39 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:01:43 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:01:50 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:04:55 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:04:58 --> 404 Page Not Found: /index
ERROR - 2022-12-08 09:08:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:07:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:07:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:07:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:08:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:08:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:08:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:08:53 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:08:53 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:08:53 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:08:53 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:08 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:08 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:22 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:22 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:27 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:27 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:27 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:27 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:27 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:38 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:38 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:09:38 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:38 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:09:38 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 63
ERROR - 2022-12-08 10:11:28 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:11:28 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:11:32 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:11:32 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:33 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:33 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:42 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:42 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:53 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:53 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:58 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:12:58 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:15:37 --> Severity: Warning --> Use of undefined constant topic - assumed 'topic' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:15:37 --> Severity: Notice --> Undefined index: topic C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 54
ERROR - 2022-12-08 10:29:37 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2777
ERROR - 2022-12-08 10:29:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:29:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:29:46 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2777
ERROR - 2022-12-08 10:29:46 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:29:46 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:30:18 --> Severity: error --> Exception: Call to undefined method App_model::topic_name_edit() C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2736
ERROR - 2022-12-08 10:30:32 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\controllers\Presenters.php 2778
ERROR - 2022-12-08 10:30:32 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:30:32 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:31 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:31 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:31 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:31 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:49 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:49 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:49 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:55 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:55 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:55 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:32:55 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:08 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:08 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:13 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:13 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:13 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:13 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:23 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:23 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:23 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:29 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:29 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:29 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:29 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:39 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:39 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:39 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:33:39 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:08 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:08 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:08 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:08 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:16 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:16 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:16 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:16 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:22 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:22 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:36:22 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:44:18 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:44:18 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:44:18 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:44:18 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:46:26 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:46:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:46:26 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:46:26 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:10 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:10 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:10 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:14 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:14 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:14 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:14 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:19 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:19 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:19 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:19 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:24 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:24 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:55:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:11 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:11 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:11 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:11 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:20 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:20 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:20 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:20 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:34 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:34 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:34 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:34 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:57:40 --> 404 Page Not Found: /index
ERROR - 2022-12-08 10:58:01 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:01 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:01 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:01 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:02 --> 404 Page Not Found: /index
ERROR - 2022-12-08 10:58:14 --> 404 Page Not Found: /index
ERROR - 2022-12-08 10:58:40 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:40 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:40 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:40 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:41 --> 404 Page Not Found: /index
ERROR - 2022-12-08 10:58:54 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:54 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:54 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:54 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:58:55 --> 404 Page Not Found: /index
ERROR - 2022-12-08 10:59:07 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:59:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:59:07 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:59:07 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:59:24 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:59:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:59:24 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 10:59:24 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:18 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:18 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:18 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:18 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:42 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:42 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:42 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:42 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:48 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:48 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:48 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:00:48 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:09 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:09 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:09 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:09 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:49 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:49 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:01:49 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:04:37 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:04:37 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:04:37 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:04:37 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:05:10 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:05:10 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:05:10 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:05:10 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:05:31 --> 404 Page Not Found: /index
ERROR - 2022-12-08 11:05:41 --> 404 Page Not Found: /index
ERROR - 2022-12-08 11:06:47 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:06:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:06:47 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:06:47 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:06:49 --> 404 Page Not Found: /index
ERROR - 2022-12-08 11:07:05 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:07:05 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:07:05 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:07:05 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:13:58 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:13:58 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:13:58 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:13:58 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:14:15 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:14:15 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:14:15 --> Severity: Notice --> Undefined variable: topic_name C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
ERROR - 2022-12-08 11:14:15 --> Severity: Notice --> Trying to get property 'topic' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\custom_template_edit.php 56
