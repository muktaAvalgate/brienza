<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-30 07:05:12 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:05:17 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:05:31 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:05:38 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:05:41 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:05:51 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:11:24 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:11:27 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:11:34 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:13:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:13:21 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:13:23 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:13:26 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:13:30 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:13:36 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:13:37 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:14:56 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:15:28 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:15:59 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:16:04 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:16:21 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:18:38 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:18:58 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:29:09 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:29:19 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:29:29 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:29:36 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:29:58 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:30:01 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:30:04 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:31:15 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:31:17 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:32:01 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:32:03 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:32:11 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:32:11 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:32:45 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:32:56 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:34:30 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:34:44 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:35:29 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:35:33 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:35:39 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:35:45 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:35:46 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:35:48 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:35:51 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:36:05 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:36:13 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:36:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:36:23 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:38:18 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:39:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:39:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:39:44 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:39:52 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:40:06 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:43:29 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:43:35 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:43:56 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:44:41 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:45:23 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:50:11 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:50:15 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:51:06 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:51:44 --> 404 Page Not Found: /index
ERROR - 2021-12-30 08:10:10 --> 404 Page Not Found: /index
ERROR - 2021-12-30 08:10:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:30:00 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:31:23 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:32:07 --> 404 Page Not Found: /index
ERROR - 2021-12-30 04:39:02 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-30 09:39:07 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:39:22 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:39:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:39:54 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:40:03 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:40:06 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:40:12 --> 404 Page Not Found: /index
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-30 04:40:23 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-30 09:40:24 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:40:37 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:41:05 --> 404 Page Not Found: /index
ERROR - 2021-12-30 04:41:16 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-30 09:41:17 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:41:22 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:41:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:41:41 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:41:48 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:42:00 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:42:10 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:44:48 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:46:05 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:46:23 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:46:27 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:46:38 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:46:42 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:48:59 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:49:22 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:49:36 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:50:04 --> 404 Page Not Found: /index
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 16
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 24
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 27
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 30
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 33
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 36
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 39
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 48
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: order /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 52
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 53
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Undefined variable: schedule /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-30 04:50:31 --> Severity: Notice --> Trying to get property of non-object /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/views/presenters/create_log.php 54
ERROR - 2021-12-30 09:50:33 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:50:42 --> 404 Page Not Found: /index
ERROR - 2021-12-30 09:51:05 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:06:40 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:06:46 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:07:16 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:12:16 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:12:24 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:12:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:12:36 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:12:56 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:13:14 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:13:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:13:26 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:13:30 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:15:27 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:15:35 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:16:11 --> 404 Page Not Found: /index
ERROR - 2021-12-30 05:16:18 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-30 10:16:21 --> 404 Page Not Found: /index
ERROR - 2021-12-30 05:16:43 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-30 10:16:47 --> 404 Page Not Found: /index
ERROR - 2021-12-30 05:17:06 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-30 10:17:09 --> 404 Page Not Found: /index
ERROR - 2021-12-30 05:17:28 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-30 10:17:30 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:18:43 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:19:38 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:20:38 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:21:15 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:21:17 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:21:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:22:02 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:22:10 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:22:14 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:22:35 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:22:46 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:22:48 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:23:28 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:23:55 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:06 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:09 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:10 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:14 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:16 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:22 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:24 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:28 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:24:34 --> 404 Page Not Found: /index
ERROR - 2021-12-30 05:32:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-30 10:35:25 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:35:25 --> 404 Page Not Found: /index
ERROR - 2021-12-30 10:42:12 --> 404 Page Not Found: /index
ERROR - 2021-12-30 05:43:29 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-30 10:59:59 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:00:09 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:00:17 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:00:28 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:00:36 --> 404 Page Not Found: /index
ERROR - 2021-12-30 06:00:42 --> Severity: Notice --> Undefined index: profile_pic /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/App/controllers/Schools.php 333
ERROR - 2021-12-30 11:00:44 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:00:50 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:01:04 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:01:08 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:01:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:01:34 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:01:38 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:01:44 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:01:53 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:04 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:08 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:13 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:18 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:28 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:37 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:41 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:44 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:02:52 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:03:00 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:03:04 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:46:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:46:36 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:46:39 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:46:49 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:47:14 --> 404 Page Not Found: /index
ERROR - 2021-12-30 06:47:20 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-30 11:47:21 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:47:33 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:47:46 --> 404 Page Not Found: /index
ERROR - 2021-12-30 11:49:09 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:08:57 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:09:24 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:09:26 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:09:32 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:45:19 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:45:57 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:46:07 --> 404 Page Not Found: /index
ERROR - 2021-12-30 07:46:19 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-30 12:46:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:46:24 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:46:31 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:46:59 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:47:53 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:49:29 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:49:34 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:49:45 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:49:45 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:50:20 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:51:23 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:53:25 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:53:38 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:53:39 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:53:43 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:53:44 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:08 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:08 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:12 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:13 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:14 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:14 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:36 --> 404 Page Not Found: /index
ERROR - 2021-12-30 12:54:37 --> 404 Page Not Found: /index
ERROR - 2021-12-30 19:28:07 --> 404 Page Not Found: /index
ERROR - 2021-12-30 14:28:20 --> Severity: Notice --> Undefined variable: total_new_schedule_hour /home/wyktsmhg/public_html/baasolutionsonline.east-coast-developer.pro/application/modules/Auth/views/dashboard.php 756
ERROR - 2021-12-30 19:28:25 --> 404 Page Not Found: /index
ERROR - 2021-12-30 19:28:27 --> 404 Page Not Found: /index
ERROR - 2021-12-30 19:28:43 --> 404 Page Not Found: /index
ERROR - 2021-12-30 19:29:22 --> 404 Page Not Found: /index
