<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-12 07:25:11 --> 404 Page Not Found: /index
ERROR - 2022-09-12 07:26:16 --> 404 Page Not Found: /index
ERROR - 2022-09-12 07:26:29 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-12 07:26:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:26:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:26:37 --> 404 Page Not Found: /index
ERROR - 2022-09-12 07:26:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-12 07:26:41 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-12 07:26:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:26:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:26:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-12 07:26:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-12 07:26:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:26:54 --> 404 Page Not Found: /index
ERROR - 2022-09-12 07:31:45 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-09-12 07:31:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:31:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:31:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:31:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:31:51 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-09-12 07:31:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:04 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-09-12 07:32:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:08 --> 404 Page Not Found: /index
ERROR - 2022-09-12 07:32:10 --> 404 Page Not Found: /index
ERROR - 2022-09-12 07:32:12 --> 404 Page Not Found: /index
ERROR - 2022-09-12 07:32:28 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-12 07:32:30 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-12 07:32:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:32:47 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 07:34:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 07:34:07 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:27:27 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:27:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:27:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:27:36 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:27:48 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:27:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:27:57 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:28:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:28:04 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:28:35 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 08:28:36 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:55:59 --> 404 Page Not Found: /index
ERROR - 2022-09-12 08:56:05 --> 404 Page Not Found: /index
ERROR - 2022-09-12 09:43:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-12 09:43:33 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-12 09:43:33 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:43:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:43:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:43:40 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:43:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:43:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:44:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:44:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:44:25 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 09:45:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:45:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:45:28 --> 404 Page Not Found: /index
ERROR - 2022-09-12 09:53:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:53:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 09:53:22 --> 404 Page Not Found: /index
ERROR - 2022-09-12 10:48:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:05 --> 404 Page Not Found: /index
ERROR - 2022-09-12 10:48:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-12 10:48:20 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-09-12 10:48:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:20 --> 404 Page Not Found: /index
ERROR - 2022-09-12 10:48:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:30 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:30 --> 404 Page Not Found: /index
ERROR - 2022-09-12 10:48:33 --> 404 Page Not Found: /index
ERROR - 2022-09-12 10:48:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:54:10 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:54:10 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 10:56:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:56:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:56:17 --> 404 Page Not Found: /index
ERROR - 2022-09-12 10:57:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:57:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:58:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 10:58:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:27:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:27:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:27:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:27:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:27:30 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:30:30 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:30:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:30:38 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:44:50 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:44:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:44:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:44:59 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:46:50 --> Severity: error --> Exception: syntax error, unexpected '$item' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-12 11:46:51 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:46:54 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:47:09 --> Severity: error --> Exception: syntax error, unexpected '$item' (T_VARIABLE) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-12 11:47:09 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:47:32 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-12 11:47:32 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:47:33 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-12 11:47:33 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:48:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:48:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:48:27 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:48:50 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-12 11:48:50 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:51:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:51:54 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:52:06 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:52:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:52:06 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:52:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:52:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:52:08 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:53:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:53:32 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:54:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:54:11 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:55:07 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:55:08 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:55:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:55:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:55:46 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:59:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:24 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:59:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:25 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:59:27 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:27 --> 404 Page Not Found: /index
ERROR - 2022-09-12 11:59:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 11:59:33 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:00:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:00:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:00:30 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:01:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:01:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:01:45 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:01:46 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:01:46 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:01:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:01:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:01:50 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:02:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:02:14 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:02:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:02:17 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:03:34 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:03:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:03:35 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:03:43 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:09:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-09-12 12:09:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:09:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:09:38 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:09:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:09:44 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:10:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:10:03 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:11:01 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:01 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:11:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:28 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:11:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:30 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:11:38 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:38 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:11:42 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:42 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:11:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:48 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:11:58 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:11:58 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:12:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:12:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:12:13 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:12:52 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:12:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:12:53 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:17:57 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 59
ERROR - 2022-09-12 12:17:57 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:19:28 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 63
ERROR - 2022-09-12 12:19:28 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:19:29 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 63
ERROR - 2022-09-12 12:19:29 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:19:30 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 63
ERROR - 2022-09-12 12:19:30 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:20:00 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 63
ERROR - 2022-09-12 12:20:00 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:20:00 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\brienza_backup\application\modules\App\views\notifications\list.php 63
ERROR - 2022-09-12 12:20:00 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:25:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:18 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:25:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:37 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:25:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:51 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:25:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:25:55 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:26:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:26:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:26:12 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:26:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:26:15 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:26:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:26:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:26:26 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:27:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:10 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:27:17 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:18 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:27:25 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:26 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:27:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:51 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:27:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:27:57 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:28:00 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:00 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:28:12 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:12 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:28:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:18 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:28:23 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:23 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:28:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:46 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 12:28:48 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:28:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:29:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:29:02 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 12:29:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:29:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:29:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:29:51 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:30:02 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:25 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 12:30:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:54 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:30:54 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:31:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:31:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:31:15 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:31:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:31:19 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:31:57 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:31:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:31:57 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:32:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:32:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:32:11 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:32:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:32:43 --> 404 Page Not Found: /index
ERROR - 2022-09-12 12:32:59 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 12:32:59 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:25:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:25:48 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:25:53 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:25:53 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:26:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:26:33 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:15 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:20 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:24 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:39 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:39 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:43 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:43 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:44 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:44 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:46 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:31:51 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:31:52 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:33:13 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:13 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:33:19 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:20 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:33:24 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:25 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:33:28 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:33:28 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:09 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:09 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:11 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:14 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:20 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:20 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:23 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:37 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:38 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:47 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:47 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:34:49 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:34:49 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:37:56 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:37:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:37:57 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:38:05 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:05 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:38:11 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:11 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:38:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:15 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:38:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:38:18 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:40:21 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:40:21 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:42:08 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:08 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:42:32 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:33 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:42:41 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:41 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:42:45 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:45 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:42:55 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:42:55 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:43:14 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:43:14 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:43:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:03 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:03 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 13:44:22 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:26 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:26 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:44:29 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:30 --> 404 Page Not Found: /index
ERROR - 2022-09-12 13:44:31 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 13:44:32 --> 404 Page Not Found: /index
ERROR - 2022-09-12 14:20:15 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 14:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 14:42:04 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 14:42:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 14:42:04 --> 404 Page Not Found: ../modules/App/controllers/Notifications/css
ERROR - 2022-09-12 14:48:18 --> Severity: Notice --> Undefined variable: teacher_grades C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 14:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza_backup\application\views\templates\school\template.php 178
ERROR - 2022-09-12 14:48:18 --> 404 Page Not Found: /index
