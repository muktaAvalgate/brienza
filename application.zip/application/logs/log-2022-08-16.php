<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-16 07:24:03 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:24:03 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:24:51 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:25:14 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 07:25:17 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 07:25:25 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 07:25:27 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 07:25:28 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:25:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 07:26:02 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:29:04 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:29:10 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:29:21 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:30:22 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:30:22 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:30:36 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:30:36 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:38:03 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:38:03 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:38:13 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:38:13 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:38:26 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:38:26 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:40:28 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:40:29 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:40:31 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:40:32 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:40:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:40:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:41:07 --> 404 Page Not Found: /index
ERROR - 2022-08-16 07:41:07 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:18:13 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:18:18 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:18:57 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:29:29 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:29:32 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:29:47 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:29:52 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:29:55 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:30:13 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 09:30:14 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 09:30:18 --> Severity: Notice --> Undefined index: session C:\xampp\htdocs\brienza_backup\application\modules\App\views\orders\list.php 125
ERROR - 2022-08-16 09:30:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 09:30:39 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 09:32:30 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:32:47 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:32:59 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 16
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'worktype_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 24
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 27
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 30
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'start_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'end_date' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 33
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'school_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'title_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'order_no' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 36
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'topic_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 39
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'total_hours' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 68
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'principle_name' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 72
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 73
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-16 09:36:19 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\brienza_backup\application\modules\App\views\presenters\create_log.php 74
ERROR - 2022-08-16 09:36:28 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:36:46 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 09:36:47 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 09:36:47 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:36:50 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:36:54 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:37:12 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:38:25 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:38:28 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:46:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:46:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:47:08 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:47:14 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:47:29 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:47:32 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:47:38 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:48:18 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:48:22 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:48:33 --> 404 Page Not Found: /index
ERROR - 2022-08-16 09:48:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 10:12:45 --> 404 Page Not Found: /index
ERROR - 2022-08-16 10:12:48 --> 404 Page Not Found: /index
ERROR - 2022-08-16 10:12:53 --> 404 Page Not Found: /index
ERROR - 2022-08-16 10:13:28 --> 404 Page Not Found: /index
ERROR - 2022-08-16 10:13:30 --> 404 Page Not Found: /index
ERROR - 2022-08-16 10:13:46 --> 404 Page Not Found: /index
ERROR - 2022-08-16 10:14:55 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:54:54 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:54:58 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:55:32 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:55:37 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:55:42 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:57:12 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:57:23 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:57:35 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:57:47 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:59:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 11:59:49 --> 404 Page Not Found: /index
ERROR - 2022-08-16 12:06:00 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:16:22 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:16:32 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 14:16:34 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:16:41 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:16:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:16:46 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:16:49 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:17:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 14:17:32 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 14:17:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:17:58 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 14:17:58 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 14:17:59 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:18:12 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:18:13 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:18:51 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:18:54 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:19:05 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:19:09 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:19:15 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:19:42 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:19:45 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:19:55 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:20:04 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:21:17 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:27:40 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:27:42 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:28:37 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:28:39 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:29:00 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:29:04 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:29:38 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:29:40 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:29:50 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:30:04 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:31:09 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:32:04 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:32:06 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:32:32 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:32:33 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:32:45 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:32:48 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:33:02 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:33:04 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:33:09 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:33:41 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:33:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:33:53 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:34:02 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:35:19 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:42:05 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:42:09 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:42:52 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:43:16 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:48:01 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:48:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:53:14 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:53:17 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:53:27 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:56:10 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:56:38 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:56:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:56:56 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:57:23 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:57:29 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:59:19 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:59:22 --> 404 Page Not Found: /index
ERROR - 2022-08-16 14:59:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:00:02 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:00:49 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:00:52 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:00:56 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:03 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:36 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:38 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:42 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:46 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:48 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:01:51 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:02:24 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 15:03:10 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:03:12 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:03:36 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:03:41 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:03:55 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:04:12 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:04:18 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:05:10 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:05:16 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:05:32 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:05:47 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:07:19 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:07:22 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:07:33 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:07:57 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:08:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:08:47 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:12:24 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:12:28 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:13:47 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 15:18:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:03 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 15:20:05 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 15:20:11 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:14 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 15:20:34 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza_backup\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-08-16 15:20:34 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:39 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:41 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:47 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:49 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:20:54 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:21:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza_backup\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-08-16 15:21:11 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:21:17 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:21:19 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:21:39 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:21:43 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:21:58 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:22:01 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:22:03 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:22:04 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:22:09 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:22:44 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:22:58 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:23:05 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:23:15 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:23:23 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:26:24 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:26:49 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:26:53 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:26:56 --> 404 Page Not Found: /index
ERROR - 2022-08-16 15:27:12 --> 404 Page Not Found: /index
