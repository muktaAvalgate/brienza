<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-05-13 07:51:54 --> 404 Page Not Found: /index
ERROR - 2022-05-13 07:52:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-05-13 07:52:12 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-05-13 07:52:13 --> 404 Page Not Found: /index
ERROR - 2022-05-13 07:54:03 --> 404 Page Not Found: /index
ERROR - 2022-05-13 07:54:04 --> Severity: Notice --> Undefined variable: purchase_orders C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-05-13 07:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\brienza\application\modules\App\views\presenters\scheduling.php 44
ERROR - 2022-05-13 07:54:04 --> 404 Page Not Found: /index
ERROR - 2022-05-13 07:54:07 --> 404 Page Not Found: /index
ERROR - 2022-05-13 07:54:10 --> 404 Page Not Found: /index
