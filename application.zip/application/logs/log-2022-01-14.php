<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-14 05:28:14 --> 404 Page Not Found: /index
