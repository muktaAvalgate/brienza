<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-18 08:28:48 --> 404 Page Not Found: /index
ERROR - 2022-02-18 08:29:04 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-18 08:29:06 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-18 08:29:07 --> 404 Page Not Found: /index
ERROR - 2022-02-18 08:29:09 --> 404 Page Not Found: /index
ERROR - 2022-02-18 08:29:16 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:05:40 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:07:36 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:07:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-18 12:07:45 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-18 12:07:46 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:08:04 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:08:06 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:20:24 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:20:34 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:21:10 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:21:55 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:25:58 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:26:21 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:27:01 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:27:34 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:27:36 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:27:55 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:28:22 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:50:09 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:50:45 --> 404 Page Not Found: /index
ERROR - 2022-02-18 12:51:02 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:16:22 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-18 13:16:23 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:17:18 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:17:25 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:17:33 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:17:38 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:18:50 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:18:53 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:19:01 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:19:03 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:20:11 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:20:39 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:20:57 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:21:27 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:21:35 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:21:54 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:21:56 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:22:39 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:22:42 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:23:06 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:23:34 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:24:01 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:27:28 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:27:31 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:27:45 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:28:00 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:28:10 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:28:16 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:28:18 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:37:38 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:38:16 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:40:51 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:44:41 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:46:17 --> 404 Page Not Found: /index
ERROR - 2022-02-18 13:46:35 --> 404 Page Not Found: /index
ERROR - 2022-02-18 14:15:02 --> 404 Page Not Found: /index
ERROR - 2022-02-18 14:15:25 --> 404 Page Not Found: /index
ERROR - 2022-02-18 14:15:29 --> 404 Page Not Found: /index
