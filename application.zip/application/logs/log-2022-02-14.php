<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-14 07:31:29 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:38:55 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-14 07:38:58 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-14 07:38:58 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:39:08 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:39:23 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:39:34 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:39:42 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:39:50 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:39:58 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:40:06 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:43:42 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:45:04 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:47:01 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:52:57 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-14 07:52:57 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-14 07:53:16 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:53:25 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-14 07:53:31 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:53:43 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:53:51 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:53:56 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:54:36 --> 404 Page Not Found: /index
ERROR - 2022-02-14 07:54:37 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:01:31 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:01:32 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:03:36 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:03:37 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:03:47 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:03:48 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:07 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:13 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:15 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:18 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:22 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:25 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:34 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:40 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:50 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:04:55 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:05:07 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:05:08 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:05:13 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:06:16 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:06:16 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:06:24 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:06:25 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:06:36 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:06:36 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:01 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:02 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:14 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:14 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:22 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:23 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:31 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:31 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:07:59 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:08:00 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:08:08 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:08:08 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:08:17 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:08:18 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:12:27 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:12:37 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:12:44 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:12:54 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:13:04 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:13:38 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:14:46 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:14:55 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:15:06 --> 404 Page Not Found: /index
ERROR - 2022-02-14 08:15:53 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-14 08:15:54 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-14 11:50:01 --> 404 Page Not Found: /index
ERROR - 2022-02-14 11:50:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-14 11:50:09 --> Severity: Notice --> Undefined variable: total_new_schedule_hour C:\xampp\htdocs\brienza\application\modules\Auth\views\dashboard.php 756
ERROR - 2022-02-14 11:50:09 --> 404 Page Not Found: /index
ERROR - 2022-02-14 11:50:30 --> 404 Page Not Found: /index
ERROR - 2022-02-14 11:50:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls C:\xampp\htdocs\brienza\application\modules\Auth\models\Auth_model.php 242
ERROR - 2022-02-14 11:50:40 --> 404 Page Not Found: /index
