<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** application/libraries/MY_Form_validation **/ 
class MY_Form_validation extends CI_Form_validation 
{
    public $CI;
}
